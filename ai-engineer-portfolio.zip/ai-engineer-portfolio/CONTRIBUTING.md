# Contributing to AI Engineer Portfolio

First off, thank you for considering contributing to this project! 🎉

## How Can I Contribute?

### 🐛 Reporting Bugs

Before creating bug reports, please check existing issues. When creating a bug report, include:

- **Clear title** describing the issue
- **Steps to reproduce** the behavior
- **Expected behavior** vs actual behavior
- **Screenshots** if applicable
- **Environment details** (OS, Python version, etc.)

### 💡 Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, include:

- **Clear title** describing the suggestion
- **Detailed description** of the proposed functionality
- **Why this would be useful** to most users
- **Possible implementation** approach

### 🔧 Pull Requests

1. **Fork** the repository
2. **Create** your feature branch (`git checkout -b feature/AmazingFeature`)
3. **Commit** your changes (`git commit -m 'Add some AmazingFeature'`)
4. **Push** to the branch (`git push origin feature/AmazingFeature`)
5. **Open** a Pull Request

#### Pull Request Guidelines

- Follow the existing code style
- Write meaningful commit messages
- Add tests if applicable
- Update documentation as needed
- Reference any related issues

## Development Setup

```bash
# Clone your fork
git clone https://github.com/yourusername/ai-engineer-portfolio.git
cd ai-engineer-portfolio

# Create virtual environment
python -m venv venv
source venv/bin/activate

# Install development dependencies
pip install -r requirements-dev.txt

# Run tests
pytest
```

## Code Style

- Follow PEP 8 guidelines
- Use type hints where possible
- Write docstrings for functions and classes
- Keep functions small and focused

### Example

```python
def calculate_impact_score(
    emissions: float,
    area: float,
    duration: int,
) -> float:
    """
    Calculate environmental impact score.
    
    Args:
        emissions: CO2 emissions in tons
        area: Affected area in hectares
        duration: Project duration in months
        
    Returns:
        Impact score from 0 to 100
    """
    # Implementation
    pass
```

## Project Structure

When adding new features, please follow the existing project structure:

```
project-name/
├── src/
│   ├── __init__.py
│   ├── config.py
│   └── main.py
├── tests/
│   └── test_main.py
├── docs/
├── requirements.txt
└── README.md
```

## Questions?

Feel free to open an issue for any questions or reach out directly.

Thank you for contributing! 🌍
