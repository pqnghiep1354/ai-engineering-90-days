# 🌍 AI Engineer Portfolio - Environmental Domain

<div align="center">

![AI Engineer](https://img.shields.io/badge/AI-Engineer-blue?style=for-the-badge&logo=artificial-intelligence)
![Python](https://img.shields.io/badge/Python-3.10+-green?style=for-the-badge&logo=python)
![LangChain](https://img.shields.io/badge/🦜_LangChain-Framework-orange?style=for-the-badge)
![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)

**5 Production-Ready Projects Demonstrating AI Engineering Expertise**

[Projects](#-projects) • [Skills](#-skills-demonstrated) • [Tech Stack](#-tech-stack) • [Getting Started](#-getting-started) • [Contact](#-contact)

</div>

---

## 👤 About Me

AI Engineer chuyên về ứng dụng AI trong lĩnh vực môi trường và phát triển bền vững. Portfolio này thể hiện hành trình từ những khái niệm cơ bản đến các hệ thống AI phức tạp, production-ready.

**Focus Areas:**
- 🤖 Large Language Models & RAG Systems
- 🔍 Semantic Search & Information Retrieval
- 🧠 Multi-Agent AI Systems
- 🌱 Environmental & ESG Applications
- 📊 Domain-Specific AI Solutions

---

## 📂 Projects

### Portfolio Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         AI ENGINEER PORTFOLIO                                │
│                    Environmental Domain Specialization                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐    │
│   │  Project 1  │   │  Project 2  │   │  Project 3  │   │  Project 4  │    │
│   │  Semantic   │──▶│  Climate    │──▶│  Multi-     │──▶│  LLM Fine-  │    │
│   │  Search     │   │  Q&A RAG    │   │  Agent      │   │  Tuning     │    │
│   │  ⭐⭐       │   │  ⭐⭐⭐     │   │  ⭐⭐⭐⭐   │   │  ⭐⭐⭐⭐⭐  │    │
│   └─────────────┘   └─────────────┘   └─────────────┘   └─────────────┘    │
│           │                 │                 │                 │           │
│           └─────────────────┴─────────────────┴─────────────────┘           │
│                                     │                                        │
│                                     ▼                                        │
│                        ┌─────────────────────────┐                          │
│                        │      Project 5          │                          │
│                        │    EIA GENERATOR        │                          │
│                        │      (CAPSTONE)         │                          │
│                        │      ⭐⭐⭐⭐⭐          │                          │
│                        └─────────────────────────┘                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Project 1: Environmental Semantic Search 🔍

**Hệ thống tìm kiếm ngữ nghĩa cho tài liệu môi trường**

<details>
<summary>📋 Chi tiết dự án</summary>

#### Description
Xây dựng hệ thống tìm kiếm thông minh sử dụng vector embeddings để tìm kiếm tài liệu môi trường, quy định pháp luật, và báo cáo ESG.

#### Features
- ✅ Vector embeddings với Sentence Transformers
- ✅ ChromaDB vector database
- ✅ Semantic similarity search
- ✅ Multi-language support (Vietnamese/English)
- ✅ CLI và Web interface

#### Tech Stack
```
Python | ChromaDB | Sentence-Transformers | Streamlit | FastAPI
```

#### Architecture
```
Documents → Chunking → Embedding → ChromaDB → Semantic Search → Results
```

#### Quick Start
```bash
cd env-semantic-search
pip install -r requirements.txt
python -m src.main --query "quy định xử lý nước thải"
```

</details>

[![View Project](https://img.shields.io/badge/View-Project-blue?style=flat-square)](./env-semantic-search)

---

### Project 2: Climate Q&A RAG System 💬

**Hệ thống hỏi đáp về khí hậu và môi trường**

<details>
<summary>📋 Chi tiết dự án</summary>

#### Description
RAG (Retrieval-Augmented Generation) system cho phép trả lời câu hỏi về biến đổi khí hậu, chính sách môi trường, và ESG dựa trên knowledge base.

#### Features
- ✅ RAG pipeline hoàn chỉnh
- ✅ Hybrid search (semantic + keyword)
- ✅ Reranking với Cross-Encoder
- ✅ Source citations
- ✅ Conversation memory
- ✅ Vietnamese regulation knowledge base

#### Tech Stack
```
LangChain | OpenAI | ChromaDB | Cross-Encoder | Streamlit
```

#### Architecture
```
Query → Retriever → Reranker → Context → LLM → Response + Citations
```

#### Sample Q&A
```
Q: Việt Nam cam kết gì tại COP26?
A: Tại COP26, Việt Nam cam kết đạt phát thải ròng bằng 0 (net-zero) 
   vào năm 2050. Đây là cam kết mạnh mẽ thể hiện quyết tâm của 
   Việt Nam trong việc ứng phó với biến đổi khí hậu...
   [Nguồn: Tuyên bố của Thủ tướng tại COP26]
```

</details>

[![View Project](https://img.shields.io/badge/View-Project-blue?style=flat-square)](./climate-qa-rag)

---

### Project 3: Multi-Agent Research System 🤖

**Hệ thống nghiên cứu đa tác tử cho phân tích môi trường**

<details>
<summary>📋 Chi tiết dự án</summary>

#### Description
Multi-agent system sử dụng LangGraph để phối hợp nhiều AI agents chuyên biệt, tự động thực hiện nghiên cứu về các chủ đề môi trường.

#### Agents
| Agent | Role | Tools |
|-------|------|-------|
| 🔬 Researcher | Thu thập thông tin | Web Search, RAG |
| 📊 Analyst | Phân tích dữ liệu | Calculator, Charts |
| ✍️ Writer | Viết báo cáo | Document Gen |
| ✅ Reviewer | Kiểm tra chất lượng | Validation |

#### Features
- ✅ LangGraph multi-agent orchestration
- ✅ Tool use (web search, RAG, calculator)
- ✅ Automatic report generation
- ✅ State management & checkpointing
- ✅ Async execution

#### Tech Stack
```
LangGraph | LangChain | Tavily | OpenAI | python-docx
```

#### Sample Output
```
📄 Research Report: "Tác động của điện mặt trời tại Việt Nam"
├── Executive Summary
├── Market Analysis (Agent: Researcher)
├── Environmental Impact (Agent: Analyst)
├── Policy Recommendations (Agent: Writer)
└── Quality Score: 92/100 (Agent: Reviewer)
```

</details>

[![View Project](https://img.shields.io/badge/View-Project-blue?style=flat-square)](./env-research-agents)

---

### Project 4: Environmental LLM Fine-tuning 🧠

**Fine-tune LLM cho domain môi trường**

<details>
<summary>📋 Chi tiết dự án</summary>

#### Description
Pipeline hoàn chỉnh để fine-tune các Large Language Models (Llama, Mistral, Phi) cho các tác vụ môi trường sử dụng LoRA và QLoRA.

#### Supported Models
- 🦙 Llama 2/3 (7B, 13B)
- 🌪️ Mistral (7B)
- 🔷 Phi-2/3 (2.7B, 3.8B)
- 💎 Gemma (2B, 7B)

#### Features
- ✅ LoRA/QLoRA parameter-efficient fine-tuning
- ✅ 4-bit quantization (8GB GPU support)
- ✅ Multiple instruction templates
- ✅ Comprehensive evaluation metrics
- ✅ Model merging & export (GGUF, ONNX)
- ✅ Gradio demo interface

#### Tech Stack
```
PyTorch | Transformers | PEFT | bitsandbytes | TRL | Weights & Biases
```

#### Performance
| Model | Before | After | Improvement |
|-------|--------|-------|-------------|
| Llama-2-7B | 62.3% | 78.5% | +16.2% |
| Mistral-7B | 68.1% | 82.3% | +14.2% |
| Phi-2 | 58.7% | 74.2% | +15.5% |

#### Training Command
```bash
python scripts/train.py \
    --model_name microsoft/phi-2 \
    --dataset data/climate_qa.json \
    --output_dir models/phi2-climate \
    --use_qlora
```

</details>

[![View Project](https://img.shields.io/badge/View-Project-blue?style=flat-square)](./env-llm-finetune)

---

### Project 5: EIA Generator (Capstone) 🌍

**Hệ thống AI tự động tạo Báo cáo Đánh giá Tác động Môi trường**

<details>
<summary>📋 Chi tiết dự án</summary>

#### Description
Capstone project tích hợp tất cả kỹ năng từ 4 dự án trước để xây dựng hệ thống AI hoàn chỉnh cho việc tạo Báo cáo Đánh giá Tác động Môi trường (ĐTM) tuân thủ pháp luật Việt Nam.

#### 6 Specialized Agents
```
┌─────────────────────────────────────────────────────────────────┐
│                    EIA GENERATOR WORKFLOW                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐     │
│  │ Research │──▶│ Baseline │──▶│  Impact  │──▶│Mitigation│     │
│  │  Agent   │   │  Agent   │   │  Agent   │   │  Agent   │     │
│  └──────────┘   └──────────┘   └──────────┘   └──────────┘     │
│       │                                              │          │
│       │         ┌──────────┐   ┌──────────┐         │          │
│       └────────▶│Monitoring│──▶│Validator │◀────────┘          │
│                 │  Agent   │   │  Agent   │                     │
│                 └──────────┘   └──────────┘                     │
│                                     │                           │
│                                     ▼                           │
│                           ┌──────────────┐                      │
│                           │ DOCX Report  │                      │
│                           └──────────────┘                      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

#### Features
- ✅ Multi-agent LangGraph workflow
- ✅ RAG-powered regulation retrieval
- ✅ Professional DOCX generation
- ✅ Vietnamese regulation compliance
- ✅ Streamlit web interface
- ✅ REST API
- ✅ Validation & quality scoring

#### Supported Project Types
- ⚡ Energy (Solar, Wind, Thermal)
- 🏭 Industrial (Manufacturing, Chemical)
- 🛣️ Infrastructure (Roads, Ports)
- 🏙️ Urban Development

#### Compliance
- 📜 Luật Bảo vệ Môi trường 2020
- 📋 Nghị định 08/2022/NĐ-CP
- 📊 QCVN Environmental Standards

#### Sample Output
```
BÁO CÁO ĐÁNH GIÁ TÁC ĐỘNG MÔI TRƯỜNG
DỰ ÁN NHÀ MÁY ĐIỆN MẶT TRỜI ABC

Chương 1: Mô tả dự án
Chương 2: Điều kiện môi trường nền
Chương 3: Đánh giá tác động môi trường
Chương 4: Biện pháp giảm thiểu
Chương 5: Chương trình quản lý và giám sát
Chương 6: Tham vấn cộng đồng

✅ Điểm đánh giá: 87/100
✅ Tuân thủ: Luật BVMT 2020
```

</details>

[![View Project](https://img.shields.io/badge/View-Project-blue?style=flat-square)](./eia-generator)

---

## 🛠 Skills Demonstrated

### AI/ML Engineering

| Skill | Projects | Proficiency |
|-------|----------|-------------|
| **RAG Systems** | #2, #5 | ████████░░ 80% |
| **LLM Fine-tuning** | #4 | ████████░░ 80% |
| **Multi-Agent Systems** | #3, #5 | █████████░ 90% |
| **Semantic Search** | #1, #2, #5 | █████████░ 90% |
| **Prompt Engineering** | All | █████████░ 90% |

### Software Engineering

| Skill | Projects | Proficiency |
|-------|----------|-------------|
| **Python** | All | █████████░ 90% |
| **API Development** | #1, #2, #5 | ████████░░ 80% |
| **Testing** | All | ███████░░░ 70% |
| **Docker** | All | ████████░░ 80% |
| **Documentation** | All | █████████░ 90% |

### Domain Expertise

| Area | Description |
|------|-------------|
| 🌍 **Environmental Regulations** | Vietnamese environmental law (Luật BVMT 2020) |
| 📊 **ESG Standards** | Environmental, Social, Governance metrics |
| 🌡️ **Climate Science** | Climate change impacts and mitigation |
| 📋 **EIA Process** | Environmental Impact Assessment methodology |

---

## 💻 Tech Stack

### Core Technologies

<div align="center">

| Category | Technologies |
|----------|--------------|
| **Language** | ![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python) |
| **AI Framework** | ![LangChain](https://img.shields.io/badge/🦜_LangChain-Latest-green) ![LangGraph](https://img.shields.io/badge/🔗_LangGraph-Latest-green) |
| **LLMs** | ![OpenAI](https://img.shields.io/badge/OpenAI-GPT--4-black?logo=openai) ![HuggingFace](https://img.shields.io/badge/🤗_HuggingFace-Transformers-yellow) |
| **Vector DB** | ![ChromaDB](https://img.shields.io/badge/ChromaDB-Latest-orange) |
| **ML/DL** | ![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-red?logo=pytorch) |
| **Web** | ![Streamlit](https://img.shields.io/badge/Streamlit-Latest-red?logo=streamlit) ![FastAPI](https://img.shields.io/badge/FastAPI-Latest-teal?logo=fastapi) |
| **DevOps** | ![Docker](https://img.shields.io/badge/Docker-Latest-blue?logo=docker) |

</div>

### Complete Stack

```
┌─────────────────────────────────────────────────────────────────┐
│                        TECHNOLOGY STACK                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    AI/ML LAYER                           │    │
│  │  LangChain | LangGraph | OpenAI | HuggingFace | PEFT    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              │                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                   DATA LAYER                             │    │
│  │  ChromaDB | Sentence-Transformers | pandas | numpy      │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              │                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                APPLICATION LAYER                         │    │
│  │  Streamlit | FastAPI | python-docx | Gradio             │    │
│  └─────────────────────────────────────────────────────────┘    │
│                              │                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │               INFRASTRUCTURE LAYER                       │    │
│  │  Docker | pytest | Loguru | Pydantic                    │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Getting Started

### Prerequisites

```bash
# Python 3.10+
python --version

# Git
git --version

# (Optional) Docker
docker --version
```

### Installation

```bash
# Clone repository
git clone https://github.com/yourusername/ai-engineer-portfolio.git
cd ai-engineer-portfolio

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies for a specific project
cd eia-generator  # or any project folder
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Add your API keys
```

### Running Projects

#### Project 1: Semantic Search
```bash
cd env-semantic-search
streamlit run app.py
```

#### Project 2: Climate Q&A
```bash
cd climate-qa-rag
streamlit run app.py
```

#### Project 3: Multi-Agent Research
```bash
cd env-research-agents
python -m src.main --topic "renewable energy vietnam"
```

#### Project 4: LLM Fine-tuning
```bash
cd env-llm-finetune
python scripts/train.py --config configs/qlora_config.yaml
```

#### Project 5: EIA Generator
```bash
cd eia-generator
streamlit run app.py
```

---

## 📊 Project Metrics

| Metric | Project 1 | Project 2 | Project 3 | Project 4 | Project 5 |
|--------|-----------|-----------|-----------|-----------|-----------|
| **Lines of Code** | ~1,500 | ~2,000 | ~2,500 | ~3,000 | ~3,500 |
| **Files** | 15 | 18 | 20 | 22 | 25 |
| **Test Coverage** | 70% | 75% | 80% | 75% | 80% |
| **Documentation** | ✅ | ✅ | ✅ | ✅ | ✅ |

---

## 📁 Repository Structure

```
ai-engineer-portfolio/
├── README.md                    # This file
├── env-semantic-search/         # Project 1
│   ├── src/
│   ├── tests/
│   ├── app.py
│   └── README.md
├── climate-qa-rag/              # Project 2
│   ├── src/
│   ├── data/
│   ├── app.py
│   └── README.md
├── env-research-agents/         # Project 3
│   ├── src/agents/
│   ├── src/tools/
│   ├── app.py
│   └── README.md
├── env-llm-finetune/            # Project 4
│   ├── src/
│   ├── scripts/
│   ├── configs/
│   └── README.md
├── eia-generator/               # Project 5 (Capstone)
│   ├── src/agents/
│   ├── src/generators/
│   ├── data/regulations/
│   ├── app.py
│   └── README.md
└── docs/
    ├── roadmap.md
    └── architecture.md
```

---

## 🎯 Learning Journey

### 90-Day AI Engineer Roadmap

```
Month 1: Foundations
├── Week 1-2: Python, ML basics
├── Week 3-4: LLM fundamentals, embeddings
└── Project 1: Semantic Search ✅

Month 2: Intermediate
├── Week 5-6: RAG systems, LangChain
├── Week 7-8: Multi-agent systems
├── Project 2: Climate Q&A RAG ✅
└── Project 3: Multi-Agent Research ✅

Month 3: Advanced
├── Week 9-10: LLM fine-tuning, PEFT
├── Week 11-12: Production systems
├── Project 4: LLM Fine-tuning ✅
└── Project 5: EIA Generator (Capstone) ✅
```

---

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 📫 Contact

<div align="center">

[![Email](https://img.shields.io/badge/Email-Contact-red?style=for-the-badge&logo=gmail)](mailto:your.email@example.com)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue?style=for-the-badge&logo=linkedin)](https://linkedin.com/in/yourprofile)
[![GitHub](https://img.shields.io/badge/GitHub-Follow-black?style=for-the-badge&logo=github)](https://github.com/yourusername)

</div>

---

## ⭐ Acknowledgments

- OpenAI for GPT models
- LangChain & LangGraph teams
- Hugging Face community
- Vietnamese Ministry of Natural Resources and Environment
- All open-source contributors

---

<div align="center">

**Made with ❤️ for Environmental AI**

*If you find this portfolio helpful, please give it a ⭐!*

</div>
