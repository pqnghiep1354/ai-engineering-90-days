# 🗺️ 90-Day AI Engineer Roadmap

## Overview

Lộ trình 90 ngày để trở thành AI Engineer chuyên về lĩnh vực môi trường, từ cơ bản đến nâng cao với 5 portfolio projects.

---

## 📅 Timeline

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          90-DAY LEARNING JOURNEY                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  MONTH 1: FOUNDATIONS                                                        │
│  ══════════════════                                                          │
│  Week 1-2: Python & ML Basics                                               │
│  Week 3-4: LLM & Embeddings Fundamentals                                    │
│  🎯 Project 1: Semantic Search                                              │
│                                                                              │
│  MONTH 2: INTERMEDIATE                                                       │
│  ════════════════════                                                        │
│  Week 5-6: RAG Systems & LangChain                                          │
│  Week 7-8: Multi-Agent Architectures                                        │
│  🎯 Project 2: Climate Q&A RAG                                              │
│  🎯 Project 3: Multi-Agent Research                                         │
│                                                                              │
│  MONTH 3: ADVANCED                                                           │
│  ═════════════════                                                           │
│  Week 9-10: LLM Fine-tuning & PEFT                                          │
│  Week 11-12: Production Systems                                             │
│  🎯 Project 4: LLM Fine-tuning                                              │
│  🎯 Project 5: EIA Generator (Capstone)                                     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Month 1: Foundations (Tuần 1-4)

### Week 1-2: Python & ML Basics

#### Learning Goals
- [ ] Python advanced concepts (OOP, async, decorators)
- [ ] NumPy, Pandas for data manipulation
- [ ] Basic ML concepts (embeddings, similarity)
- [ ] Git workflow

#### Resources
- Python Documentation
- NumPy/Pandas tutorials
- Scikit-learn basics

#### Practice
```python
# Example: Cosine similarity
import numpy as np

def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
```

### Week 3-4: LLM & Embeddings

#### Learning Goals
- [ ] Understanding transformers architecture
- [ ] Text embeddings (Word2Vec, Sentence-BERT)
- [ ] Vector databases (ChromaDB, Pinecone)
- [ ] OpenAI API basics

#### Resources
- Hugging Face course
- OpenAI documentation
- ChromaDB tutorials

#### 🎯 Project 1: Environmental Semantic Search

**Objectives:**
1. Build document chunking pipeline
2. Create embeddings with Sentence Transformers
3. Store in ChromaDB
4. Implement semantic search
5. Build Streamlit interface

**Deliverables:**
- Working semantic search system
- CLI and web interface
- Documentation

---

## Month 2: Intermediate (Tuần 5-8)

### Week 5-6: RAG Systems & LangChain

#### Learning Goals
- [ ] RAG architecture
- [ ] LangChain framework
- [ ] Prompt engineering
- [ ] Chain composition

#### Resources
- LangChain documentation
- RAG paper (Lewis et al.)
- Prompt engineering guides

#### Key Concepts
```python
# RAG Pipeline
from langchain.chains import RetrievalQA

chain = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff",
    retriever=vectorstore.as_retriever(),
)
```

#### 🎯 Project 2: Climate Q&A RAG

**Objectives:**
1. Build comprehensive RAG pipeline
2. Implement hybrid search
3. Add reranking
4. Source citations
5. Conversation memory

### Week 7-8: Multi-Agent Systems

#### Learning Goals
- [ ] LangGraph fundamentals
- [ ] Agent architectures
- [ ] Tool use
- [ ] State management

#### Resources
- LangGraph documentation
- Multi-agent papers
- Agent design patterns

#### 🎯 Project 3: Multi-Agent Research

**Objectives:**
1. Design agent roles
2. Implement LangGraph workflow
3. Create custom tools
4. Automatic report generation

---

## Month 3: Advanced (Tuần 9-12)

### Week 9-10: LLM Fine-tuning

#### Learning Goals
- [ ] Fine-tuning concepts
- [ ] LoRA/QLoRA techniques
- [ ] PEFT library
- [ ] Evaluation metrics

#### Resources
- Hugging Face PEFT docs
- LoRA paper
- QLoRA paper

#### Key Concepts
```python
# LoRA Configuration
from peft import LoraConfig

lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
)
```

#### 🎯 Project 4: Environmental LLM Fine-tuning

**Objectives:**
1. Prepare training data
2. Configure LoRA/QLoRA
3. Train on environmental data
4. Evaluate and compare
5. Export models

### Week 11-12: Production & Capstone

#### Learning Goals
- [ ] System design
- [ ] API development
- [ ] Docker deployment
- [ ] Testing strategies

#### 🎯 Project 5: EIA Generator (Capstone)

**Objectives:**
1. Design multi-agent workflow
2. Integrate RAG system
3. Document generation
4. Compliance validation
5. Web interface
6. API development

---

## 📚 Recommended Resources

### Books
1. "Natural Language Processing with Transformers" - Hugging Face
2. "Building LLM Apps" - O'Reilly
3. "Designing Machine Learning Systems" - Chip Huyen

### Courses
1. Hugging Face NLP Course
2. DeepLearning.AI LangChain Course
3. Fast.ai Practical Deep Learning

### Papers
1. "Attention Is All You Need" (Transformer)
2. "BERT: Pre-training of Deep Bidirectional Transformers"
3. "LoRA: Low-Rank Adaptation of Large Language Models"
4. "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks"

### Communities
- Hugging Face Discord
- LangChain Discord
- Reddit r/MachineLearning

---

## ✅ Completion Checklist

### Month 1
- [ ] Python advanced concepts mastered
- [ ] Embeddings understood
- [ ] ChromaDB set up
- [ ] **Project 1 completed**

### Month 2
- [ ] RAG pipeline built
- [ ] LangChain proficient
- [ ] Multi-agent systems understood
- [ ] **Project 2 completed**
- [ ] **Project 3 completed**

### Month 3
- [ ] Fine-tuning completed
- [ ] Production deployment done
- [ ] **Project 4 completed**
- [ ] **Project 5 completed**
- [ ] **Portfolio ready!** 🎉

---

## 🎯 Career Outcomes

After completing this roadmap, you will be qualified for:

- **AI Engineer** - Building AI-powered applications
- **ML Engineer** - Developing and deploying ML models
- **LLM Engineer** - Specializing in large language models
- **NLP Engineer** - Natural language processing systems
- **Environmental Tech Specialist** - AI for sustainability

---

**Good luck on your AI Engineering journey! 🚀**
