# 🎓 GIAI ĐOẠN 2: TRUNG CẤP (INTERMEDIATE)

## Tuần 5-8 | 60+ giờ học tập

---

## 📋 TỔNG QUAN GIAI ĐOẠN

### Mục tiêu
Nâng cao kỹ năng với RAG architecture, framework mastery, production optimization, và tool integration để xây dựng hệ thống AI hoàn chỉnh.

### Kết quả đầu ra
**PROJECT 2: Environmental Compliance RAG System với Tool Capabilities**

---

## 📚 CẤU TRÚC TÀI LIỆU

```
phase-2-intermediate/
├── README.md                           # File này
│
├── week-5/
│   └── WEEK-5-RAG-ARCHITECTURE.md
│       ├── RAG Patterns (Naive, Advanced, Modular)
│       ├── Query Transformation (HyDE, Multi-query)
│       ├── Retrieval Strategies (Dense, Sparse, Hybrid)
│       ├── Reranking với Cohere
│       └── RAG Evaluation với RAGAS
│
├── week-6/
│   └── WEEK-6-LANGCHAIN-LLAMAINDEX.md
│       ├── LangChain LCEL Deep Dive
│       ├── LangChain Structured Output
│       ├── LlamaIndex Indexes & Query Engines
│       ├── Custom Node Parsers
│       └── Framework Comparison
│
├── week-7/
│   └── WEEK-7-PRODUCTION-RAG.md
│       ├── Semantic Caching
│       ├── Embedding Batching
│       ├── Parallel Processing
│       ├── Monitoring & Observability
│       └── Cost Tracking
│
└── week-8/
    └── WEEK-8-FUNCTION-CALLING.md
        ├── Tool Definition Framework
        ├── Environmental Domain Tools
        ├── Tool Execution Engine
        ├── Tool-Augmented LLM
        └── Compliance Assistant
```

---

## 📅 LỊCH TRÌNH CHI TIẾT

### Tuần 5: RAG Architecture Deep Dive

| Ngày | Nội dung | Thời gian |
|------|----------|-----------|
| 1-2 | RAG Patterns, Query Transformation | 4-6h |
| 3-4 | Advanced Retrieval (Hybrid, Reranking) | 4-6h |
| 5-6 | RAG Evaluation với RAGAS | 4-6h |
| 7 | Benchmark và optimization | 2-3h |

**Deliverables:**
- Advanced RAG implementation
- Hybrid search system
- RAGAS evaluation pipeline

---

### Tuần 6: LangChain & LlamaIndex Deep Dive

| Ngày | Nội dung | Thời gian |
|------|----------|-----------|
| 1-2 | LangChain LCEL Mastery | 4-6h |
| 3-4 | LlamaIndex Query Engines | 4-6h |
| 5-6 | Framework Comparison | 4-6h |
| 7 | Integration và testing | 2-3h |

**Deliverables:**
- LCEL-based RAG chain
- LlamaIndex query engines
- Comparison report

---

### Tuần 7: Production RAG Optimization

| Ngày | Nội dung | Thời gian |
|------|----------|-----------|
| 1-2 | Semantic Caching với Redis | 4-6h |
| 3-4 | Batching và Parallel Processing | 4-6h |
| 5-6 | Monitoring và Observability | 4-6h |
| 7 | Cost optimization | 2-3h |

**Deliverables:**
- Semantic caching system
- Monitoring dashboard
- Cost tracking

---

### Tuần 8: Function Calling & Tool Use

| Ngày | Nội dung | Thời gian |
|------|----------|-----------|
| 1-2 | Tool Definition Framework | 4-6h |
| 3-4 | Environmental Domain Tools | 4-6h |
| 5-6 | Tool Execution Engine | 4-6h |
| 7 | Integration và demo | 2-3h |

**Deliverables:**
- Tool framework
- Domain tools
- Compliance assistant

---

## 🛠 TECH STACK BỔ SUNG

### Frameworks
- LangChain (LCEL)
- LlamaIndex
- LangGraph (preview)

### Caching & Storage
- Redis
- ChromaDB (advanced)
- Pinecone (optional)

### Reranking
- Cohere Rerank
- Cross-encoders

### Monitoring
- Prometheus
- Grafana
- LangSmith

### APIs
- OpenAI Function Calling
- Anthropic Tool Use

---

## 📊 METRICS ĐÁNH GIÁ

### RAG Quality Metrics

| Metric | Target | Actual |
|--------|--------|--------|
| Faithfulness | > 0.85 | |
| Answer Relevancy | > 0.80 | |
| Context Precision | > 0.75 | |
| Context Recall | > 0.80 | |

### Performance Metrics

| Metric | Target | Actual |
|--------|--------|--------|
| P95 Latency (cached) | < 200ms | |
| P95 Latency (uncached) | < 3000ms | |
| Cache Hit Rate | > 30% | |
| Cost per Query | < $0.05 | |

### Project Completion

| Component | Status |
|-----------|--------|
| Advanced RAG | ☐ |
| Hybrid Search | ☐ |
| Framework Integration | ☐ |
| Semantic Cache | ☐ |
| Monitoring | ☐ |
| Tool Framework | ☐ |
| Compliance Tools | ☐ |
| Assistant Integration | ☐ |

---

## 📝 CHECKLIST HOÀN THÀNH

### Kiến thức

- [ ] **RAG Architecture**
  - [ ] RAG patterns (naive, advanced, modular)
  - [ ] Query transformation techniques
  - [ ] Retrieval strategies
  - [ ] Evaluation metrics

- [ ] **Frameworks**
  - [ ] LangChain LCEL
  - [ ] LlamaIndex indexes và query engines
  - [ ] Custom components
  - [ ] Framework selection criteria

- [ ] **Production Optimization**
  - [ ] Caching strategies
  - [ ] Batching patterns
  - [ ] Monitoring best practices
  - [ ] Cost optimization

- [ ] **Tool Use**
  - [ ] Function calling APIs
  - [ ] Tool definition schemas
  - [ ] Execution patterns
  - [ ] Error handling

### Skills

- [ ] Build advanced RAG pipelines
- [ ] Implement hybrid search
- [ ] Use LCEL effectively
- [ ] Create custom LlamaIndex components
- [ ] Setup semantic caching
- [ ] Build monitoring dashboards
- [ ] Define và execute tools
- [ ] Create tool-augmented assistants

### Projects

- [ ] **PROJECT 2**: Environmental Compliance RAG + Tools
  - [ ] Advanced retrieval với HyDE, multi-query
  - [ ] Hybrid search (semantic + BM25)
  - [ ] Cohere reranking
  - [ ] Semantic caching
  - [ ] Monitoring system
  - [ ] Compliance checking tools
  - [ ] Tool-augmented assistant
  - [ ] API endpoints

---

## 🔗 TÀI NGUYÊN

### Tài liệu tuần 5
- [Week 5: RAG Architecture](./week-5/WEEK-5-RAG-ARCHITECTURE.md)

### Tài liệu tuần 6
- [Week 6: LangChain & LlamaIndex](./week-6/WEEK-6-LANGCHAIN-LLAMAINDEX.md)

### Tài liệu tuần 7
- [Week 7: Production RAG](./week-7/WEEK-7-PRODUCTION-RAG.md)

### Tài liệu tuần 8
- [Week 8: Function Calling & Tool Use](./week-8/WEEK-8-FUNCTION-CALLING.md)

---

## ➡️ BƯỚC TIẾP THEO

Sau khi hoàn thành Phase 2, bạn sẽ tiếp tục với:

### Phase 3: Advanced (Tuần 9-12)
- **Tuần 9**: Multi-Agent Systems với LangGraph
- **Tuần 10**: Document Generation Pipeline
- **Tuần 11**: Testing & Deployment
- **Tuần 12**: Capstone Project - Full Integration

### Capstone Project Preview
**Environmental Compliance Management System**
- Multi-agent architecture
- Automated report generation
- Real-time monitoring integration
- Production deployment

---

## 📈 SO SÁNH VỚI PHASE 1

| Aspect | Phase 1 (Foundation) | Phase 2 (Intermediate) |
|--------|---------------------|----------------------|
| RAG | Basic semantic search | Advanced với HyDE, reranking |
| Frameworks | Custom implementation | LangChain + LlamaIndex |
| Caching | None | Semantic caching |
| Tools | None | Full tool integration |
| Monitoring | Basic logging | Prometheus + Grafana |
| Evaluation | Manual | RAGAS automated |

---

*Chúc bạn học tập hiệu quả! 🚀*
