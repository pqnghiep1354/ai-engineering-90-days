# 📅 TUẦN 8: FUNCTION CALLING & TOOL USE

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Thành thạo function calling và tool integration |
| **Output** | Environmental Compliance Assistant với tools |
| **Độ khó** | ⭐⭐⭐⭐ Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu function calling APIs (OpenAI, Anthropic)
- [ ] Nắm vững tool definition và schemas
- [ ] Hiểu ReAct pattern và tool orchestration
- [ ] Biết error handling và retry strategies

### Kỹ năng (Skills)
- [ ] Define tools với JSON Schema
- [ ] Implement custom tools cho environmental domain
- [ ] Build tool execution pipeline
- [ ] Handle parallel và sequential tool calls

### Ứng dụng (Application)
- [ ] Environmental Compliance Checker tool
- [ ] Regulation Lookup tool
- [ ] Data Analysis tool
- [ ] Report Generation tool

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: Function Calling Fundamentals

#### 1.1 Function Calling Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         FUNCTION CALLING FLOW                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                        STANDARD FLOW                                 │    │
│  │                                                                      │    │
│  │   User        LLM          Tool         LLM          Response       │    │
│  │    │           │            │            │              │           │    │
│  │    │──Query───▶│            │            │              │           │    │
│  │    │           │──Decide────▶            │              │           │    │
│  │    │           │  to call   │            │              │           │    │
│  │    │           │  tool      │            │              │           │    │
│  │    │           │◀──Result───│            │              │           │    │
│  │    │           │────────────────────────▶│              │           │    │
│  │    │           │            │            │──Generate───▶│           │    │
│  │    │◀──────────────────────────────────────────────────│           │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                     PARALLEL TOOL CALLS                              │    │
│  │                                                                      │    │
│  │   User ──▶ LLM ──┬──▶ Tool A ──┐                                    │    │
│  │                  ├──▶ Tool B ──┼──▶ LLM ──▶ Response                │    │
│  │                  └──▶ Tool C ──┘                                    │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                     SEQUENTIAL (ReAct)                               │    │
│  │                                                                      │    │
│  │   Thought ──▶ Action ──▶ Observation ──▶ Thought ──▶ ... ──▶ Answer │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 Tool Definition Framework

```python
# ============================================
# TOOL DEFINITION FRAMEWORK
# ============================================

from typing import Dict, List, Optional, Any, Callable, Union, Type
from dataclasses import dataclass, field
from pydantic import BaseModel, Field, create_model
from enum import Enum
import json
import inspect
from abc import ABC, abstractmethod

class ToolParameterType(Enum):
    """Supported parameter types."""
    STRING = "string"
    NUMBER = "number"
    INTEGER = "integer"
    BOOLEAN = "boolean"
    ARRAY = "array"
    OBJECT = "object"

@dataclass
class ToolParameter:
    """Definition of a tool parameter."""
    name: str
    type: ToolParameterType
    description: str
    required: bool = True
    enum: Optional[List[str]] = None
    default: Any = None
    items: Optional[Dict] = None  # For array types
    properties: Optional[Dict] = None  # For object types

@dataclass
class ToolDefinition:
    """Complete tool definition."""
    name: str
    description: str
    parameters: List[ToolParameter]
    returns: str = "string"
    examples: List[Dict] = field(default_factory=list)
    
    def to_openai_schema(self) -> Dict:
        """Convert to OpenAI function calling format."""
        properties = {}
        required = []
        
        for param in self.parameters:
            prop = {
                "type": param.type.value,
                "description": param.description
            }
            
            if param.enum:
                prop["enum"] = param.enum
            
            if param.type == ToolParameterType.ARRAY and param.items:
                prop["items"] = param.items
            
            if param.type == ToolParameterType.OBJECT and param.properties:
                prop["properties"] = param.properties
            
            properties[param.name] = prop
            
            if param.required:
                required.append(param.name)
        
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required
                }
            }
        }
    
    def to_anthropic_schema(self) -> Dict:
        """Convert to Anthropic tool use format."""
        properties = {}
        required = []
        
        for param in self.parameters:
            prop = {
                "type": param.type.value,
                "description": param.description
            }
            
            if param.enum:
                prop["enum"] = param.enum
            
            properties[param.name] = prop
            
            if param.required:
                required.append(param.name)
        
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": {
                "type": "object",
                "properties": properties,
                "required": required
            }
        }


class BaseTool(ABC):
    """Abstract base class for tools."""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Tool name."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Tool description."""
        pass
    
    @property
    @abstractmethod
    def parameters(self) -> List[ToolParameter]:
        """Tool parameters."""
        pass
    
    @abstractmethod
    def execute(self, **kwargs) -> Any:
        """Execute the tool."""
        pass
    
    def get_definition(self) -> ToolDefinition:
        """Get tool definition."""
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters=self.parameters
        )
    
    def validate_params(self, **kwargs) -> bool:
        """Validate input parameters."""
        for param in self.parameters:
            if param.required and param.name not in kwargs:
                raise ValueError(f"Missing required parameter: {param.name}")
            
            if param.name in kwargs and param.enum:
                if kwargs[param.name] not in param.enum:
                    raise ValueError(
                        f"Invalid value for {param.name}: {kwargs[param.name]}. "
                        f"Must be one of: {param.enum}"
                    )
        
        return True


def tool(
    name: str = None,
    description: str = None
):
    """
    Decorator to convert a function into a tool.
    
    Usage:
        @tool(name="search_regulations", description="Search environmental regulations")
        def search_regulations(query: str, domain: str = None) -> str:
            '''
            Search for environmental regulations.
            
            Args:
                query: Search query
                domain: Filter by domain (air, water, waste)
            '''
            # Implementation
            pass
    """
    def decorator(func: Callable) -> 'FunctionTool':
        return FunctionTool(func, name, description)
    
    return decorator


class FunctionTool(BaseTool):
    """Tool created from a function."""
    
    def __init__(
        self,
        func: Callable,
        name: str = None,
        description: str = None
    ):
        self.func = func
        self._name = name or func.__name__
        self._description = description or (func.__doc__ or "").split("\n")[0]
        self._parameters = self._extract_parameters()
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        return self._description
    
    @property
    def parameters(self) -> List[ToolParameter]:
        return self._parameters
    
    def _extract_parameters(self) -> List[ToolParameter]:
        """Extract parameters from function signature and docstring."""
        import typing
        
        sig = inspect.signature(self.func)
        hints = typing.get_type_hints(self.func) if hasattr(self.func, '__annotations__') else {}
        
        # Parse docstring for descriptions
        docstring = self.func.__doc__ or ""
        param_docs = self._parse_docstring_params(docstring)
        
        parameters = []
        
        for param_name, param in sig.parameters.items():
            if param_name == 'self':
                continue
            
            # Determine type
            type_hint = hints.get(param_name, str)
            param_type = self._python_type_to_tool_type(type_hint)
            
            # Check if required
            required = param.default == inspect.Parameter.empty
            default = None if required else param.default
            
            # Get description from docstring
            description = param_docs.get(param_name, f"Parameter {param_name}")
            
            parameters.append(ToolParameter(
                name=param_name,
                type=param_type,
                description=description,
                required=required,
                default=default
            ))
        
        return parameters
    
    def _python_type_to_tool_type(self, type_hint) -> ToolParameterType:
        """Convert Python type hint to tool parameter type."""
        import typing
        
        origin = typing.get_origin(type_hint)
        
        if type_hint == str:
            return ToolParameterType.STRING
        elif type_hint == int:
            return ToolParameterType.INTEGER
        elif type_hint == float:
            return ToolParameterType.NUMBER
        elif type_hint == bool:
            return ToolParameterType.BOOLEAN
        elif origin == list or type_hint == list:
            return ToolParameterType.ARRAY
        elif origin == dict or type_hint == dict:
            return ToolParameterType.OBJECT
        else:
            return ToolParameterType.STRING
    
    def _parse_docstring_params(self, docstring: str) -> Dict[str, str]:
        """Parse parameter descriptions from docstring."""
        params = {}
        
        # Simple parsing for Google-style docstrings
        in_args = False
        current_param = None
        current_desc = []
        
        for line in docstring.split('\n'):
            line = line.strip()
            
            if line.lower().startswith('args:'):
                in_args = True
                continue
            
            if in_args:
                if line.lower().startswith(('returns:', 'raises:', 'example')):
                    break
                
                if ':' in line and not line.startswith(' '):
                    # Save previous param
                    if current_param:
                        params[current_param] = ' '.join(current_desc).strip()
                    
                    # Parse new param
                    parts = line.split(':', 1)
                    current_param = parts[0].strip()
                    current_desc = [parts[1].strip()] if len(parts) > 1 else []
                elif current_param and line:
                    current_desc.append(line)
        
        # Don't forget last param
        if current_param:
            params[current_param] = ' '.join(current_desc).strip()
        
        return params
    
    def execute(self, **kwargs) -> Any:
        """Execute the underlying function."""
        self.validate_params(**kwargs)
        return self.func(**kwargs)
    
    def __call__(self, **kwargs) -> Any:
        """Allow calling tool directly."""
        return self.execute(**kwargs)


# ============================================
# TOOL REGISTRY
# ============================================

class ToolRegistry:
    """
    Registry for managing tools.
    """
    
    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}
    
    def register(self, tool: BaseTool):
        """Register a tool."""
        self._tools[tool.name] = tool
    
    def get(self, name: str) -> Optional[BaseTool]:
        """Get tool by name."""
        return self._tools.get(name)
    
    def list_tools(self) -> List[str]:
        """List all registered tool names."""
        return list(self._tools.keys())
    
    def get_all_definitions(self) -> List[ToolDefinition]:
        """Get all tool definitions."""
        return [tool.get_definition() for tool in self._tools.values()]
    
    def get_openai_tools(self) -> List[Dict]:
        """Get all tools in OpenAI format."""
        return [
            tool.get_definition().to_openai_schema()
            for tool in self._tools.values()
        ]
    
    def get_anthropic_tools(self) -> List[Dict]:
        """Get all tools in Anthropic format."""
        return [
            tool.get_definition().to_anthropic_schema()
            for tool in self._tools.values()
        ]
    
    def execute(self, tool_name: str, **kwargs) -> Any:
        """Execute a tool by name."""
        tool = self.get(tool_name)
        if tool is None:
            raise ValueError(f"Unknown tool: {tool_name}")
        
        return tool.execute(**kwargs)
```

### Ngày 3-4: Environmental Domain Tools

#### 2.1 Compliance Checking Tools

```python
# ============================================
# ENVIRONMENTAL COMPLIANCE TOOLS
# ============================================

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import json

# ==================== COMPLIANCE CHECKER ====================

class ComplianceCheckerTool(BaseTool):
    """
    Tool for checking environmental compliance against QCVN standards.
    """
    
    # QCVN standards database
    QCVN_STANDARDS = {
        "QCVN_40_2011": {
            "name": "QCVN 40:2011/BTNMT",
            "description": "Quy chuẩn kỹ thuật quốc gia về nước thải công nghiệp",
            "parameters": {
                "BOD5": {"column_A": 30, "column_B": 50, "unit": "mg/L"},
                "COD": {"column_A": 75, "column_B": 150, "unit": "mg/L"},
                "TSS": {"column_A": 50, "column_B": 100, "unit": "mg/L"},
                "pH": {"column_A": [6, 9], "column_B": [5.5, 9], "unit": "-"},
                "Amonia": {"column_A": 5, "column_B": 10, "unit": "mg/L"},
                "Tong_Nito": {"column_A": 20, "column_B": 40, "unit": "mg/L"},
                "Tong_Photpho": {"column_A": 4, "column_B": 6, "unit": "mg/L"},
                "Coliform": {"column_A": 3000, "column_B": 5000, "unit": "MPN/100mL"},
            }
        },
        "QCVN_05_2023": {
            "name": "QCVN 05:2023/BTNMT",
            "description": "Quy chuẩn kỹ thuật quốc gia về chất lượng không khí",
            "parameters": {
                "PM2.5": {"24h": 50, "year": 25, "unit": "μg/m³"},
                "PM10": {"24h": 100, "year": 50, "unit": "μg/m³"},
                "SO2": {"1h": 350, "24h": 125, "year": 50, "unit": "μg/m³"},
                "NO2": {"1h": 200, "24h": 100, "year": 40, "unit": "μg/m³"},
                "CO": {"1h": 30000, "8h": 10000, "unit": "μg/m³"},
                "O3": {"1h": 180, "8h": 120, "unit": "μg/m³"},
            }
        }
    }
    
    @property
    def name(self) -> str:
        return "check_compliance"
    
    @property
    def description(self) -> str:
        return """Kiểm tra tuân thủ quy chuẩn môi trường Việt Nam (QCVN).
        
Hỗ trợ các quy chuẩn:
- QCVN 40:2011/BTNMT: Nước thải công nghiệp
- QCVN 05:2023/BTNMT: Chất lượng không khí

Trả về kết quả kiểm tra chi tiết với trạng thái ĐẠT/KHÔNG ĐẠT."""
    
    @property
    def parameters(self) -> List[ToolParameter]:
        return [
            ToolParameter(
                name="parameter",
                type=ToolParameterType.STRING,
                description="Thông số cần kiểm tra (VD: BOD5, COD, PM2.5)",
                required=True
            ),
            ToolParameter(
                name="value",
                type=ToolParameterType.NUMBER,
                description="Giá trị đo được",
                required=True
            ),
            ToolParameter(
                name="standard",
                type=ToolParameterType.STRING,
                description="Mã quy chuẩn (VD: QCVN_40_2011, QCVN_05_2023)",
                required=True,
                enum=["QCVN_40_2011", "QCVN_05_2023"]
            ),
            ToolParameter(
                name="column",
                type=ToolParameterType.STRING,
                description="Cột áp dụng cho QCVN 40 (A hoặc B) hoặc loại trung bình cho QCVN 05 (1h, 8h, 24h, year)",
                required=False,
                default="B"
            )
        ]
    
    def execute(
        self,
        parameter: str,
        value: float,
        standard: str,
        column: str = "B"
    ) -> Dict:
        """Execute compliance check."""
        
        if standard not in self.QCVN_STANDARDS:
            return {
                "error": f"Unknown standard: {standard}",
                "supported_standards": list(self.QCVN_STANDARDS.keys())
            }
        
        qcvn = self.QCVN_STANDARDS[standard]
        
        if parameter not in qcvn["parameters"]:
            return {
                "error": f"Unknown parameter: {parameter}",
                "supported_parameters": list(qcvn["parameters"].keys())
            }
        
        param_spec = qcvn["parameters"][parameter]
        unit = param_spec["unit"]
        
        # Get limit based on column/type
        if standard == "QCVN_40_2011":
            column_key = f"column_{column}"
            if column_key not in param_spec:
                column_key = "column_B"
            limit = param_spec[column_key]
        else:
            limit = param_spec.get(column, param_spec.get("24h"))
        
        # Check compliance
        if isinstance(limit, list):
            # Range check (e.g., pH)
            compliant = limit[0] <= value <= limit[1]
            limit_str = f"{limit[0]} - {limit[1]}"
        else:
            compliant = value <= limit
            limit_str = str(limit)
        
        # Calculate exceedance
        if isinstance(limit, list):
            if value < limit[0]:
                exceedance_pct = ((limit[0] - value) / limit[0]) * 100
            elif value > limit[1]:
                exceedance_pct = ((value - limit[1]) / limit[1]) * 100
            else:
                exceedance_pct = 0
        else:
            if value > limit:
                exceedance_pct = ((value - limit) / limit) * 100
            else:
                exceedance_pct = 0
        
        return {
            "parameter": parameter,
            "measured_value": value,
            "unit": unit,
            "standard": qcvn["name"],
            "standard_description": qcvn["description"],
            "limit": limit_str,
            "column_or_type": column,
            "compliant": compliant,
            "status": "ĐẠT" if compliant else "KHÔNG ĐẠT",
            "exceedance_percent": round(exceedance_pct, 2) if not compliant else 0,
            "checked_at": datetime.now().isoformat()
        }


# ==================== REGULATION SEARCH ====================

class RegulationSearchTool(BaseTool):
    """
    Tool for searching Vietnamese environmental regulations.
    """
    
    def __init__(self, vector_store):
        self.vector_store = vector_store
    
    @property
    def name(self) -> str:
        return "search_regulations"
    
    @property
    def description(self) -> str:
        return """Tìm kiếm văn bản quy định môi trường Việt Nam.
        
Hỗ trợ tìm kiếm:
- Luật, Nghị định, Thông tư
- QCVN, TCVN
- Theo lĩnh vực: không khí, nước, chất thải, ĐTM, giấy phép

Trả về các văn bản phù hợp với độ liên quan."""
    
    @property
    def parameters(self) -> List[ToolParameter]:
        return [
            ToolParameter(
                name="query",
                type=ToolParameterType.STRING,
                description="Nội dung cần tìm kiếm",
                required=True
            ),
            ToolParameter(
                name="domain",
                type=ToolParameterType.STRING,
                description="Lĩnh vực môi trường",
                required=False,
                enum=["air_quality", "water_quality", "waste_management", "eia", "permit", "monitoring"]
            ),
            ToolParameter(
                name="doc_type",
                type=ToolParameterType.STRING,
                description="Loại văn bản",
                required=False,
                enum=["luat", "nghi_dinh", "thong_tu", "qcvn", "tcvn", "quyet_dinh"]
            ),
            ToolParameter(
                name="max_results",
                type=ToolParameterType.INTEGER,
                description="Số kết quả tối đa",
                required=False,
                default=5
            )
        ]
    
    def execute(
        self,
        query: str,
        domain: str = None,
        doc_type: str = None,
        max_results: int = 5
    ) -> Dict:
        """Search regulations."""
        
        # Build filter
        filter_dict = {}
        if domain:
            filter_dict["domain"] = domain
        if doc_type:
            filter_dict["doc_type"] = doc_type
        
        # Search
        results = self.vector_store.search(
            query=query,
            n_results=max_results,
            where=filter_dict if filter_dict else None
        )
        
        return {
            "query": query,
            "filters": {
                "domain": domain,
                "doc_type": doc_type
            },
            "total_results": len(results),
            "results": [
                {
                    "id": r.id,
                    "doc_number": r.metadata.get("doc_number"),
                    "title": r.metadata.get("title", ""),
                    "article": r.metadata.get("article"),
                    "content_snippet": r.content[:500] + "..." if len(r.content) > 500 else r.content,
                    "relevance_score": round(r.score, 4),
                    "domain": r.metadata.get("domain"),
                    "doc_type": r.metadata.get("doc_type")
                }
                for r in results
            ]
        }


# ==================== DATA ANALYSIS ====================

class EnvironmentalDataAnalysisTool(BaseTool):
    """
    Tool for analyzing environmental monitoring data.
    """
    
    @property
    def name(self) -> str:
        return "analyze_environmental_data"
    
    @property
    def description(self) -> str:
        return """Phân tích dữ liệu quan trắc môi trường.
        
Hỗ trợ:
- Thống kê mô tả (mean, median, std, min, max)
- Phát hiện outliers
- Xu hướng theo thời gian
- So sánh với quy chuẩn"""
    
    @property
    def parameters(self) -> List[ToolParameter]:
        return [
            ToolParameter(
                name="data",
                type=ToolParameterType.ARRAY,
                description="Mảng dữ liệu đo đạc",
                required=True,
                items={"type": "number"}
            ),
            ToolParameter(
                name="parameter_name",
                type=ToolParameterType.STRING,
                description="Tên thông số (VD: BOD5, PM2.5)",
                required=True
            ),
            ToolParameter(
                name="unit",
                type=ToolParameterType.STRING,
                description="Đơn vị đo",
                required=False,
                default="mg/L"
            ),
            ToolParameter(
                name="limit",
                type=ToolParameterType.NUMBER,
                description="Giới hạn QCVN để so sánh",
                required=False
            )
        ]
    
    def execute(
        self,
        data: List[float],
        parameter_name: str,
        unit: str = "mg/L",
        limit: float = None
    ) -> Dict:
        """Analyze environmental data."""
        import numpy as np
        
        if not data:
            return {"error": "Empty data array"}
        
        arr = np.array(data)
        
        # Basic statistics
        stats = {
            "count": len(arr),
            "mean": round(float(np.mean(arr)), 4),
            "median": round(float(np.median(arr)), 4),
            "std": round(float(np.std(arr)), 4),
            "min": round(float(np.min(arr)), 4),
            "max": round(float(np.max(arr)), 4),
            "percentile_25": round(float(np.percentile(arr, 25)), 4),
            "percentile_75": round(float(np.percentile(arr, 75)), 4),
            "percentile_95": round(float(np.percentile(arr, 95)), 4)
        }
        
        # Detect outliers (IQR method)
        q1 = np.percentile(arr, 25)
        q3 = np.percentile(arr, 75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        outliers = arr[(arr < lower_bound) | (arr > upper_bound)]
        
        result = {
            "parameter": parameter_name,
            "unit": unit,
            "statistics": stats,
            "outliers": {
                "count": len(outliers),
                "values": [round(float(v), 4) for v in outliers],
                "lower_bound": round(float(lower_bound), 4),
                "upper_bound": round(float(upper_bound), 4)
            }
        }
        
        # Compare with limit if provided
        if limit is not None:
            exceedances = arr[arr > limit]
            result["compliance"] = {
                "limit": limit,
                "exceedance_count": len(exceedances),
                "exceedance_rate": round(len(exceedances) / len(arr) * 100, 2),
                "max_exceedance": round(float(np.max(exceedances) - limit), 4) if len(exceedances) > 0 else 0
            }
        
        return result


# ==================== REPORT GENERATION ====================

class ReportGeneratorTool(BaseTool):
    """
    Tool for generating environmental compliance reports.
    """
    
    @property
    def name(self) -> str:
        return "generate_report"
    
    @property
    def description(self) -> str:
        return """Tạo báo cáo tuân thủ môi trường.
        
Hỗ trợ các loại báo cáo:
- compliance_summary: Tóm tắt tuân thủ
- detailed_analysis: Phân tích chi tiết
- trend_report: Báo cáo xu hướng
- recommendation: Khuyến nghị cải thiện"""
    
    @property
    def parameters(self) -> List[ToolParameter]:
        return [
            ToolParameter(
                name="report_type",
                type=ToolParameterType.STRING,
                description="Loại báo cáo",
                required=True,
                enum=["compliance_summary", "detailed_analysis", "trend_report", "recommendation"]
            ),
            ToolParameter(
                name="facility_name",
                type=ToolParameterType.STRING,
                description="Tên cơ sở/nhà máy",
                required=True
            ),
            ToolParameter(
                name="compliance_data",
                type=ToolParameterType.OBJECT,
                description="Dữ liệu tuân thủ (kết quả từ check_compliance)",
                required=True
            ),
            ToolParameter(
                name="period",
                type=ToolParameterType.STRING,
                description="Kỳ báo cáo (VD: Q1/2024, 01/2024)",
                required=False,
                default="Current"
            )
        ]
    
    def execute(
        self,
        report_type: str,
        facility_name: str,
        compliance_data: Dict,
        period: str = "Current"
    ) -> Dict:
        """Generate compliance report."""
        
        report = {
            "report_type": report_type,
            "facility_name": facility_name,
            "period": period,
            "generated_at": datetime.now().isoformat(),
            "content": {}
        }
        
        if report_type == "compliance_summary":
            report["content"] = self._generate_summary(compliance_data)
        elif report_type == "detailed_analysis":
            report["content"] = self._generate_detailed(compliance_data)
        elif report_type == "recommendation":
            report["content"] = self._generate_recommendations(compliance_data)
        
        return report
    
    def _generate_summary(self, data: Dict) -> Dict:
        """Generate compliance summary."""
        return {
            "title": "BÁO CÁO TÓM TẮT TUÂN THỦ MÔI TRƯỜNG",
            "overall_status": data.get("status", "N/A"),
            "parameters_checked": 1,
            "parameters_compliant": 1 if data.get("compliant") else 0,
            "parameters_non_compliant": 0 if data.get("compliant") else 1,
            "key_findings": [
                f"Thông số {data.get('parameter')}: {data.get('measured_value')} {data.get('unit')} - {data.get('status')}"
            ]
        }
    
    def _generate_detailed(self, data: Dict) -> Dict:
        """Generate detailed analysis."""
        return {
            "title": "BÁO CÁO PHÂN TÍCH CHI TIẾT",
            "sections": [
                {
                    "name": "Thông tin chung",
                    "content": {
                        "standard_applied": data.get("standard"),
                        "standard_description": data.get("standard_description"),
                        "column_applied": data.get("column_or_type")
                    }
                },
                {
                    "name": "Kết quả kiểm tra",
                    "content": {
                        "parameter": data.get("parameter"),
                        "measured_value": f"{data.get('measured_value')} {data.get('unit')}",
                        "limit": f"{data.get('limit')} {data.get('unit')}",
                        "status": data.get("status"),
                        "exceedance": f"{data.get('exceedance_percent')}%" if data.get('exceedance_percent') else "N/A"
                    }
                }
            ]
        }
    
    def _generate_recommendations(self, data: Dict) -> Dict:
        """Generate recommendations."""
        recommendations = []
        
        if not data.get("compliant"):
            recommendations.append({
                "priority": "HIGH",
                "issue": f"Thông số {data.get('parameter')} vượt quy chuẩn {data.get('exceedance_percent')}%",
                "recommendation": f"Cần xem xét nâng cấp hệ thống xử lý để đảm bảo {data.get('parameter')} đạt dưới {data.get('limit')} {data.get('unit')}",
                "timeline": "Immediate"
            })
        
        return {
            "title": "KHUYẾN NGHỊ CẢI THIỆN",
            "recommendations": recommendations,
            "next_steps": [
                "Kiểm tra lại hệ thống xử lý",
                "Tăng tần suất quan trắc",
                "Báo cáo cơ quan chức năng nếu cần"
            ]
        }
```

### Ngày 5-6: Tool Execution Engine

#### 3.1 Tool Execution Pipeline

```python
# ============================================
# TOOL EXECUTION ENGINE
# ============================================

from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field
from enum import Enum
import json
import asyncio
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class ToolCallStatus(Enum):
    """Status of tool call execution."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"

@dataclass
class ToolCall:
    """Represents a tool call from LLM."""
    id: str
    name: str
    arguments: Dict[str, Any]
    status: ToolCallStatus = ToolCallStatus.PENDING
    result: Optional[Any] = None
    error: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    
    @property
    def duration_ms(self) -> float:
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds() * 1000
        return 0

@dataclass
class ToolExecutionResult:
    """Result of tool execution pipeline."""
    tool_calls: List[ToolCall]
    total_duration_ms: float
    successful_count: int
    failed_count: int


class ToolExecutor:
    """
    Execute tools from LLM responses.
    
    Supports:
    - Sequential execution
    - Parallel execution
    - Error handling and retries
    - Timeout management
    """
    
    def __init__(
        self,
        registry: ToolRegistry,
        max_parallel: int = 5,
        timeout_seconds: int = 30,
        max_retries: int = 2
    ):
        self.registry = registry
        self.max_parallel = max_parallel
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries
    
    def parse_tool_calls(
        self,
        response: Dict,
        provider: str = "openai"
    ) -> List[ToolCall]:
        """
        Parse tool calls from LLM response.
        
        Args:
            response: Raw LLM response
            provider: 'openai' or 'anthropic'
        
        Returns:
            List of ToolCall objects
        """
        tool_calls = []
        
        if provider == "openai":
            # OpenAI format
            message = response.get("choices", [{}])[0].get("message", {})
            raw_calls = message.get("tool_calls", [])
            
            for call in raw_calls:
                tool_calls.append(ToolCall(
                    id=call.get("id"),
                    name=call.get("function", {}).get("name"),
                    arguments=json.loads(call.get("function", {}).get("arguments", "{}"))
                ))
        
        elif provider == "anthropic":
            # Anthropic format
            content = response.get("content", [])
            
            for item in content:
                if item.get("type") == "tool_use":
                    tool_calls.append(ToolCall(
                        id=item.get("id"),
                        name=item.get("name"),
                        arguments=item.get("input", {})
                    ))
        
        return tool_calls
    
    def execute_single(self, tool_call: ToolCall) -> ToolCall:
        """Execute a single tool call."""
        tool_call.status = ToolCallStatus.RUNNING
        tool_call.start_time = datetime.now()
        
        try:
            tool = self.registry.get(tool_call.name)
            
            if tool is None:
                raise ValueError(f"Unknown tool: {tool_call.name}")
            
            result = tool.execute(**tool_call.arguments)
            
            tool_call.result = result
            tool_call.status = ToolCallStatus.SUCCESS
            
        except Exception as e:
            logger.error(f"Tool execution failed: {tool_call.name} - {str(e)}")
            tool_call.error = str(e)
            tool_call.status = ToolCallStatus.FAILED
        
        finally:
            tool_call.end_time = datetime.now()
        
        return tool_call
    
    def execute_sequential(
        self,
        tool_calls: List[ToolCall]
    ) -> ToolExecutionResult:
        """Execute tool calls sequentially."""
        start_time = datetime.now()
        
        for call in tool_calls:
            self.execute_single(call)
        
        end_time = datetime.now()
        total_duration = (end_time - start_time).total_seconds() * 1000
        
        return ToolExecutionResult(
            tool_calls=tool_calls,
            total_duration_ms=total_duration,
            successful_count=sum(1 for c in tool_calls if c.status == ToolCallStatus.SUCCESS),
            failed_count=sum(1 for c in tool_calls if c.status == ToolCallStatus.FAILED)
        )
    
    async def execute_parallel(
        self,
        tool_calls: List[ToolCall]
    ) -> ToolExecutionResult:
        """Execute tool calls in parallel."""
        start_time = datetime.now()
        
        semaphore = asyncio.Semaphore(self.max_parallel)
        
        async def execute_with_semaphore(call: ToolCall):
            async with semaphore:
                # Run sync execution in thread pool
                loop = asyncio.get_event_loop()
                return await loop.run_in_executor(
                    None, self.execute_single, call
                )
        
        await asyncio.gather(*[
            execute_with_semaphore(call) for call in tool_calls
        ])
        
        end_time = datetime.now()
        total_duration = (end_time - start_time).total_seconds() * 1000
        
        return ToolExecutionResult(
            tool_calls=tool_calls,
            total_duration_ms=total_duration,
            successful_count=sum(1 for c in tool_calls if c.status == ToolCallStatus.SUCCESS),
            failed_count=sum(1 for c in tool_calls if c.status == ToolCallStatus.FAILED)
        )
    
    def format_results_for_llm(
        self,
        tool_calls: List[ToolCall],
        provider: str = "openai"
    ) -> List[Dict]:
        """
        Format tool results for sending back to LLM.
        
        Args:
            tool_calls: Executed tool calls
            provider: 'openai' or 'anthropic'
        
        Returns:
            Formatted messages/content for LLM
        """
        messages = []
        
        if provider == "openai":
            for call in tool_calls:
                content = json.dumps(call.result, ensure_ascii=False) if call.result else call.error
                
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": content
                })
        
        elif provider == "anthropic":
            for call in tool_calls:
                content = call.result if call.result else {"error": call.error}
                
                messages.append({
                    "type": "tool_result",
                    "tool_use_id": call.id,
                    "content": json.dumps(content, ensure_ascii=False)
                })
        
        return messages


# ============================================
# TOOL-AUGMENTED LLM
# ============================================

class ToolAugmentedLLM:
    """
    LLM with integrated tool calling capability.
    """
    
    def __init__(
        self,
        llm_client,
        tool_registry: ToolRegistry,
        provider: str = "openai",
        max_iterations: int = 5
    ):
        self.llm = llm_client
        self.registry = tool_registry
        self.provider = provider
        self.max_iterations = max_iterations
        
        self.executor = ToolExecutor(registry)
    
    def chat(
        self,
        messages: List[Dict],
        tools_enabled: bool = True,
        parallel_tools: bool = True
    ) -> Dict:
        """
        Chat with tool calling support.
        
        Args:
            messages: Conversation messages
            tools_enabled: Enable tool calling
            parallel_tools: Execute tools in parallel
        
        Returns:
            Final response with tool usage info
        """
        iteration = 0
        all_tool_calls = []
        
        # Get tool schemas
        if tools_enabled:
            if self.provider == "openai":
                tools = self.registry.get_openai_tools()
            else:
                tools = self.registry.get_anthropic_tools()
        else:
            tools = None
        
        while iteration < self.max_iterations:
            iteration += 1
            
            # Call LLM
            if self.provider == "openai":
                response = self._call_openai(messages, tools)
            else:
                response = self._call_anthropic(messages, tools)
            
            # Check for tool calls
            tool_calls = self.executor.parse_tool_calls(response, self.provider)
            
            if not tool_calls:
                # No tool calls, return response
                return {
                    "response": self._extract_text(response),
                    "tool_calls": all_tool_calls,
                    "iterations": iteration
                }
            
            # Execute tools
            if parallel_tools:
                result = asyncio.run(self.executor.execute_parallel(tool_calls))
            else:
                result = self.executor.execute_sequential(tool_calls)
            
            all_tool_calls.extend(result.tool_calls)
            
            # Add tool results to messages
            if self.provider == "openai":
                # Add assistant message with tool calls
                messages.append({
                    "role": "assistant",
                    "tool_calls": [
                        {
                            "id": c.id,
                            "type": "function",
                            "function": {
                                "name": c.name,
                                "arguments": json.dumps(c.arguments)
                            }
                        }
                        for c in tool_calls
                    ]
                })
            
            # Add tool results
            tool_messages = self.executor.format_results_for_llm(
                result.tool_calls, self.provider
            )
            messages.extend(tool_messages)
        
        # Max iterations reached
        return {
            "response": "Maximum iterations reached",
            "tool_calls": all_tool_calls,
            "iterations": iteration,
            "warning": "max_iterations_reached"
        }
    
    def _call_openai(self, messages: List[Dict], tools: List[Dict]) -> Dict:
        """Call OpenAI API."""
        kwargs = {
            "messages": messages,
            "model": "gpt-4-turbo-preview"
        }
        
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
        
        return self.llm.chat.completions.create(**kwargs).model_dump()
    
    def _call_anthropic(self, messages: List[Dict], tools: List[Dict]) -> Dict:
        """Call Anthropic API."""
        kwargs = {
            "messages": messages,
            "model": "claude-3-sonnet-20240229",
            "max_tokens": 4096
        }
        
        if tools:
            kwargs["tools"] = tools
        
        return self.llm.messages.create(**kwargs).model_dump()
    
    def _extract_text(self, response: Dict) -> str:
        """Extract text content from response."""
        if self.provider == "openai":
            return response.get("choices", [{}])[0].get("message", {}).get("content", "")
        else:
            content = response.get("content", [])
            texts = [c.get("text", "") for c in content if c.get("type") == "text"]
            return "\n".join(texts)


# ============================================
# ENVIRONMENTAL COMPLIANCE ASSISTANT
# ============================================

class EnvironmentalComplianceAssistant:
    """
    AI Assistant for environmental compliance with tool capabilities.
    """
    
    SYSTEM_PROMPT = """Bạn là trợ lý chuyên gia về tuân thủ môi trường Việt Nam.

Bạn có các công cụ sau:
1. check_compliance: Kiểm tra tuân thủ quy chuẩn QCVN
2. search_regulations: Tìm kiếm văn bản quy định môi trường
3. analyze_environmental_data: Phân tích dữ liệu quan trắc
4. generate_report: Tạo báo cáo tuân thủ

Hãy sử dụng các công cụ phù hợp để trả lời câu hỏi của người dùng.
Luôn trích dẫn nguồn văn bản pháp luật khi có thể.
Trả lời bằng tiếng Việt."""
    
    def __init__(
        self,
        llm_client,
        vector_store,
        provider: str = "openai"
    ):
        # Initialize tools
        self.registry = ToolRegistry()
        
        # Register tools
        self.registry.register(ComplianceCheckerTool())
        self.registry.register(RegulationSearchTool(vector_store))
        self.registry.register(EnvironmentalDataAnalysisTool())
        self.registry.register(ReportGeneratorTool())
        
        # Initialize tool-augmented LLM
        self.assistant = ToolAugmentedLLM(
            llm_client=llm_client,
            tool_registry=self.registry,
            provider=provider
        )
        
        self.conversation_history = []
    
    def chat(self, user_message: str) -> Dict:
        """
        Chat with the assistant.
        
        Args:
            user_message: User's question or request
        
        Returns:
            Response with answer and tool usage info
        """
        # Build messages
        messages = [
            {"role": "system", "content": self.SYSTEM_PROMPT}
        ]
        messages.extend(self.conversation_history)
        messages.append({"role": "user", "content": user_message})
        
        # Get response
        result = self.assistant.chat(messages)
        
        # Update history
        self.conversation_history.append(
            {"role": "user", "content": user_message}
        )
        self.conversation_history.append(
            {"role": "assistant", "content": result["response"]}
        )
        
        return result
    
    def reset_conversation(self):
        """Reset conversation history."""
        self.conversation_history = []


# Usage example
if __name__ == "__main__":
    # Example usage (pseudo-code)
    """
    from openai import OpenAI
    
    # Initialize
    client = OpenAI()
    vector_store = EnvironmentalRegulationDB(...)
    
    assistant = EnvironmentalComplianceAssistant(
        llm_client=client,
        vector_store=vector_store,
        provider="openai"
    )
    
    # Chat
    response = assistant.chat(
        "Kiểm tra xem nồng độ BOD5 = 45 mg/L có đạt QCVN 40:2011 cột B không?"
    )
    
    print(response["response"])
    print(f"Tools used: {len(response['tool_calls'])}")
    """
    pass
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Tool Definition Framework (Ngày 1-2)

```
🎯 Mục tiêu: Build tool definition framework

📋 Yêu cầu:
1. Implement ToolDefinition với JSON Schema
2. Support OpenAI và Anthropic formats
3. Create @tool decorator
4. Build ToolRegistry

📁 Deliverables:
- src/tools/framework.py
- src/tools/registry.py
- tests/test_tools.py
```

### Bài tập 2: Environmental Tools (Ngày 3-4)

```
🎯 Mục tiêu: Build domain-specific tools

📋 Yêu cầu:
1. Implement ComplianceCheckerTool
2. Implement RegulationSearchTool
3. Implement DataAnalysisTool
4. Implement ReportGeneratorTool

📁 Deliverables:
- src/tools/compliance.py
- src/tools/search.py
- src/tools/analysis.py
- src/tools/reports.py
```

### Bài tập 3: Tool Execution Engine (Ngày 5-7)

```
🎯 Mục tiêu: Build complete tool execution system

📋 Yêu cầu:
1. Implement ToolExecutor với parallel support
2. Build ToolAugmentedLLM
3. Create EnvironmentalComplianceAssistant
4. Add comprehensive error handling

📁 Deliverables:
- src/execution/executor.py
- src/assistants/compliance_assistant.py
- Demo notebook
- **PROJECT 2 Complete**: Environmental Compliance RAG + Tools
```

---

## ✅ CHECKLIST TUẦN 8

### Kiến thức đã học
- [ ] Function calling APIs (OpenAI, Anthropic)
- [ ] Tool definition với JSON Schema
- [ ] Tool execution patterns
- [ ] ReAct và tool orchestration
- [ ] Error handling strategies

### Skills thực hành
- [ ] Define tools với schemas
- [ ] Build domain-specific tools
- [ ] Implement parallel execution
- [ ] Handle tool errors gracefully

### Deliverables
- [ ] Tool definition framework
- [ ] Environmental domain tools
- [ ] Tool execution engine
- [ ] Compliance assistant
- [ ] **PROJECT 2 Complete**: RAG + Tool System

---

## 🎉 TỔNG KẾT GIAI ĐOẠN INTERMEDIATE

### Những gì đã học được (Tuần 5-8)

| Tuần | Chủ đề | Output |
|------|--------|--------|
| 5 | RAG Architecture | Advanced RAG với query transformation |
| 6 | LangChain & LlamaIndex | Framework comparison và selection |
| 7 | Production Optimization | Caching, batching, monitoring |
| 8 | Function Calling | Tool-augmented assistant |

### PROJECT 2: Environmental Compliance RAG System

**Features hoàn thành:**
- ✅ Advanced RAG với HyDE, multi-query
- ✅ Hybrid search (semantic + BM25)
- ✅ Semantic caching
- ✅ Production monitoring
- ✅ Compliance checking tools
- ✅ Tool-augmented assistant

**Tech Stack bổ sung:**
- LangChain / LlamaIndex
- Redis (caching)
- Cohere (reranking)
- Prometheus (monitoring)

### Chuẩn bị cho Phase 3 (Advanced)

Tuần 9-12 sẽ cover:
- Multi-Agent Systems (LangGraph)
- Document Generation
- Testing & Deployment
- Capstone Project

---

*Hoàn thành Phase 2 Intermediate! Tiếp tục sang Phase 3: Advanced*
