# 📅 TUẦN 5: RAG ARCHITECTURE DEEP DIVE

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Thành thạo RAG architecture và advanced retrieval strategies |
| **Output** | Production-ready RAG system cho Environmental Compliance |
| **Độ khó** | ⭐⭐⭐⭐ Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu sâu RAG architecture và các components
- [ ] Nắm vững retrieval strategies (dense, sparse, hybrid)
- [ ] Hiểu reranking và relevance optimization
- [ ] Biết các RAG patterns (naive, advanced, modular)

### Kỹ năng (Skills)
- [ ] Implement multi-stage retrieval pipelines
- [ ] Build query transformation techniques
- [ ] Implement contextual compression
- [ ] Evaluate RAG systems với RAGAS

### Ứng dụng (Application)
- [ ] Xây dựng Environmental Compliance RAG System
- [ ] Multi-query retrieval cho legal documents
- [ ] Citation và source tracking

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: RAG Architecture Fundamentals

#### 1.1 RAG Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    RETRIEVAL-AUGMENTED GENERATION (RAG)                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                         INDEXING PIPELINE                            │    │
│  │                                                                      │    │
│  │  Documents → Chunking → Embedding → Vector Store                    │    │
│  │      │           │           │            │                         │    │
│  │      ▼           ▼           ▼            ▼                         │    │
│  │  [PDF,DOCX]  [Semantic]  [OpenAI]   [ChromaDB]                     │    │
│  │  [HTML,TXT]  [Article]   [BGE-M3]   [Pinecone]                     │    │
│  │              [Fixed]     [Cohere]   [Qdrant]                       │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                         RETRIEVAL PIPELINE                           │    │
│  │                                                                      │    │
│  │  Query → Query Transform → Retrieve → Rerank → Context              │    │
│  │    │           │              │          │          │               │    │
│  │    ▼           ▼              ▼          ▼          ▼               │    │
│  │  [User]   [HyDE/Multi]   [Top-K]   [Cohere]   [Compressed]         │    │
│  │  [Input]  [Decompose]    [Hybrid]  [Cross]    [Relevant]           │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                        GENERATION PIPELINE                           │    │
│  │                                                                      │    │
│  │  Context + Query → Prompt → LLM → Response → Post-process           │    │
│  │       │              │        │        │           │                │    │
│  │       ▼              ▼        ▼        ▼           ▼                │    │
│  │  [Retrieved]    [Template] [GPT-4]  [Answer]  [Citation]           │    │
│  │  [Documents]    [Few-shot] [Claude] [+Source] [Validation]         │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 RAG Patterns

```python
# ============================================
# RAG PATTERNS & ARCHITECTURES
# ============================================

from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
import numpy as np

class RAGPattern(Enum):
    """Different RAG architectural patterns."""
    NAIVE = "naive"                    # Simple retrieve + generate
    SENTENCE_WINDOW = "sentence_window" # Retrieve sentence, expand context
    AUTO_MERGING = "auto_merging"      # Hierarchical chunks with merging
    FUSION = "fusion"                  # Multiple queries + fusion
    CORRECTIVE = "corrective"          # Self-correcting retrieval
    SELF_RAG = "self_rag"             # Self-reflective generation
    GRAPH_RAG = "graph_rag"           # Knowledge graph enhanced

@dataclass
class RetrievedDocument:
    """Retrieved document with metadata."""
    id: str
    content: str
    score: float
    metadata: Dict[str, Any]
    embedding: Optional[np.ndarray] = None

@dataclass
class RAGContext:
    """Context for RAG generation."""
    query: str
    documents: List[RetrievedDocument]
    reranked: bool = False
    compressed: bool = False
    total_tokens: int = 0

@dataclass
class RAGResponse:
    """RAG system response."""
    answer: str
    sources: List[Dict]
    context_used: int
    retrieval_score: float
    generation_tokens: int
    metadata: Dict[str, Any] = field(default_factory=dict)


class BaseRAGSystem(ABC):
    """Abstract base class for RAG systems."""
    
    @abstractmethod
    def index(self, documents: List[Dict]) -> int:
        """Index documents into the system."""
        pass
    
    @abstractmethod
    def retrieve(self, query: str, top_k: int = 5) -> List[RetrievedDocument]:
        """Retrieve relevant documents."""
        pass
    
    @abstractmethod
    def generate(self, query: str, context: RAGContext) -> RAGResponse:
        """Generate answer from context."""
        pass
    
    def query(self, query: str, top_k: int = 5) -> RAGResponse:
        """End-to-end RAG query."""
        documents = self.retrieve(query, top_k)
        context = RAGContext(query=query, documents=documents)
        return self.generate(query, context)


# ============================================
# NAIVE RAG IMPLEMENTATION
# ============================================

class NaiveRAG(BaseRAGSystem):
    """
    Simple RAG implementation.
    
    Flow: Query → Embed → Retrieve → Concatenate → Generate
    
    Pros:
    - Simple to implement
    - Fast
    - Good baseline
    
    Cons:
    - No query transformation
    - May retrieve irrelevant chunks
    - No context optimization
    """
    
    def __init__(
        self,
        vector_store,
        embedding_model,
        llm_client,
        chunk_size: int = 1000,
        chunk_overlap: int = 200
    ):
        self.vector_store = vector_store
        self.embedding_model = embedding_model
        self.llm = llm_client
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
    
    def index(self, documents: List[Dict]) -> int:
        """Index documents with simple chunking."""
        from langchain.text_splitter import RecursiveCharacterTextSplitter
        
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            separators=["\n\n", "\n", ".", " "]
        )
        
        chunks = []
        for doc in documents:
            doc_chunks = splitter.split_text(doc['content'])
            for i, chunk in enumerate(doc_chunks):
                chunks.append({
                    'content': chunk,
                    'metadata': {
                        **doc.get('metadata', {}),
                        'chunk_index': i,
                        'source_id': doc.get('id', '')
                    }
                })
        
        # Add to vector store
        self.vector_store.add_documents(chunks)
        
        return len(chunks)
    
    def retrieve(self, query: str, top_k: int = 5) -> List[RetrievedDocument]:
        """Simple semantic retrieval."""
        results = self.vector_store.search(query, n_results=top_k)
        
        return [
            RetrievedDocument(
                id=r.id,
                content=r.content,
                score=r.score,
                metadata=r.metadata
            )
            for r in results
        ]
    
    def generate(self, query: str, context: RAGContext) -> RAGResponse:
        """Generate answer from retrieved context."""
        
        # Build context string
        context_str = "\n\n---\n\n".join([
            f"[Nguồn {i+1}] {doc.content}"
            for i, doc in enumerate(context.documents)
        ])
        
        prompt = f"""Dựa vào các tài liệu sau, hãy trả lời câu hỏi.

CONTEXT:
{context_str}

QUESTION: {query}

Yêu cầu:
1. Trả lời dựa trên thông tin trong context
2. Trích dẫn nguồn (số thứ tự tài liệu)
3. Nếu không có thông tin, nói rõ

ANSWER:"""
        
        response = self.llm.complete([
            {"role": "user", "content": prompt}
        ])
        
        return RAGResponse(
            answer=response.content,
            sources=[
                {"id": doc.id, "score": doc.score, "snippet": doc.content[:200]}
                for doc in context.documents
            ],
            context_used=len(context.documents),
            retrieval_score=np.mean([d.score for d in context.documents]),
            generation_tokens=response.total_tokens
        )


# ============================================
# ADVANCED RAG WITH QUERY TRANSFORMATION
# ============================================

class AdvancedRAG(BaseRAGSystem):
    """
    Advanced RAG with query transformation and reranking.
    
    Features:
    - Query decomposition
    - HyDE (Hypothetical Document Embedding)
    - Multi-query retrieval
    - Reranking
    - Contextual compression
    """
    
    def __init__(
        self,
        vector_store,
        embedding_model,
        llm_client,
        reranker=None,
        use_hyde: bool = True,
        use_multi_query: bool = True,
        use_rerank: bool = True,
        use_compression: bool = True
    ):
        self.vector_store = vector_store
        self.embedding_model = embedding_model
        self.llm = llm_client
        self.reranker = reranker
        
        self.use_hyde = use_hyde
        self.use_multi_query = use_multi_query
        self.use_rerank = use_rerank
        self.use_compression = use_compression
    
    def index(self, documents: List[Dict]) -> int:
        """Index with metadata enrichment."""
        # Implementation similar to NaiveRAG but with metadata enrichment
        pass
    
    # ==================== QUERY TRANSFORMATION ====================
    
    def _generate_hyde_document(self, query: str) -> str:
        """
        HyDE: Generate hypothetical document that would answer the query.
        Then use this document for retrieval.
        """
        prompt = f"""Bạn là chuyên gia về quy định môi trường Việt Nam.
Hãy viết một đoạn văn bản (khoảng 100-200 từ) trả lời câu hỏi sau như thể bạn đang trích từ một văn bản pháp luật chính thức.

Câu hỏi: {query}

Văn bản:"""
        
        response = self.llm.complete([{"role": "user", "content": prompt}])
        return response.content
    
    def _generate_multi_queries(self, query: str, n_queries: int = 3) -> List[str]:
        """
        Generate multiple query variations to improve recall.
        """
        prompt = f"""Tạo {n_queries} câu hỏi khác nhau nhưng cùng ý nghĩa với câu hỏi gốc.
Mỗi câu hỏi nên sử dụng từ ngữ và cách diễn đạt khác nhau.

Câu hỏi gốc: {query}

Trả về dạng:
1. [câu hỏi 1]
2. [câu hỏi 2]
3. [câu hỏi 3]

Các câu hỏi:"""
        
        response = self.llm.complete([{"role": "user", "content": prompt}])
        
        # Parse response
        queries = [query]  # Include original
        for line in response.content.strip().split('\n'):
            line = line.strip()
            if line and line[0].isdigit():
                # Remove numbering
                q = line.split('.', 1)[-1].strip()
                if q:
                    queries.append(q)
        
        return queries[:n_queries + 1]
    
    def _decompose_query(self, query: str) -> List[str]:
        """
        Decompose complex query into sub-queries.
        """
        prompt = f"""Phân tích câu hỏi sau và chia thành các câu hỏi con đơn giản hơn.
Nếu câu hỏi đã đủ đơn giản, chỉ trả về câu hỏi gốc.

Câu hỏi: {query}

Các câu hỏi con (mỗi câu một dòng):"""
        
        response = self.llm.complete([{"role": "user", "content": prompt}])
        
        sub_queries = []
        for line in response.content.strip().split('\n'):
            line = line.strip()
            if line and not line.startswith('-'):
                # Remove bullet points or numbering
                if line[0].isdigit():
                    line = line.split('.', 1)[-1].strip()
                if line.startswith('- '):
                    line = line[2:]
                if line:
                    sub_queries.append(line)
        
        return sub_queries if sub_queries else [query]
    
    # ==================== RETRIEVAL ====================
    
    def retrieve(
        self, 
        query: str, 
        top_k: int = 5,
        expand_k: int = 10
    ) -> List[RetrievedDocument]:
        """
        Advanced retrieval with query transformation.
        
        Steps:
        1. Transform query (HyDE / Multi-query)
        2. Retrieve for each query variant
        3. Reciprocal Rank Fusion
        4. Rerank
        5. Return top-k
        """
        all_results = []
        
        # Step 1: Query transformation
        queries_to_search = [query]
        
        if self.use_hyde:
            hyde_doc = self._generate_hyde_document(query)
            queries_to_search.append(hyde_doc)
        
        if self.use_multi_query:
            multi_queries = self._generate_multi_queries(query, n_queries=2)
            queries_to_search.extend(multi_queries[1:])  # Skip original
        
        # Step 2: Retrieve for each query
        for q in queries_to_search:
            results = self.vector_store.search(q, n_results=expand_k)
            all_results.append(results)
        
        # Step 3: Reciprocal Rank Fusion
        fused = self._reciprocal_rank_fusion(all_results)
        
        # Step 4: Rerank
        if self.use_rerank and self.reranker:
            fused = self._rerank(query, fused[:expand_k])
        
        # Convert to RetrievedDocument
        documents = [
            RetrievedDocument(
                id=r.id,
                content=r.content,
                score=r.score,
                metadata=r.metadata
            )
            for r in fused[:top_k]
        ]
        
        return documents
    
    def _reciprocal_rank_fusion(
        self, 
        result_lists: List[List],
        k: int = 60
    ) -> List:
        """
        Combine results from multiple queries using RRF.
        
        RRF score = Σ 1 / (k + rank)
        """
        scores = {}
        doc_map = {}
        
        for results in result_lists:
            for rank, doc in enumerate(results):
                doc_id = doc.id
                
                if doc_id not in scores:
                    scores[doc_id] = 0
                    doc_map[doc_id] = doc
                
                scores[doc_id] += 1 / (k + rank + 1)
        
        # Sort by fused score
        sorted_ids = sorted(scores.keys(), key=lambda x: scores[x], reverse=True)
        
        # Update scores in documents
        fused_results = []
        for doc_id in sorted_ids:
            doc = doc_map[doc_id]
            doc.score = scores[doc_id]
            fused_results.append(doc)
        
        return fused_results
    
    def _rerank(
        self, 
        query: str, 
        documents: List
    ) -> List:
        """
        Rerank documents using cross-encoder or Cohere reranker.
        """
        if self.reranker is None:
            return documents
        
        # Rerank using Cohere or cross-encoder
        texts = [doc.content for doc in documents]
        rerank_results = self.reranker.rerank(query, texts)
        
        # Reorder documents
        reranked = []
        for result in rerank_results:
            idx = result['index']
            doc = documents[idx]
            doc.score = result['relevance_score']
            reranked.append(doc)
        
        return reranked
    
    # ==================== CONTEXT COMPRESSION ====================
    
    def _compress_context(
        self, 
        query: str, 
        documents: List[RetrievedDocument],
        max_tokens: int = 3000
    ) -> List[RetrievedDocument]:
        """
        Compress context to fit token limit while preserving relevance.
        """
        if not self.use_compression:
            return documents
        
        compressed = []
        
        for doc in documents:
            # Extract most relevant sentences
            prompt = f"""Trích xuất các câu/đoạn quan trọng nhất từ văn bản sau liên quan đến câu hỏi.
Giữ nguyên nội dung quan trọng, bỏ phần không liên quan.

Câu hỏi: {query}

Văn bản:
{doc.content}

Nội dung đã lọc:"""
            
            response = self.llm.complete([{"role": "user", "content": prompt}])
            
            compressed_doc = RetrievedDocument(
                id=doc.id,
                content=response.content,
                score=doc.score,
                metadata={**doc.metadata, "compressed": True}
            )
            compressed.append(compressed_doc)
        
        return compressed
    
    # ==================== GENERATION ====================
    
    def generate(self, query: str, context: RAGContext) -> RAGResponse:
        """Generate with chain-of-thought and citation."""
        
        # Optionally compress context
        documents = context.documents
        if self.use_compression:
            documents = self._compress_context(query, documents)
        
        # Build context with clear source markers
        context_parts = []
        for i, doc in enumerate(documents):
            source_info = f"[Nguồn {i+1}]"
            if doc.metadata.get('doc_number'):
                source_info += f" {doc.metadata['doc_number']}"
            if doc.metadata.get('article'):
                source_info += f" - {doc.metadata['article']}"
            
            context_parts.append(f"{source_info}\n{doc.content}")
        
        context_str = "\n\n---\n\n".join(context_parts)
        
        prompt = f"""Bạn là chuyên gia tư vấn pháp luật môi trường Việt Nam.

NGỮCẢNH TỪ CÁC VĂN BẢN PHÁP LUẬT:
{context_str}

CÂU HỎI: {query}

Hãy trả lời theo format sau:

## Phân tích
[Phân tích ngắn gọn vấn đề]

## Câu trả lời
[Trả lời chi tiết, trích dẫn nguồn bằng [Nguồn X]]

## Căn cứ pháp lý
[Liệt kê các văn bản/điều khoản đã sử dụng]

## Lưu ý
[Các lưu ý quan trọng nếu có]

TRẢ LỜI:"""
        
        response = self.llm.complete([{"role": "user", "content": prompt}])
        
        return RAGResponse(
            answer=response.content,
            sources=[
                {
                    "id": doc.id,
                    "score": doc.score,
                    "doc_number": doc.metadata.get('doc_number'),
                    "article": doc.metadata.get('article'),
                    "snippet": doc.content[:300]
                }
                for doc in documents
            ],
            context_used=len(documents),
            retrieval_score=np.mean([d.score for d in documents]),
            generation_tokens=response.total_tokens,
            metadata={
                "compressed": self.use_compression,
                "reranked": self.use_rerank,
                "hyde_used": self.use_hyde,
                "multi_query_used": self.use_multi_query
            }
        )


# ============================================
# COHERE RERANKER
# ============================================

class CohereReranker:
    """Cohere Reranking API wrapper."""
    
    def __init__(self, api_key: str, model: str = "rerank-multilingual-v3.0"):
        import cohere
        self.client = cohere.Client(api_key)
        self.model = model
    
    def rerank(
        self, 
        query: str, 
        documents: List[str],
        top_n: int = None
    ) -> List[Dict]:
        """
        Rerank documents using Cohere.
        
        Returns list of {index, relevance_score}
        """
        response = self.client.rerank(
            model=self.model,
            query=query,
            documents=documents,
            top_n=top_n or len(documents)
        )
        
        return [
            {
                "index": result.index,
                "relevance_score": result.relevance_score
            }
            for result in response.results
        ]


# Usage example
if __name__ == "__main__":
    # Example usage (pseudo-code)
    """
    # Initialize components
    vector_store = EnvironmentalRegulationDB(...)
    embedding_model = OpenAIEmbedding(...)
    llm = UnifiedLLMClient(...)
    reranker = CohereReranker(api_key="...")
    
    # Create Advanced RAG
    rag = AdvancedRAG(
        vector_store=vector_store,
        embedding_model=embedding_model,
        llm_client=llm,
        reranker=reranker,
        use_hyde=True,
        use_multi_query=True,
        use_rerank=True,
        use_compression=True
    )
    
    # Query
    response = rag.query(
        "Giới hạn xả thải BOD5 theo QCVN 40:2011 là bao nhiêu?",
        top_k=5
    )
    
    print(response.answer)
    print(f"Sources: {len(response.sources)}")
    """
    pass
```

### Ngày 3-4: Advanced Retrieval Strategies

#### 2.1 Hybrid Search Implementation

```python
# ============================================
# HYBRID SEARCH: DENSE + SPARSE RETRIEVAL
# ============================================

from typing import List, Dict, Tuple, Optional
import numpy as np
from dataclasses import dataclass
from rank_bm25 import BM25Okapi
import re

@dataclass
class HybridSearchResult:
    """Result from hybrid search."""
    id: str
    content: str
    dense_score: float
    sparse_score: float
    combined_score: float
    metadata: Dict

class HybridRetriever:
    """
    Hybrid retrieval combining dense (semantic) and sparse (BM25) search.
    
    Approaches:
    1. Linear combination: α * dense + (1-α) * sparse
    2. Reciprocal Rank Fusion (RRF)
    3. Learned combination
    """
    
    def __init__(
        self,
        vector_store,
        embedding_model,
        combination_method: str = "rrf",  # "linear", "rrf"
        alpha: float = 0.7,  # Weight for dense (only for linear)
        rrf_k: int = 60
    ):
        self.vector_store = vector_store
        self.embedding_model = embedding_model
        self.combination_method = combination_method
        self.alpha = alpha
        self.rrf_k = rrf_k
        
        # BM25 components
        self.bm25 = None
        self.corpus = []
        self.doc_ids = []
        self.doc_map = {}
    
    def build_sparse_index(self, documents: List[Dict]):
        """Build BM25 index for sparse retrieval."""
        
        self.corpus = []
        self.doc_ids = []
        self.doc_map = {}
        
        for doc in documents:
            doc_id = doc.get('id', str(len(self.doc_ids)))
            content = doc['content']
            
            # Tokenize for BM25 (Vietnamese-aware)
            tokens = self._tokenize(content)
            
            self.corpus.append(tokens)
            self.doc_ids.append(doc_id)
            self.doc_map[doc_id] = doc
        
        # Build BM25 index
        self.bm25 = BM25Okapi(self.corpus)
        
        print(f"Built BM25 index with {len(self.corpus)} documents")
    
    def _tokenize(self, text: str) -> List[str]:
        """
        Tokenize Vietnamese text for BM25.
        
        For better results, consider using underthesea word_tokenize.
        """
        # Simple tokenization
        text = text.lower()
        # Remove punctuation but keep Vietnamese characters
        text = re.sub(r'[^\w\sàáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ]', ' ', text)
        tokens = text.split()
        
        # Remove short tokens
        tokens = [t for t in tokens if len(t) > 1]
        
        return tokens
    
    def sparse_search(
        self, 
        query: str, 
        top_k: int = 10
    ) -> List[Tuple[str, float]]:
        """
        BM25 sparse search.
        
        Returns list of (doc_id, score) tuples.
        """
        if self.bm25 is None:
            raise ValueError("BM25 index not built. Call build_sparse_index first.")
        
        query_tokens = self._tokenize(query)
        scores = self.bm25.get_scores(query_tokens)
        
        # Get top-k
        top_indices = np.argsort(scores)[::-1][:top_k]
        
        results = [
            (self.doc_ids[i], scores[i])
            for i in top_indices
            if scores[i] > 0
        ]
        
        return results
    
    def dense_search(
        self, 
        query: str, 
        top_k: int = 10
    ) -> List[Tuple[str, float]]:
        """
        Dense (semantic) search using vector store.
        
        Returns list of (doc_id, score) tuples.
        """
        results = self.vector_store.search(query, n_results=top_k)
        
        return [(r.id, r.score) for r in results]
    
    def hybrid_search(
        self, 
        query: str, 
        top_k: int = 5,
        sparse_k: int = 20,
        dense_k: int = 20
    ) -> List[HybridSearchResult]:
        """
        Perform hybrid search combining dense and sparse.
        
        Args:
            query: Search query
            top_k: Number of results to return
            sparse_k: Number of sparse results to retrieve
            dense_k: Number of dense results to retrieve
        
        Returns:
            List of HybridSearchResult
        """
        # Get results from both methods
        sparse_results = self.sparse_search(query, top_k=sparse_k)
        dense_results = self.dense_search(query, top_k=dense_k)
        
        # Combine based on method
        if self.combination_method == "linear":
            combined = self._linear_combination(sparse_results, dense_results)
        elif self.combination_method == "rrf":
            combined = self._rrf_combination(sparse_results, dense_results)
        else:
            raise ValueError(f"Unknown combination method: {self.combination_method}")
        
        # Sort by combined score and return top-k
        combined.sort(key=lambda x: x.combined_score, reverse=True)
        
        return combined[:top_k]
    
    def _linear_combination(
        self,
        sparse_results: List[Tuple[str, float]],
        dense_results: List[Tuple[str, float]]
    ) -> List[HybridSearchResult]:
        """
        Linear combination: combined = α * dense + (1-α) * sparse
        
        Scores are normalized before combination.
        """
        # Normalize scores
        sparse_dict = self._normalize_scores(dict(sparse_results))
        dense_dict = self._normalize_scores(dict(dense_results))
        
        # Combine
        all_doc_ids = set(sparse_dict.keys()) | set(dense_dict.keys())
        
        results = []
        for doc_id in all_doc_ids:
            sparse_score = sparse_dict.get(doc_id, 0)
            dense_score = dense_dict.get(doc_id, 0)
            
            combined_score = self.alpha * dense_score + (1 - self.alpha) * sparse_score
            
            doc = self.doc_map.get(doc_id, {})
            
            results.append(HybridSearchResult(
                id=doc_id,
                content=doc.get('content', ''),
                dense_score=dense_score,
                sparse_score=sparse_score,
                combined_score=combined_score,
                metadata=doc.get('metadata', {})
            ))
        
        return results
    
    def _rrf_combination(
        self,
        sparse_results: List[Tuple[str, float]],
        dense_results: List[Tuple[str, float]]
    ) -> List[HybridSearchResult]:
        """
        Reciprocal Rank Fusion combination.
        
        RRF score = 1/(k + rank_sparse) + 1/(k + rank_dense)
        """
        # Build rank dictionaries
        sparse_ranks = {doc_id: rank for rank, (doc_id, _) in enumerate(sparse_results)}
        dense_ranks = {doc_id: rank for rank, (doc_id, _) in enumerate(dense_results)}
        
        # Get original scores
        sparse_scores = dict(sparse_results)
        dense_scores = dict(dense_results)
        
        all_doc_ids = set(sparse_ranks.keys()) | set(dense_ranks.keys())
        
        results = []
        for doc_id in all_doc_ids:
            sparse_rank = sparse_ranks.get(doc_id, 1000)  # Default high rank if not found
            dense_rank = dense_ranks.get(doc_id, 1000)
            
            rrf_score = (
                1 / (self.rrf_k + sparse_rank) +
                1 / (self.rrf_k + dense_rank)
            )
            
            doc = self.doc_map.get(doc_id, {})
            
            results.append(HybridSearchResult(
                id=doc_id,
                content=doc.get('content', ''),
                dense_score=dense_scores.get(doc_id, 0),
                sparse_score=sparse_scores.get(doc_id, 0),
                combined_score=rrf_score,
                metadata=doc.get('metadata', {})
            ))
        
        return results
    
    def _normalize_scores(self, scores: Dict[str, float]) -> Dict[str, float]:
        """Normalize scores to [0, 1] range."""
        if not scores:
            return scores
        
        values = list(scores.values())
        min_val = min(values)
        max_val = max(values)
        
        if max_val == min_val:
            return {k: 1.0 for k in scores}
        
        return {
            k: (v - min_val) / (max_val - min_val)
            for k, v in scores.items()
        }


# ============================================
# SENTENCE WINDOW RETRIEVAL
# ============================================

class SentenceWindowRetriever:
    """
    Sentence Window Retrieval:
    - Index individual sentences
    - Retrieve matching sentences
    - Expand to surrounding context (window)
    
    Benefits:
    - Better matching precision
    - Contextual expansion for generation
    """
    
    def __init__(
        self,
        vector_store,
        embedding_model,
        window_size: int = 3  # Sentences before and after
    ):
        self.vector_store = vector_store
        self.embedding_model = embedding_model
        self.window_size = window_size
        
        # Store original documents for context expansion
        self.documents = {}
        self.sentence_to_doc = {}
    
    def index(self, documents: List[Dict]) -> int:
        """
        Index documents by sentences with context tracking.
        """
        import re
        
        sentence_count = 0
        
        for doc in documents:
            doc_id = doc.get('id', str(len(self.documents)))
            content = doc['content']
            metadata = doc.get('metadata', {})
            
            # Store original document
            self.documents[doc_id] = doc
            
            # Split into sentences (Vietnamese-aware)
            sentences = self._split_sentences(content)
            
            # Index each sentence
            for i, sentence in enumerate(sentences):
                if len(sentence.strip()) < 10:  # Skip very short sentences
                    continue
                
                sentence_id = f"{doc_id}_s{i}"
                
                # Store mapping
                self.sentence_to_doc[sentence_id] = {
                    'doc_id': doc_id,
                    'sentence_index': i,
                    'total_sentences': len(sentences)
                }
                
                # Add to vector store
                self.vector_store.add_document(
                    content=sentence,
                    metadata={
                        **metadata,
                        'sentence_id': sentence_id,
                        'sentence_index': i,
                        'source_doc_id': doc_id
                    },
                    doc_id=sentence_id
                )
                
                sentence_count += 1
        
        return sentence_count
    
    def _split_sentences(self, text: str) -> List[str]:
        """Split text into sentences (Vietnamese-aware)."""
        import re
        
        # Vietnamese sentence endings
        sentence_pattern = r'(?<=[.!?])\s+(?=[A-ZÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐ])'
        
        sentences = re.split(sentence_pattern, text)
        
        # Clean up
        sentences = [s.strip() for s in sentences if s.strip()]
        
        return sentences
    
    def retrieve(
        self, 
        query: str, 
        top_k: int = 5
    ) -> List[Dict]:
        """
        Retrieve sentences and expand to window context.
        """
        # Search for matching sentences
        results = self.vector_store.search(query, n_results=top_k * 2)
        
        expanded_results = []
        seen_windows = set()
        
        for result in results:
            sentence_id = result.id
            
            if sentence_id not in self.sentence_to_doc:
                continue
            
            mapping = self.sentence_to_doc[sentence_id]
            doc_id = mapping['doc_id']
            sentence_idx = mapping['sentence_index']
            total_sentences = mapping['total_sentences']
            
            # Calculate window
            start_idx = max(0, sentence_idx - self.window_size)
            end_idx = min(total_sentences, sentence_idx + self.window_size + 1)
            
            # Create window key to avoid duplicates
            window_key = f"{doc_id}_{start_idx}_{end_idx}"
            if window_key in seen_windows:
                continue
            seen_windows.add(window_key)
            
            # Get original document and extract window
            doc = self.documents[doc_id]
            sentences = self._split_sentences(doc['content'])
            
            window_text = ' '.join(sentences[start_idx:end_idx])
            
            expanded_results.append({
                'id': result.id,
                'matched_sentence': result.content,
                'expanded_context': window_text,
                'score': result.score,
                'metadata': {
                    **doc.get('metadata', {}),
                    'sentence_index': sentence_idx,
                    'window_start': start_idx,
                    'window_end': end_idx
                }
            })
            
            if len(expanded_results) >= top_k:
                break
        
        return expanded_results


# ============================================
# PARENT DOCUMENT RETRIEVER
# ============================================

class ParentDocumentRetriever:
    """
    Parent Document Retriever:
    - Index small chunks for precise matching
    - Return parent (larger) chunks for context
    
    Similar to sentence window but with document hierarchy.
    """
    
    def __init__(
        self,
        vector_store,
        embedding_model,
        child_chunk_size: int = 200,
        parent_chunk_size: int = 1000
    ):
        self.vector_store = vector_store
        self.embedding_model = embedding_model
        self.child_chunk_size = child_chunk_size
        self.parent_chunk_size = parent_chunk_size
        
        # Store parent chunks
        self.parent_chunks = {}
        self.child_to_parent = {}
    
    def index(self, documents: List[Dict]) -> int:
        """
        Create hierarchical index:
        1. Split into parent chunks
        2. Split parents into child chunks
        3. Index child chunks with parent reference
        """
        from langchain.text_splitter import RecursiveCharacterTextSplitter
        
        parent_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.parent_chunk_size,
            chunk_overlap=100
        )
        
        child_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.child_chunk_size,
            chunk_overlap=50
        )
        
        child_count = 0
        
        for doc in documents:
            doc_id = doc.get('id', str(len(self.parent_chunks)))
            content = doc['content']
            metadata = doc.get('metadata', {})
            
            # Create parent chunks
            parent_texts = parent_splitter.split_text(content)
            
            for p_idx, parent_text in enumerate(parent_texts):
                parent_id = f"{doc_id}_p{p_idx}"
                
                # Store parent chunk
                self.parent_chunks[parent_id] = {
                    'content': parent_text,
                    'metadata': {
                        **metadata,
                        'parent_index': p_idx,
                        'source_doc_id': doc_id
                    }
                }
                
                # Create and index child chunks
                child_texts = child_splitter.split_text(parent_text)
                
                for c_idx, child_text in enumerate(child_texts):
                    child_id = f"{parent_id}_c{c_idx}"
                    
                    # Map child to parent
                    self.child_to_parent[child_id] = parent_id
                    
                    # Index child chunk
                    self.vector_store.add_document(
                        content=child_text,
                        metadata={
                            **metadata,
                            'child_id': child_id,
                            'parent_id': parent_id,
                            'child_index': c_idx
                        },
                        doc_id=child_id
                    )
                    
                    child_count += 1
        
        return child_count
    
    def retrieve(
        self, 
        query: str, 
        top_k: int = 5
    ) -> List[Dict]:
        """
        Retrieve matching child chunks, return parent chunks.
        """
        # Search child chunks
        results = self.vector_store.search(query, n_results=top_k * 3)
        
        parent_results = []
        seen_parents = set()
        
        for result in results:
            child_id = result.id
            
            if child_id not in self.child_to_parent:
                continue
            
            parent_id = self.child_to_parent[child_id]
            
            if parent_id in seen_parents:
                continue
            seen_parents.add(parent_id)
            
            parent = self.parent_chunks[parent_id]
            
            parent_results.append({
                'id': parent_id,
                'content': parent['content'],
                'matched_child': result.content,
                'child_score': result.score,
                'metadata': parent['metadata']
            })
            
            if len(parent_results) >= top_k:
                break
        
        return parent_results
```

### Ngày 5-6: RAG Evaluation

#### 3.1 RAGAS Evaluation Framework

```python
# ============================================
# RAG EVALUATION WITH RAGAS
# ============================================

from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import numpy as np
from enum import Enum

class RAGMetric(Enum):
    """RAG evaluation metrics."""
    FAITHFULNESS = "faithfulness"
    ANSWER_RELEVANCY = "answer_relevancy"
    CONTEXT_PRECISION = "context_precision"
    CONTEXT_RECALL = "context_recall"
    CONTEXT_RELEVANCY = "context_relevancy"
    ANSWER_CORRECTNESS = "answer_correctness"

@dataclass
class RAGEvaluationResult:
    """Result of RAG evaluation."""
    query: str
    answer: str
    contexts: List[str]
    ground_truth: Optional[str]
    metrics: Dict[str, float]
    details: Dict[str, any]

class RAGEvaluator:
    """
    Comprehensive RAG evaluation system.
    
    Metrics:
    1. Faithfulness: Is the answer grounded in the context?
    2. Answer Relevancy: Does the answer address the question?
    3. Context Precision: Are retrieved contexts relevant?
    4. Context Recall: Are all relevant contexts retrieved?
    5. Answer Correctness: Is the answer correct?
    """
    
    def __init__(self, llm_client, embedding_model):
        self.llm = llm_client
        self.embedding = embedding_model
    
    def evaluate(
        self,
        query: str,
        answer: str,
        contexts: List[str],
        ground_truth: Optional[str] = None,
        metrics: List[RAGMetric] = None
    ) -> RAGEvaluationResult:
        """
        Evaluate RAG response.
        
        Args:
            query: User query
            answer: Generated answer
            contexts: Retrieved contexts used for generation
            ground_truth: Expected answer (optional)
            metrics: Metrics to compute (default: all)
        
        Returns:
            RAGEvaluationResult with all metrics
        """
        if metrics is None:
            metrics = list(RAGMetric)
        
        results = {}
        details = {}
        
        for metric in metrics:
            if metric == RAGMetric.FAITHFULNESS:
                score, detail = self._evaluate_faithfulness(answer, contexts)
            elif metric == RAGMetric.ANSWER_RELEVANCY:
                score, detail = self._evaluate_answer_relevancy(query, answer)
            elif metric == RAGMetric.CONTEXT_PRECISION:
                score, detail = self._evaluate_context_precision(query, contexts)
            elif metric == RAGMetric.CONTEXT_RECALL:
                if ground_truth:
                    score, detail = self._evaluate_context_recall(ground_truth, contexts)
                else:
                    score, detail = None, "Ground truth required"
            elif metric == RAGMetric.CONTEXT_RELEVANCY:
                score, detail = self._evaluate_context_relevancy(query, contexts)
            elif metric == RAGMetric.ANSWER_CORRECTNESS:
                if ground_truth:
                    score, detail = self._evaluate_answer_correctness(answer, ground_truth)
                else:
                    score, detail = None, "Ground truth required"
            
            results[metric.value] = score
            details[metric.value] = detail
        
        return RAGEvaluationResult(
            query=query,
            answer=answer,
            contexts=contexts,
            ground_truth=ground_truth,
            metrics=results,
            details=details
        )
    
    def _evaluate_faithfulness(
        self, 
        answer: str, 
        contexts: List[str]
    ) -> Tuple[float, Dict]:
        """
        Evaluate if answer is grounded in context (no hallucination).
        
        Method:
        1. Extract claims from answer
        2. Check if each claim is supported by context
        3. Score = supported claims / total claims
        """
        # Step 1: Extract claims
        claims_prompt = f"""Trích xuất tất cả các tuyên bố/khẳng định từ câu trả lời sau.
Mỗi tuyên bố là một fact hoặc statement độc lập.

Câu trả lời:
{answer}

Liệt kê các tuyên bố (mỗi dòng một tuyên bố):"""
        
        claims_response = self.llm.complete([{"role": "user", "content": claims_prompt}])
        claims = [c.strip() for c in claims_response.content.strip().split('\n') if c.strip()]
        
        if not claims:
            return 1.0, {"claims": [], "supported": [], "unsupported": []}
        
        # Step 2: Check each claim against context
        context_str = "\n\n".join(contexts)
        
        supported = []
        unsupported = []
        
        for claim in claims:
            check_prompt = f"""Kiểm tra xem tuyên bố sau có được hỗ trợ bởi ngữ cảnh không.

Ngữ cảnh:
{context_str}

Tuyên bố: {claim}

Trả lời CHỈ "CÓ" hoặc "KHÔNG":"""
            
            check_response = self.llm.complete([{"role": "user", "content": check_prompt}])
            
            if "CÓ" in check_response.content.upper():
                supported.append(claim)
            else:
                unsupported.append(claim)
        
        # Step 3: Calculate score
        score = len(supported) / len(claims)
        
        return score, {
            "claims": claims,
            "supported": supported,
            "unsupported": unsupported,
            "total_claims": len(claims),
            "supported_count": len(supported)
        }
    
    def _evaluate_answer_relevancy(
        self, 
        query: str, 
        answer: str
    ) -> Tuple[float, Dict]:
        """
        Evaluate if answer is relevant to the question.
        
        Method:
        1. Generate questions that the answer would address
        2. Compare generated questions with original query
        3. Score based on semantic similarity
        """
        # Generate questions from answer
        gen_prompt = f"""Dựa vào câu trả lời sau, tạo 3 câu hỏi mà câu trả lời này có thể trả lời.

Câu trả lời:
{answer}

3 câu hỏi (mỗi dòng một câu):"""
        
        gen_response = self.llm.complete([{"role": "user", "content": gen_prompt}])
        generated_questions = [q.strip() for q in gen_response.content.strip().split('\n') if q.strip()]
        
        if not generated_questions:
            return 0.0, {"generated_questions": [], "similarities": []}
        
        # Calculate semantic similarity
        query_embedding = self.embedding.embed(query)
        
        similarities = []
        for gen_q in generated_questions:
            gen_embedding = self.embedding.embed(gen_q)
            sim = np.dot(query_embedding, gen_embedding) / (
                np.linalg.norm(query_embedding) * np.linalg.norm(gen_embedding)
            )
            similarities.append(float(sim))
        
        score = np.mean(similarities)
        
        return score, {
            "generated_questions": generated_questions,
            "similarities": similarities,
            "original_query": query
        }
    
    def _evaluate_context_precision(
        self, 
        query: str, 
        contexts: List[str]
    ) -> Tuple[float, Dict]:
        """
        Evaluate precision of retrieved contexts.
        
        Method: Check if each context is relevant to the query.
        Score = relevant contexts / total contexts
        """
        relevant = []
        irrelevant = []
        
        for i, context in enumerate(contexts):
            check_prompt = f"""Đánh giá xem đoạn văn sau có liên quan đến câu hỏi không.

Câu hỏi: {query}

Đoạn văn:
{context}

Trả lời CHỈ "LIÊN QUAN" hoặc "KHÔNG LIÊN QUAN":"""
            
            response = self.llm.complete([{"role": "user", "content": check_prompt}])
            
            if "LIÊN QUAN" in response.content.upper() and "KHÔNG" not in response.content.upper():
                relevant.append(i)
            else:
                irrelevant.append(i)
        
        score = len(relevant) / len(contexts) if contexts else 0.0
        
        return score, {
            "relevant_indices": relevant,
            "irrelevant_indices": irrelevant,
            "total_contexts": len(contexts)
        }
    
    def _evaluate_context_recall(
        self, 
        ground_truth: str, 
        contexts: List[str]
    ) -> Tuple[float, Dict]:
        """
        Evaluate if contexts contain information needed for ground truth answer.
        
        Method:
        1. Extract key facts from ground truth
        2. Check if each fact is present in contexts
        """
        # Extract facts from ground truth
        facts_prompt = f"""Trích xuất các thông tin quan trọng từ câu trả lời chuẩn sau.

Câu trả lời chuẩn:
{ground_truth}

Các thông tin quan trọng (mỗi dòng một thông tin):"""
        
        facts_response = self.llm.complete([{"role": "user", "content": facts_prompt}])
        facts = [f.strip() for f in facts_response.content.strip().split('\n') if f.strip()]
        
        if not facts:
            return 1.0, {"facts": [], "found": [], "missing": []}
        
        # Check each fact in contexts
        context_str = "\n\n".join(contexts)
        
        found = []
        missing = []
        
        for fact in facts:
            check_prompt = f"""Kiểm tra xem thông tin sau có xuất hiện trong ngữ cảnh không.

Ngữ cảnh:
{context_str}

Thông tin cần tìm: {fact}

Trả lời CHỈ "CÓ" hoặc "KHÔNG":"""
            
            response = self.llm.complete([{"role": "user", "content": check_prompt}])
            
            if "CÓ" in response.content.upper():
                found.append(fact)
            else:
                missing.append(fact)
        
        score = len(found) / len(facts)
        
        return score, {
            "facts": facts,
            "found": found,
            "missing": missing
        }
    
    def _evaluate_context_relevancy(
        self, 
        query: str, 
        contexts: List[str]
    ) -> Tuple[float, Dict]:
        """
        Evaluate overall relevancy of contexts using embedding similarity.
        """
        query_embedding = self.embedding.embed(query)
        
        similarities = []
        for context in contexts:
            context_embedding = self.embedding.embed(context)
            sim = np.dot(query_embedding, context_embedding) / (
                np.linalg.norm(query_embedding) * np.linalg.norm(context_embedding)
            )
            similarities.append(float(sim))
        
        score = np.mean(similarities)
        
        return score, {
            "individual_scores": similarities,
            "min_score": min(similarities) if similarities else 0,
            "max_score": max(similarities) if similarities else 0
        }
    
    def _evaluate_answer_correctness(
        self, 
        answer: str, 
        ground_truth: str
    ) -> Tuple[float, Dict]:
        """
        Evaluate correctness of answer against ground truth.
        
        Combines:
        - Semantic similarity
        - Factual overlap
        """
        # Semantic similarity
        answer_embedding = self.embedding.embed(answer)
        truth_embedding = self.embedding.embed(ground_truth)
        
        semantic_sim = np.dot(answer_embedding, truth_embedding) / (
            np.linalg.norm(answer_embedding) * np.linalg.norm(truth_embedding)
        )
        
        # Factual correctness via LLM
        eval_prompt = f"""So sánh câu trả lời với câu trả lời chuẩn và đánh giá độ chính xác.

Câu trả lời chuẩn:
{ground_truth}

Câu trả lời cần đánh giá:
{answer}

Đánh giá theo thang điểm 0-10:
- 0-3: Sai hoàn toàn hoặc không liên quan
- 4-6: Đúng một phần, thiếu thông tin quan trọng
- 7-8: Đúng phần lớn, có thể thiếu chi tiết nhỏ
- 9-10: Hoàn toàn chính xác

Trả lời với format:
ĐIỂM: [0-10]
NHẬN XÉT: [nhận xét ngắn]"""
        
        eval_response = self.llm.complete([{"role": "user", "content": eval_prompt}])
        
        # Parse score
        try:
            score_line = [l for l in eval_response.content.split('\n') if 'ĐIỂM' in l][0]
            factual_score = int(''.join(filter(str.isdigit, score_line))) / 10
        except:
            factual_score = 0.5
        
        # Combine scores
        final_score = 0.4 * semantic_sim + 0.6 * factual_score
        
        return final_score, {
            "semantic_similarity": float(semantic_sim),
            "factual_score": factual_score,
            "llm_evaluation": eval_response.content
        }
    
    def evaluate_batch(
        self,
        test_cases: List[Dict],
        metrics: List[RAGMetric] = None
    ) -> Dict:
        """
        Evaluate multiple test cases and aggregate results.
        
        Args:
            test_cases: List of {query, answer, contexts, ground_truth}
            metrics: Metrics to compute
        
        Returns:
            Aggregated evaluation results
        """
        all_results = []
        
        for case in test_cases:
            result = self.evaluate(
                query=case['query'],
                answer=case['answer'],
                contexts=case['contexts'],
                ground_truth=case.get('ground_truth'),
                metrics=metrics
            )
            all_results.append(result)
        
        # Aggregate metrics
        aggregated = {}
        for metric in (metrics or list(RAGMetric)):
            scores = [r.metrics.get(metric.value) for r in all_results if r.metrics.get(metric.value) is not None]
            if scores:
                aggregated[metric.value] = {
                    "mean": np.mean(scores),
                    "std": np.std(scores),
                    "min": np.min(scores),
                    "max": np.max(scores)
                }
        
        return {
            "individual_results": all_results,
            "aggregated_metrics": aggregated,
            "total_cases": len(test_cases)
        }


# ============================================
# EVALUATION TEST DATASET
# ============================================

class EnvironmentalRAGTestDataset:
    """
    Test dataset for evaluating Environmental RAG system.
    """
    
    TEST_CASES = [
        {
            "query": "Giới hạn BOD5 trong nước thải công nghiệp theo QCVN 40:2011 là bao nhiêu?",
            "ground_truth": "Theo QCVN 40:2011/BTNMT, giới hạn BOD5 trong nước thải công nghiệp là 30 mg/L đối với cột A (xả vào nguồn nước dùng cho cấp nước sinh hoạt) và 50 mg/L đối với cột B (xả vào nguồn nước không dùng cho cấp nước sinh hoạt).",
            "required_facts": ["QCVN 40:2011", "BOD5", "30 mg/L", "50 mg/L", "cột A", "cột B"]
        },
        {
            "query": "Đối tượng nào phải có giấy phép môi trường theo Nghị định 08/2022?",
            "ground_truth": "Theo Nghị định 08/2022/NĐ-CP, đối tượng phải có giấy phép môi trường bao gồm: (1) Dự án đầu tư nhóm I, (2) Dự án đầu tư nhóm II có phát sinh nước thải, bụi, khí thải xả ra môi trường, (3) Cơ sở sản xuất, kinh doanh, dịch vụ hoạt động trước ngày Luật BVMT 2020 có hiệu lực thuộc đối tượng phải có giấy phép môi trường.",
            "required_facts": ["Nghị định 08/2022", "dự án nhóm I", "dự án nhóm II", "nước thải", "khí thải", "giấy phép môi trường"]
        },
        {
            "query": "Tiêu chuẩn PM2.5 trong không khí theo QCVN 05:2023 là gì?",
            "ground_truth": "Theo QCVN 05:2023/BTNMT, giới hạn nồng độ PM2.5 trong không khí xung quanh là: 50 μg/m³ (trung bình 24 giờ) và 25 μg/m³ (trung bình năm).",
            "required_facts": ["QCVN 05:2023", "PM2.5", "50 μg/m³", "25 μg/m³", "24 giờ", "năm"]
        }
    ]
    
    @classmethod
    def get_test_cases(cls) -> List[Dict]:
        """Get test cases for evaluation."""
        return cls.TEST_CASES
    
    @classmethod
    def create_evaluation_report(cls, results: Dict) -> str:
        """Create formatted evaluation report."""
        report = ["# RAG Evaluation Report", ""]
        report.append(f"Total test cases: {results['total_cases']}")
        report.append("")
        
        report.append("## Aggregated Metrics")
        for metric, stats in results['aggregated_metrics'].items():
            report.append(f"\n### {metric}")
            report.append(f"- Mean: {stats['mean']:.4f}")
            report.append(f"- Std: {stats['std']:.4f}")
            report.append(f"- Min: {stats['min']:.4f}")
            report.append(f"- Max: {stats['max']:.4f}")
        
        report.append("\n## Individual Results")
        for i, result in enumerate(results['individual_results']):
            report.append(f"\n### Test Case {i+1}")
            report.append(f"Query: {result.query}")
            report.append(f"Metrics: {result.metrics}")
        
        return "\n".join(report)
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Advanced RAG Implementation (Ngày 1-3)

```
🎯 Mục tiêu: Implement AdvancedRAG với query transformation

📋 Yêu cầu:
1. Implement HyDE (Hypothetical Document Embedding)
2. Implement Multi-query retrieval
3. Add Cohere reranking
4. Context compression

📁 Deliverables:
- src/rag/advanced_rag.py
- src/rag/query_transform.py
- tests/test_advanced_rag.py
```

### Bài tập 2: Hybrid Search (Ngày 4-5)

```
🎯 Mục tiêu: Implement hybrid search với BM25 + Dense

📋 Yêu cầu:
1. BM25 indexing và search
2. Reciprocal Rank Fusion
3. Linear combination
4. Benchmark comparison

📁 Deliverables:
- src/retrieval/hybrid_search.py
- src/retrieval/bm25.py
- Benchmark results
```

### Bài tập 3: RAG Evaluation (Ngày 6-7)

```
🎯 Mục tiêu: Build evaluation system với RAGAS metrics

📋 Yêu cầu:
1. Implement all RAGAS metrics
2. Create test dataset cho environmental domain
3. Run evaluation và generate report
4. Identify improvement areas

📁 Deliverables:
- src/evaluation/rag_evaluator.py
- data/test_cases.json
- reports/evaluation_report.md
- **PROJECT 2 Started**: Environmental Compliance RAG
```

---

## ✅ CHECKLIST TUẦN 5

### Kiến thức đã học
- [ ] RAG architecture components
- [ ] Query transformation techniques (HyDE, multi-query)
- [ ] Retrieval strategies (dense, sparse, hybrid)
- [ ] Reranking methods
- [ ] RAG evaluation metrics (RAGAS)

### Skills thực hành
- [ ] Implement advanced RAG pipeline
- [ ] Build hybrid search system
- [ ] Setup Cohere reranking
- [ ] Evaluate RAG với RAGAS
- [ ] Optimize retrieval quality

### Deliverables
- [ ] AdvancedRAG implementation
- [ ] Hybrid search system
- [ ] RAG evaluation framework
- [ ] Test dataset
- [ ] Benchmark report

---

*Hoàn thành Tuần 5 để tiếp tục sang Tuần 6: LangChain & LlamaIndex Deep Dive*
