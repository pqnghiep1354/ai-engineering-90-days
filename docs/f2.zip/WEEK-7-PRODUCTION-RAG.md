# 📅 TUẦN 7: PRODUCTION RAG OPTIMIZATION

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Optimize RAG cho production với caching, batching, evaluation |
| **Output** | Production-optimized Environmental RAG System |
| **Độ khó** | ⭐⭐⭐⭐ Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu các bottlenecks trong RAG pipelines
- [ ] Nắm vững caching strategies (semantic, exact)
- [ ] Hiểu batching và parallel processing
- [ ] Biết RAG evaluation best practices

### Kỹ năng (Skills)
- [ ] Implement semantic caching với Redis
- [ ] Build batching cho embeddings và LLM calls
- [ ] Setup monitoring và observability
- [ ] Create comprehensive evaluation pipeline

### Ứng dụng (Application)
- [ ] Optimize Environmental RAG cho production
- [ ] Reduce latency và costs
- [ ] Implement quality monitoring

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: Caching Strategies

#### 1.1 Caching Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         RAG CACHING ARCHITECTURE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                        CACHING LAYERS                                │    │
│  │                                                                      │    │
│  │   Layer 1: Query Cache                                              │    │
│  │   ┌─────────────┐                                                   │    │
│  │   │ Exact Match │ ──▶ Hash(query) → Cached Response                 │    │
│  │   └─────────────┘                                                   │    │
│  │                                                                      │    │
│  │   Layer 2: Semantic Cache                                           │    │
│  │   ┌─────────────┐                                                   │    │
│  │   │ Similar Q   │ ──▶ Embed(query) → Top-K Similar → Cached Resp   │    │
│  │   └─────────────┘                                                   │    │
│  │                                                                      │    │
│  │   Layer 3: Document Cache                                           │    │
│  │   ┌─────────────┐                                                   │    │
│  │   │ Retrieved   │ ──▶ Cache retrieved documents per query          │    │
│  │   └─────────────┘                                                   │    │
│  │                                                                      │    │
│  │   Layer 4: Embedding Cache                                          │    │
│  │   ┌─────────────┐                                                   │    │
│  │   │ Embeddings  │ ──▶ Cache embeddings for repeated texts          │    │
│  │   └─────────────┘                                                   │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  Storage Options:                                                           │
│  • In-memory (LRU): Fast, limited size                                     │
│  • Redis: Distributed, TTL support                                         │
│  • SQLite: Persistent, simple                                              │
│  • Vector DB: For semantic cache                                           │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 Semantic Cache Implementation

```python
# ============================================
# SEMANTIC CACHING FOR RAG
# ============================================

import hashlib
import json
import time
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import numpy as np
from abc import ABC, abstractmethod
import redis
import pickle

@dataclass
class CacheEntry:
    """Cache entry with metadata."""
    key: str
    value: Any
    query: str
    query_embedding: Optional[np.ndarray]
    created_at: datetime
    accessed_at: datetime
    hit_count: int = 0
    ttl_seconds: Optional[int] = None
    metadata: Dict = field(default_factory=dict)
    
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        if self.ttl_seconds is None:
            return False
        age = (datetime.now() - self.created_at).total_seconds()
        return age > self.ttl_seconds


class BaseCacheBackend(ABC):
    """Abstract base for cache backends."""
    
    @abstractmethod
    def get(self, key: str) -> Optional[Any]:
        pass
    
    @abstractmethod
    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        pass
    
    @abstractmethod
    def delete(self, key: str):
        pass
    
    @abstractmethod
    def clear(self):
        pass


class InMemoryCache(BaseCacheBackend):
    """In-memory LRU cache backend."""
    
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.cache: Dict[str, CacheEntry] = {}
        self.access_order: List[str] = []
    
    def get(self, key: str) -> Optional[CacheEntry]:
        if key not in self.cache:
            return None
        
        entry = self.cache[key]
        
        # Check expiration
        if entry.is_expired():
            self.delete(key)
            return None
        
        # Update access
        entry.accessed_at = datetime.now()
        entry.hit_count += 1
        
        # Move to end of access order (LRU)
        if key in self.access_order:
            self.access_order.remove(key)
        self.access_order.append(key)
        
        return entry
    
    def set(self, key: str, value: CacheEntry, ttl: Optional[int] = None):
        if ttl:
            value.ttl_seconds = ttl
        
        self.cache[key] = value
        
        if key in self.access_order:
            self.access_order.remove(key)
        self.access_order.append(key)
        
        # Evict if over capacity
        while len(self.cache) > self.max_size:
            oldest_key = self.access_order.pop(0)
            del self.cache[oldest_key]
    
    def delete(self, key: str):
        if key in self.cache:
            del self.cache[key]
        if key in self.access_order:
            self.access_order.remove(key)
    
    def clear(self):
        self.cache.clear()
        self.access_order.clear()
    
    def get_all_embeddings(self) -> List[Tuple[str, np.ndarray]]:
        """Get all cached embeddings for semantic search."""
        results = []
        for key, entry in self.cache.items():
            if entry.query_embedding is not None and not entry.is_expired():
                results.append((key, entry.query_embedding))
        return results


class RedisCache(BaseCacheBackend):
    """Redis cache backend for distributed caching."""
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        prefix: str = "rag_cache:"
    ):
        self.redis = redis.Redis(host=host, port=port, db=db)
        self.prefix = prefix
    
    def _make_key(self, key: str) -> str:
        return f"{self.prefix}{key}"
    
    def get(self, key: str) -> Optional[CacheEntry]:
        data = self.redis.get(self._make_key(key))
        if data is None:
            return None
        
        entry = pickle.loads(data)
        entry.accessed_at = datetime.now()
        entry.hit_count += 1
        
        # Update in Redis
        self.set(key, entry)
        
        return entry
    
    def set(self, key: str, value: CacheEntry, ttl: Optional[int] = None):
        data = pickle.dumps(value)
        
        if ttl:
            self.redis.setex(self._make_key(key), ttl, data)
        else:
            self.redis.set(self._make_key(key), data)
    
    def delete(self, key: str):
        self.redis.delete(self._make_key(key))
    
    def clear(self):
        keys = self.redis.keys(f"{self.prefix}*")
        if keys:
            self.redis.delete(*keys)


class SemanticCache:
    """
    Semantic caching for RAG queries.
    
    Returns cached response if a semantically similar query exists.
    """
    
    def __init__(
        self,
        embedding_model,
        backend: BaseCacheBackend = None,
        similarity_threshold: float = 0.95,
        ttl_seconds: int = 3600,
        max_cache_size: int = 10000
    ):
        self.embedding_model = embedding_model
        self.backend = backend or InMemoryCache(max_size=max_cache_size)
        self.similarity_threshold = similarity_threshold
        self.ttl_seconds = ttl_seconds
        
        # For semantic search, we need a separate vector index
        self._embedding_index: Dict[str, np.ndarray] = {}
    
    def _compute_similarity(
        self,
        query_embedding: np.ndarray,
        cached_embedding: np.ndarray
    ) -> float:
        """Compute cosine similarity between embeddings."""
        dot_product = np.dot(query_embedding, cached_embedding)
        norm_a = np.linalg.norm(query_embedding)
        norm_b = np.linalg.norm(cached_embedding)
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return dot_product / (norm_a * norm_b)
    
    def _generate_key(self, query: str) -> str:
        """Generate cache key from query."""
        return hashlib.sha256(query.encode()).hexdigest()[:16]
    
    def get(self, query: str) -> Optional[Dict]:
        """
        Get cached response for query.
        
        First checks exact match, then semantic similarity.
        
        Returns:
            Cached response dict or None
        """
        # Try exact match first
        exact_key = self._generate_key(query)
        exact_entry = self.backend.get(exact_key)
        
        if exact_entry is not None:
            return {
                "response": exact_entry.value,
                "cache_type": "exact",
                "similarity": 1.0,
                "hit_count": exact_entry.hit_count
            }
        
        # Try semantic match
        query_embedding = self.embedding_model.embed(query)
        
        best_match = None
        best_similarity = 0.0
        
        # Search through cached embeddings
        if isinstance(self.backend, InMemoryCache):
            cached_embeddings = self.backend.get_all_embeddings()
        else:
            cached_embeddings = list(self._embedding_index.items())
        
        for cached_key, cached_embedding in cached_embeddings:
            similarity = self._compute_similarity(query_embedding, cached_embedding)
            
            if similarity > best_similarity and similarity >= self.similarity_threshold:
                best_similarity = similarity
                best_match = cached_key
        
        if best_match is not None:
            entry = self.backend.get(best_match)
            if entry is not None:
                return {
                    "response": entry.value,
                    "cache_type": "semantic",
                    "similarity": best_similarity,
                    "original_query": entry.query,
                    "hit_count": entry.hit_count
                }
        
        return None
    
    def set(
        self,
        query: str,
        response: Any,
        metadata: Dict = None
    ):
        """
        Cache a query-response pair.
        
        Args:
            query: The query string
            response: The response to cache
            metadata: Additional metadata
        """
        key = self._generate_key(query)
        query_embedding = self.embedding_model.embed(query)
        
        entry = CacheEntry(
            key=key,
            value=response,
            query=query,
            query_embedding=query_embedding,
            created_at=datetime.now(),
            accessed_at=datetime.now(),
            ttl_seconds=self.ttl_seconds,
            metadata=metadata or {}
        )
        
        self.backend.set(key, entry, ttl=self.ttl_seconds)
        
        # Update embedding index
        self._embedding_index[key] = query_embedding
    
    def invalidate(self, query: str):
        """Invalidate cache entry for query."""
        key = self._generate_key(query)
        self.backend.delete(key)
        
        if key in self._embedding_index:
            del self._embedding_index[key]
    
    def clear(self):
        """Clear all cache entries."""
        self.backend.clear()
        self._embedding_index.clear()
    
    def get_stats(self) -> Dict:
        """Get cache statistics."""
        if isinstance(self.backend, InMemoryCache):
            total_entries = len(self.backend.cache)
            total_hits = sum(e.hit_count for e in self.backend.cache.values())
        else:
            total_entries = len(self._embedding_index)
            total_hits = 0  # Would need to track separately
        
        return {
            "total_entries": total_entries,
            "total_hits": total_hits,
            "similarity_threshold": self.similarity_threshold,
            "ttl_seconds": self.ttl_seconds
        }


# ============================================
# CACHED RAG SYSTEM
# ============================================

class CachedRAGSystem:
    """
    RAG system with multi-layer caching.
    """
    
    def __init__(
        self,
        rag_system,
        embedding_model,
        cache_config: Dict = None
    ):
        self.rag = rag_system
        self.embedding_model = embedding_model
        
        config = cache_config or {}
        
        # Initialize caches
        self.response_cache = SemanticCache(
            embedding_model=embedding_model,
            similarity_threshold=config.get("semantic_threshold", 0.95),
            ttl_seconds=config.get("response_ttl", 3600)
        )
        
        self.document_cache = InMemoryCache(
            max_size=config.get("doc_cache_size", 5000)
        )
        
        # Stats
        self.stats = {
            "total_queries": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "avg_latency_cached": 0,
            "avg_latency_uncached": 0
        }
    
    def query(
        self,
        query: str,
        use_cache: bool = True,
        **kwargs
    ) -> Dict:
        """
        Query with caching.
        
        Args:
            query: User query
            use_cache: Whether to use cache
            **kwargs: Additional arguments for RAG
        
        Returns:
            Response with cache metadata
        """
        start_time = time.perf_counter()
        self.stats["total_queries"] += 1
        
        # Check cache
        if use_cache:
            cached = self.response_cache.get(query)
            
            if cached is not None:
                latency = (time.perf_counter() - start_time) * 1000
                self.stats["cache_hits"] += 1
                self._update_avg_latency("cached", latency)
                
                return {
                    **cached["response"],
                    "from_cache": True,
                    "cache_type": cached["cache_type"],
                    "cache_similarity": cached.get("similarity", 1.0),
                    "latency_ms": latency
                }
        
        # Cache miss - execute RAG
        self.stats["cache_misses"] += 1
        
        response = self.rag.query(query, **kwargs)
        
        latency = (time.perf_counter() - start_time) * 1000
        self._update_avg_latency("uncached", latency)
        
        # Store in cache
        if use_cache:
            self.response_cache.set(query, response)
        
        return {
            **response,
            "from_cache": False,
            "latency_ms": latency
        }
    
    def _update_avg_latency(self, cache_type: str, latency: float):
        """Update running average latency."""
        key = f"avg_latency_{cache_type}"
        count_key = f"total_{cache_type}"
        
        if count_key not in self.stats:
            self.stats[count_key] = 0
        
        self.stats[count_key] += 1
        n = self.stats[count_key]
        
        # Running average
        self.stats[key] = ((n - 1) * self.stats.get(key, 0) + latency) / n
    
    def get_stats(self) -> Dict:
        """Get comprehensive cache statistics."""
        return {
            **self.stats,
            "cache_hit_rate": (
                self.stats["cache_hits"] / self.stats["total_queries"]
                if self.stats["total_queries"] > 0 else 0
            ),
            "response_cache_stats": self.response_cache.get_stats()
        }
    
    def clear_cache(self):
        """Clear all caches."""
        self.response_cache.clear()
        self.document_cache.clear()
```

### Ngày 3-4: Batching và Parallel Processing

#### 2.1 Batching Implementation

```python
# ============================================
# BATCHING FOR RAG OPERATIONS
# ============================================

import asyncio
from typing import List, Dict, Callable, Any, TypeVar
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
from queue import Queue
import threading

T = TypeVar('T')

@dataclass
class BatchConfig:
    """Configuration for batching operations."""
    batch_size: int = 32
    max_wait_ms: int = 100
    max_concurrent: int = 5
    timeout_seconds: int = 30

class BatchProcessor:
    """
    Generic batch processor for expensive operations.
    
    Collects items and processes them in batches for efficiency.
    """
    
    def __init__(
        self,
        process_fn: Callable[[List[Any]], List[Any]],
        config: BatchConfig = None
    ):
        self.process_fn = process_fn
        self.config = config or BatchConfig()
        
        self._queue: Queue = Queue()
        self._results: Dict[str, Any] = {}
        self._lock = threading.Lock()
        self._running = False
        self._batch_thread = None
    
    def start(self):
        """Start the batch processor."""
        self._running = True
        self._batch_thread = threading.Thread(target=self._batch_loop)
        self._batch_thread.daemon = True
        self._batch_thread.start()
    
    def stop(self):
        """Stop the batch processor."""
        self._running = False
        if self._batch_thread:
            self._batch_thread.join(timeout=5)
    
    def _batch_loop(self):
        """Main loop for collecting and processing batches."""
        while self._running:
            batch = []
            batch_ids = []
            
            # Collect items for batch
            start_time = time.time()
            
            while len(batch) < self.config.batch_size:
                elapsed_ms = (time.time() - start_time) * 1000
                
                if elapsed_ms >= self.config.max_wait_ms and batch:
                    break
                
                try:
                    item_id, item = self._queue.get(timeout=0.01)
                    batch.append(item)
                    batch_ids.append(item_id)
                except:
                    if batch:
                        break
                    continue
            
            if batch:
                # Process batch
                try:
                    results = self.process_fn(batch)
                    
                    # Store results
                    with self._lock:
                        for item_id, result in zip(batch_ids, results):
                            self._results[item_id] = result
                except Exception as e:
                    with self._lock:
                        for item_id in batch_ids:
                            self._results[item_id] = {"error": str(e)}
    
    def submit(self, item: Any) -> str:
        """Submit item for processing, returns item ID."""
        import uuid
        item_id = str(uuid.uuid4())
        self._queue.put((item_id, item))
        return item_id
    
    def get_result(self, item_id: str, timeout: float = None) -> Any:
        """Get result for item, blocks until available."""
        timeout = timeout or self.config.timeout_seconds
        start = time.time()
        
        while time.time() - start < timeout:
            with self._lock:
                if item_id in self._results:
                    return self._results.pop(item_id)
            time.sleep(0.01)
        
        raise TimeoutError(f"Timeout waiting for result: {item_id}")


class EmbeddingBatcher:
    """
    Batch processor specifically for embeddings.
    
    Significantly reduces API calls for large document sets.
    """
    
    def __init__(
        self,
        embedding_model,
        batch_size: int = 100,
        max_concurrent: int = 3
    ):
        self.model = embedding_model
        self.batch_size = batch_size
        self.max_concurrent = max_concurrent
        self._cache: Dict[str, List[float]] = {}
    
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Embed multiple texts with batching.
        
        Args:
            texts: List of texts to embed
        
        Returns:
            List of embeddings
        """
        # Check cache first
        uncached_texts = []
        uncached_indices = []
        results = [None] * len(texts)
        
        for i, text in enumerate(texts):
            cache_key = hashlib.md5(text.encode()).hexdigest()
            
            if cache_key in self._cache:
                results[i] = self._cache[cache_key]
            else:
                uncached_texts.append(text)
                uncached_indices.append(i)
        
        if not uncached_texts:
            return results
        
        # Batch embed uncached texts
        all_embeddings = []
        
        for i in range(0, len(uncached_texts), self.batch_size):
            batch = uncached_texts[i:i + self.batch_size]
            
            # Call embedding API
            embeddings = self.model.embed_batch(batch)
            all_embeddings.extend(embeddings)
        
        # Store results and update cache
        for idx, embedding in zip(uncached_indices, all_embeddings):
            results[idx] = embedding
            
            cache_key = hashlib.md5(texts[idx].encode()).hexdigest()
            self._cache[cache_key] = embedding
        
        return results
    
    async def embed_batch_async(self, texts: List[str]) -> List[List[float]]:
        """Async version of batch embedding."""
        
        # Similar logic but using asyncio
        uncached_texts = []
        uncached_indices = []
        results = [None] * len(texts)
        
        for i, text in enumerate(texts):
            cache_key = hashlib.md5(text.encode()).hexdigest()
            if cache_key in self._cache:
                results[i] = self._cache[cache_key]
            else:
                uncached_texts.append(text)
                uncached_indices.append(i)
        
        if not uncached_texts:
            return results
        
        # Create batches
        batches = [
            uncached_texts[i:i + self.batch_size]
            for i in range(0, len(uncached_texts), self.batch_size)
        ]
        
        # Process batches concurrently
        semaphore = asyncio.Semaphore(self.max_concurrent)
        
        async def process_batch(batch):
            async with semaphore:
                return await self.model.aembed_batch(batch)
        
        batch_results = await asyncio.gather(*[
            process_batch(batch) for batch in batches
        ])
        
        # Flatten and store
        all_embeddings = [emb for batch_embs in batch_results for emb in batch_embs]
        
        for idx, embedding in zip(uncached_indices, all_embeddings):
            results[idx] = embedding
            cache_key = hashlib.md5(texts[idx].encode()).hexdigest()
            self._cache[cache_key] = embedding
        
        return results


class ParallelRAGProcessor:
    """
    Process multiple RAG queries in parallel.
    """
    
    def __init__(
        self,
        rag_system,
        max_workers: int = 5
    ):
        self.rag = rag_system
        self.max_workers = max_workers
    
    def process_queries(
        self,
        queries: List[str],
        **kwargs
    ) -> List[Dict]:
        """Process multiple queries in parallel."""
        
        results = [None] * len(queries)
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_idx = {
                executor.submit(self.rag.query, query, **kwargs): i
                for i, query in enumerate(queries)
            }
            
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                try:
                    results[idx] = future.result()
                except Exception as e:
                    results[idx] = {"error": str(e)}
        
        return results
    
    async def process_queries_async(
        self,
        queries: List[str],
        **kwargs
    ) -> List[Dict]:
        """Process multiple queries asynchronously."""
        
        semaphore = asyncio.Semaphore(self.max_workers)
        
        async def process_single(query: str):
            async with semaphore:
                return await self.rag.aquery(query, **kwargs)
        
        results = await asyncio.gather(*[
            process_single(query) for query in queries
        ], return_exceptions=True)
        
        return [
            r if not isinstance(r, Exception) else {"error": str(r)}
            for r in results
        ]
```

### Ngày 5-6: Monitoring và Observability

#### 3.1 RAG Monitoring System

```python
# ============================================
# RAG MONITORING & OBSERVABILITY
# ============================================

from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict
import json
import logging
from enum import Enum
import time
from contextlib import contextmanager

class MetricType(Enum):
    """Types of metrics to track."""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    SUMMARY = "summary"

@dataclass
class Metric:
    """Single metric data point."""
    name: str
    value: float
    metric_type: MetricType
    timestamp: datetime
    labels: Dict[str, str] = field(default_factory=dict)

@dataclass
class RAGTrace:
    """Trace for a single RAG operation."""
    trace_id: str
    query: str
    start_time: datetime
    end_time: Optional[datetime] = None
    
    # Timing breakdown
    embedding_time_ms: float = 0
    retrieval_time_ms: float = 0
    reranking_time_ms: float = 0
    generation_time_ms: float = 0
    total_time_ms: float = 0
    
    # Quality metrics
    retrieval_count: int = 0
    relevant_count: int = 0
    answer_length: int = 0
    
    # Cost tracking
    input_tokens: int = 0
    output_tokens: int = 0
    embedding_tokens: int = 0
    estimated_cost: float = 0
    
    # Status
    success: bool = True
    error: Optional[str] = None
    
    # Additional context
    metadata: Dict = field(default_factory=dict)


class RAGMonitor:
    """
    Comprehensive monitoring for RAG systems.
    
    Tracks:
    - Latency (total and per-stage)
    - Throughput
    - Quality metrics
    - Cost
    - Errors
    """
    
    def __init__(
        self,
        service_name: str = "rag_service",
        enable_logging: bool = True,
        log_level: str = "INFO"
    ):
        self.service_name = service_name
        self.enable_logging = enable_logging
        
        # Setup logging
        self.logger = logging.getLogger(f"{service_name}_monitor")
        self.logger.setLevel(getattr(logging, log_level))
        
        # Metric storage
        self._metrics: List[Metric] = []
        self._traces: List[RAGTrace] = []
        
        # Aggregated stats
        self._stats = defaultdict(lambda: {
            "count": 0,
            "sum": 0,
            "min": float("inf"),
            "max": float("-inf"),
            "values": []
        })
        
        # Alert thresholds
        self._thresholds = {
            "latency_p95_ms": 5000,
            "error_rate": 0.05,
            "cost_per_query": 0.10
        }
    
    @contextmanager
    def trace_query(self, query: str, trace_id: str = None):
        """
        Context manager for tracing a query.
        
        Usage:
            with monitor.trace_query("What is BOD?") as trace:
                trace.embedding_time_ms = 50
                result = rag.query(query)
                trace.generation_time_ms = 200
        """
        import uuid
        
        trace = RAGTrace(
            trace_id=trace_id or str(uuid.uuid4()),
            query=query,
            start_time=datetime.now()
        )
        
        try:
            yield trace
            trace.success = True
        except Exception as e:
            trace.success = False
            trace.error = str(e)
            raise
        finally:
            trace.end_time = datetime.now()
            trace.total_time_ms = (trace.end_time - trace.start_time).total_seconds() * 1000
            
            self._traces.append(trace)
            self._record_trace_metrics(trace)
            
            if self.enable_logging:
                self._log_trace(trace)
    
    def _record_trace_metrics(self, trace: RAGTrace):
        """Record metrics from trace."""
        
        # Latency metrics
        self._record_metric("latency_total_ms", trace.total_time_ms, MetricType.HISTOGRAM)
        self._record_metric("latency_embedding_ms", trace.embedding_time_ms, MetricType.HISTOGRAM)
        self._record_metric("latency_retrieval_ms", trace.retrieval_time_ms, MetricType.HISTOGRAM)
        self._record_metric("latency_generation_ms", trace.generation_time_ms, MetricType.HISTOGRAM)
        
        # Quality metrics
        if trace.retrieval_count > 0:
            precision = trace.relevant_count / trace.retrieval_count
            self._record_metric("retrieval_precision", precision, MetricType.GAUGE)
        
        # Cost metrics
        self._record_metric("tokens_input", trace.input_tokens, MetricType.COUNTER)
        self._record_metric("tokens_output", trace.output_tokens, MetricType.COUNTER)
        self._record_metric("cost_usd", trace.estimated_cost, MetricType.COUNTER)
        
        # Error tracking
        if not trace.success:
            self._record_metric("errors", 1, MetricType.COUNTER)
    
    def _record_metric(
        self,
        name: str,
        value: float,
        metric_type: MetricType,
        labels: Dict = None
    ):
        """Record a single metric."""
        metric = Metric(
            name=name,
            value=value,
            metric_type=metric_type,
            timestamp=datetime.now(),
            labels=labels or {}
        )
        
        self._metrics.append(metric)
        
        # Update stats
        stats = self._stats[name]
        stats["count"] += 1
        stats["sum"] += value
        stats["min"] = min(stats["min"], value)
        stats["max"] = max(stats["max"], value)
        stats["values"].append(value)
        
        # Keep only recent values for percentiles
        if len(stats["values"]) > 1000:
            stats["values"] = stats["values"][-1000:]
    
    def _log_trace(self, trace: RAGTrace):
        """Log trace information."""
        log_data = {
            "trace_id": trace.trace_id,
            "query": trace.query[:100],
            "total_time_ms": trace.total_time_ms,
            "success": trace.success,
            "tokens": trace.input_tokens + trace.output_tokens
        }
        
        if trace.success:
            self.logger.info(f"RAG Query: {json.dumps(log_data)}")
        else:
            log_data["error"] = trace.error
            self.logger.error(f"RAG Query Failed: {json.dumps(log_data)}")
    
    def get_stats(self, time_window_minutes: int = 60) -> Dict:
        """Get aggregated statistics."""
        
        cutoff = datetime.now() - timedelta(minutes=time_window_minutes)
        recent_traces = [t for t in self._traces if t.start_time > cutoff]
        
        if not recent_traces:
            return {"message": "No data in time window"}
        
        # Calculate stats
        latencies = [t.total_time_ms for t in recent_traces]
        latencies.sort()
        
        total_tokens = sum(t.input_tokens + t.output_tokens for t in recent_traces)
        total_cost = sum(t.estimated_cost for t in recent_traces)
        error_count = sum(1 for t in recent_traces if not t.success)
        
        return {
            "time_window_minutes": time_window_minutes,
            "total_queries": len(recent_traces),
            "error_count": error_count,
            "error_rate": error_count / len(recent_traces) if recent_traces else 0,
            "latency": {
                "p50_ms": latencies[len(latencies) // 2] if latencies else 0,
                "p95_ms": latencies[int(len(latencies) * 0.95)] if latencies else 0,
                "p99_ms": latencies[int(len(latencies) * 0.99)] if latencies else 0,
                "avg_ms": sum(latencies) / len(latencies) if latencies else 0,
                "max_ms": max(latencies) if latencies else 0
            },
            "tokens": {
                "total": total_tokens,
                "avg_per_query": total_tokens / len(recent_traces) if recent_traces else 0
            },
            "cost": {
                "total_usd": total_cost,
                "avg_per_query": total_cost / len(recent_traces) if recent_traces else 0
            }
        }
    
    def check_alerts(self) -> List[Dict]:
        """Check for alert conditions."""
        alerts = []
        stats = self.get_stats(time_window_minutes=5)
        
        # Latency alert
        if stats.get("latency", {}).get("p95_ms", 0) > self._thresholds["latency_p95_ms"]:
            alerts.append({
                "type": "latency",
                "severity": "warning",
                "message": f"P95 latency ({stats['latency']['p95_ms']:.0f}ms) exceeds threshold ({self._thresholds['latency_p95_ms']}ms)"
            })
        
        # Error rate alert
        if stats.get("error_rate", 0) > self._thresholds["error_rate"]:
            alerts.append({
                "type": "error_rate",
                "severity": "critical",
                "message": f"Error rate ({stats['error_rate']:.2%}) exceeds threshold ({self._thresholds['error_rate']:.2%})"
            })
        
        # Cost alert
        avg_cost = stats.get("cost", {}).get("avg_per_query", 0)
        if avg_cost > self._thresholds["cost_per_query"]:
            alerts.append({
                "type": "cost",
                "severity": "warning",
                "message": f"Avg cost per query (${avg_cost:.4f}) exceeds threshold (${self._thresholds['cost_per_query']:.2f})"
            })
        
        return alerts
    
    def export_prometheus_metrics(self) -> str:
        """Export metrics in Prometheus format."""
        lines = []
        
        for name, stats in self._stats.items():
            # Counter/Gauge
            lines.append(f"# TYPE {self.service_name}_{name} gauge")
            lines.append(f"{self.service_name}_{name} {stats['sum']}")
            
            # If histogram, add percentiles
            if stats["values"]:
                sorted_vals = sorted(stats["values"])
                for p, label in [(0.5, "p50"), (0.95, "p95"), (0.99, "p99")]:
                    idx = int(len(sorted_vals) * p)
                    lines.append(f'{self.service_name}_{name}{{quantile="{p}"}} {sorted_vals[idx]}')
        
        return "\n".join(lines)


# ============================================
# COST TRACKING
# ============================================

class CostTracker:
    """
    Track and estimate costs for RAG operations.
    """
    
    # Pricing per 1K tokens (as of 2024)
    PRICING = {
        "gpt-4-turbo-preview": {"input": 0.01, "output": 0.03},
        "gpt-4o": {"input": 0.005, "output": 0.015},
        "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
        "claude-3-opus": {"input": 0.015, "output": 0.075},
        "claude-3-sonnet": {"input": 0.003, "output": 0.015},
        "claude-3-haiku": {"input": 0.00025, "output": 0.00125},
        "text-embedding-3-small": {"input": 0.00002},
        "text-embedding-3-large": {"input": 0.00013},
    }
    
    def __init__(self):
        self.total_cost = 0.0
        self.cost_by_model: Dict[str, float] = defaultdict(float)
        self.cost_by_operation: Dict[str, float] = defaultdict(float)
    
    def calculate_cost(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int = 0,
        operation: str = "query"
    ) -> float:
        """Calculate cost for an operation."""
        
        if model not in self.PRICING:
            return 0.0
        
        pricing = self.PRICING[model]
        
        cost = (input_tokens / 1000) * pricing.get("input", 0)
        cost += (output_tokens / 1000) * pricing.get("output", 0)
        
        # Track
        self.total_cost += cost
        self.cost_by_model[model] += cost
        self.cost_by_operation[operation] += cost
        
        return cost
    
    def get_summary(self) -> Dict:
        """Get cost summary."""
        return {
            "total_cost_usd": self.total_cost,
            "by_model": dict(self.cost_by_model),
            "by_operation": dict(self.cost_by_operation)
        }
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Implement Semantic Cache (Ngày 1-2)

```
🎯 Mục tiêu: Build semantic caching system

📋 Yêu cầu:
1. Implement SemanticCache với Redis backend
2. Add embedding cache
3. Benchmark cache hit rates
4. Tune similarity thresholds

📁 Deliverables:
- src/cache/semantic_cache.py
- src/cache/redis_backend.py
- Benchmark results
```

### Bài tập 2: Batching & Parallel Processing (Ngày 3-4)

```
🎯 Mục tiêu: Optimize với batching

📋 Yêu cầu:
1. Implement embedding batcher
2. Add parallel query processing
3. Benchmark performance improvements
4. Add async support

📁 Deliverables:
- src/optimization/batcher.py
- src/optimization/parallel.py
- Performance comparison report
```

### Bài tập 3: Monitoring System (Ngày 5-7)

```
🎯 Mục tiêu: Build comprehensive monitoring

📋 Yêu cầu:
1. Implement RAGMonitor
2. Add Prometheus metrics export
3. Create cost tracking
4. Setup alerting

📁 Deliverables:
- src/monitoring/rag_monitor.py
- src/monitoring/cost_tracker.py
- Grafana dashboard config
- **PROJECT 2 Production**: Optimized Environmental RAG
```

---

## ✅ CHECKLIST TUẦN 7

### Kiến thức đã học
- [ ] Caching strategies (exact, semantic)
- [ ] Batching cho embeddings và LLM calls
- [ ] Parallel processing patterns
- [ ] Monitoring và observability
- [ ] Cost optimization

### Skills thực hành
- [ ] Implement semantic cache
- [ ] Build embedding batcher
- [ ] Setup monitoring với Prometheus
- [ ] Track và optimize costs

### Deliverables
- [ ] Semantic caching system
- [ ] Batching infrastructure
- [ ] Monitoring dashboard
- [ ] Cost tracking
- [ ] **PROJECT 2**: Production-optimized RAG

---

*Hoàn thành Tuần 7 để tiếp tục sang Tuần 8: Function Calling & Tool Use*
