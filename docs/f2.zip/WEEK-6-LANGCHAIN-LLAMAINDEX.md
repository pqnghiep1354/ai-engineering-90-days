# 📅 TUẦN 6: LANGCHAIN & LLAMAINDEX DEEP DIVE

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Thành thạo LangChain và LlamaIndex cho production RAG |
| **Output** | Production RAG system với framework comparison |
| **Độ khó** | ⭐⭐⭐⭐ Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu LangChain architecture (LCEL, Chains, Agents)
- [ ] Nắm vững LlamaIndex components (Indexes, Query Engines)
- [ ] So sánh strengths/weaknesses của mỗi framework
- [ ] Biết khi nào dùng framework nào

### Kỹ năng (Skills)
- [ ] Build chains với LangChain Expression Language (LCEL)
- [ ] Implement custom retrievers và query engines
- [ ] Create reusable components
- [ ] Debug và optimize pipelines

### Ứng dụng (Application)
- [ ] Xây dựng RAG pipeline với cả hai frameworks
- [ ] Implement custom Vietnamese document loaders
- [ ] Production-ready configurations

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: LangChain Deep Dive

#### 1.1 LangChain Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        LANGCHAIN ARCHITECTURE                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    LANGCHAIN EXPRESSION LANGUAGE (LCEL)              │    │
│  │                                                                      │    │
│  │   Prompt │ LLM │ OutputParser    (Pipe operator: | )                │    │
│  │      │       │        │                                              │    │
│  │      └───────┴────────┘                                              │    │
│  │           Chain                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │    Retrievers   │  │   Memory        │  │    Tools        │             │
│  │                 │  │                 │  │                 │             │
│  │  • VectorStore  │  │  • Buffer       │  │  • Search       │             │
│  │  • Multi-Query  │  │  • Summary      │  │  • Calculator   │             │
│  │  • Self-Query   │  │  • Entity       │  │  • Custom       │             │
│  │  • Contextual   │  │  • Conversation │  │  • API calls    │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                          AGENTS                                      │    │
│  │                                                                      │    │
│  │   Agent ──▶ Think ──▶ Act ──▶ Observe ──▶ Repeat/Finish            │    │
│  │            (ReAct pattern)                                          │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 LangChain Expression Language (LCEL)

```python
# ============================================
# LANGCHAIN EXPRESSION LANGUAGE (LCEL)
# ============================================

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.output_parsers import StrOutputParser, JsonOutputParser
from langchain_core.runnables import (
    RunnablePassthrough, 
    RunnableLambda, 
    RunnableParallel,
    RunnableBranch
)
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from operator import itemgetter

# ==================== BASIC LCEL CHAINS ====================

class LCELBasics:
    """
    LangChain Expression Language fundamentals.
    
    LCEL is a declarative way to compose chains using the | operator.
    Benefits:
    - Streaming support
    - Async support
    - Parallel execution
    - Retries and fallbacks
    - Tracing (LangSmith)
    """
    
    def __init__(self, model_name: str = "gpt-4-turbo-preview"):
        self.llm = ChatOpenAI(model=model_name, temperature=0.3)
    
    def simple_chain(self):
        """
        Basic chain: Prompt → LLM → Output Parser
        """
        prompt = ChatPromptTemplate.from_messages([
            ("system", "Bạn là chuyên gia tư vấn môi trường Việt Nam."),
            ("human", "{question}")
        ])
        
        # Using pipe operator to compose
        chain = prompt | self.llm | StrOutputParser()
        
        return chain
    
    def chain_with_input_processing(self):
        """
        Chain with input transformation.
        """
        def preprocess_question(inputs: dict) -> dict:
            """Clean and normalize input question."""
            question = inputs.get("question", "")
            # Normalize Vietnamese text
            question = question.strip()
            return {"question": question, "original": inputs.get("question")}
        
        prompt = ChatPromptTemplate.from_template(
            "Trả lời câu hỏi sau về quy định môi trường: {question}"
        )
        
        chain = (
            RunnableLambda(preprocess_question)
            | prompt 
            | self.llm 
            | StrOutputParser()
        )
        
        return chain
    
    def parallel_chain(self):
        """
        Execute multiple chains in parallel.
        """
        # Define individual chains
        summary_prompt = ChatPromptTemplate.from_template(
            "Tóm tắt ngắn gọn: {text}"
        )
        
        keywords_prompt = ChatPromptTemplate.from_template(
            "Trích xuất 5 từ khóa chính từ: {text}\nTrả về dạng danh sách."
        )
        
        category_prompt = ChatPromptTemplate.from_template(
            "Phân loại văn bản sau vào: air_quality, water_quality, waste_management, eia, permit\nVăn bản: {text}\nChỉ trả về category."
        )
        
        # Parallel execution
        parallel_chain = RunnableParallel(
            summary=summary_prompt | self.llm | StrOutputParser(),
            keywords=keywords_prompt | self.llm | StrOutputParser(),
            category=category_prompt | self.llm | StrOutputParser()
        )
        
        return parallel_chain
    
    def conditional_chain(self):
        """
        Chain with conditional branching.
        """
        # Classifier chain
        classify_prompt = ChatPromptTemplate.from_template(
            "Phân loại câu hỏi sau: 'simple' (có thể trả lời ngắn) hoặc 'complex' (cần phân tích chi tiết)\n\nCâu hỏi: {question}\n\nPhân loại:"
        )
        
        # Simple answer chain
        simple_prompt = ChatPromptTemplate.from_template(
            "Trả lời ngắn gọn: {question}"
        )
        
        # Complex answer chain
        complex_prompt = ChatPromptTemplate.from_template(
            """Phân tích chi tiết câu hỏi sau:
            
Câu hỏi: {question}

Hãy trả lời theo cấu trúc:
1. Phân tích vấn đề
2. Các quy định liên quan
3. Kết luận
4. Khuyến nghị"""
        )
        
        # Classification step
        classifier = classify_prompt | self.llm | StrOutputParser()
        
        # Conditional branching
        def route(info: dict) -> str:
            classification = info.get("classification", "").lower()
            if "simple" in classification:
                return "simple"
            return "complex"
        
        branch = RunnableBranch(
            (lambda x: route(x) == "simple", simple_prompt | self.llm | StrOutputParser()),
            complex_prompt | self.llm | StrOutputParser()  # Default
        )
        
        # Full chain
        full_chain = (
            RunnableParallel(
                question=itemgetter("question"),
                classification=classifier
            )
            | branch
        )
        
        return full_chain


# ==================== STRUCTURED OUTPUT ====================

class EnvironmentalAnalysis(BaseModel):
    """Structured output for environmental analysis."""
    category: str = Field(description="Lĩnh vực môi trường: air, water, waste, eia, permit")
    regulations: List[str] = Field(description="Danh sách văn bản pháp luật liên quan")
    key_requirements: List[str] = Field(description="Các yêu cầu chính")
    compliance_status: str = Field(description="Trạng thái tuân thủ: compliant, non_compliant, needs_review")
    recommendations: List[str] = Field(description="Các khuyến nghị")

class StructuredOutputChain:
    """
    Chain with structured JSON output using Pydantic.
    """
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0)
    
    def create_analysis_chain(self):
        """Create chain that outputs structured analysis."""
        
        # JSON output parser
        parser = JsonOutputParser(pydantic_object=EnvironmentalAnalysis)
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", """Bạn là chuyên gia phân tích tuân thủ môi trường.
Phân tích tình huống và trả về JSON theo format yêu cầu.

{format_instructions}"""),
            ("human", "Phân tích tình huống sau:\n{situation}")
        ])
        
        # Add format instructions to prompt
        prompt = prompt.partial(format_instructions=parser.get_format_instructions())
        
        chain = prompt | self.llm | parser
        
        return chain
    
    def create_extraction_chain(self):
        """Chain for extracting entities from legal documents."""
        
        class LegalEntities(BaseModel):
            document_number: Optional[str] = Field(description="Số hiệu văn bản (VD: QCVN 40:2011/BTNMT)")
            articles: List[str] = Field(description="Danh sách điều khoản được đề cập")
            parameters: List[str] = Field(description="Các thông số môi trường")
            limit_values: List[Dict] = Field(description="Các giá trị giới hạn với đơn vị")
            effective_date: Optional[str] = Field(description="Ngày có hiệu lực")
        
        parser = JsonOutputParser(pydantic_object=LegalEntities)
        
        prompt = ChatPromptTemplate.from_template(
            """Trích xuất thông tin từ văn bản pháp luật môi trường sau:

{text}

{format_instructions}"""
        )
        
        prompt = prompt.partial(format_instructions=parser.get_format_instructions())
        
        chain = prompt | self.llm | parser
        
        return chain


# ==================== RAG WITH LCEL ====================

class LCELRagChain:
    """
    RAG implementation using LCEL.
    """
    
    def __init__(
        self,
        persist_directory: str = "./chroma_db",
        collection_name: str = "environmental_docs"
    ):
        self.embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0.3)
        
        # Initialize vector store
        self.vectorstore = Chroma(
            collection_name=collection_name,
            embedding_function=self.embeddings,
            persist_directory=persist_directory
        )
        
        self.retriever = self.vectorstore.as_retriever(
            search_type="similarity",
            search_kwargs={"k": 5}
        )
    
    def create_basic_rag_chain(self):
        """Basic RAG chain with LCEL."""
        
        prompt = ChatPromptTemplate.from_template(
            """Dựa vào ngữ cảnh sau, trả lời câu hỏi.

NGỮCẢNH:
{context}

CÂU HỎI: {question}

TRẢ LỜI:"""
        )
        
        def format_docs(docs):
            return "\n\n---\n\n".join(doc.page_content for doc in docs)
        
        # RAG chain
        rag_chain = (
            {
                "context": self.retriever | format_docs,
                "question": RunnablePassthrough()
            }
            | prompt
            | self.llm
            | StrOutputParser()
        )
        
        return rag_chain
    
    def create_rag_with_sources(self):
        """RAG chain that returns sources."""
        
        prompt = ChatPromptTemplate.from_template(
            """Dựa vào các nguồn sau, trả lời câu hỏi và trích dẫn nguồn.

NGUỒN:
{context}

CÂU HỎI: {question}

Yêu cầu:
1. Trả lời câu hỏi
2. Trích dẫn nguồn bằng [1], [2], etc.

TRẢ LỜI:"""
        )
        
        def format_docs_with_ids(docs):
            formatted = []
            for i, doc in enumerate(docs):
                source = doc.metadata.get('source', 'Unknown')
                formatted.append(f"[{i+1}] {source}\n{doc.page_content}")
            return "\n\n---\n\n".join(formatted)
        
        def get_sources(docs):
            return [
                {
                    "id": i+1,
                    "source": doc.metadata.get('source'),
                    "content": doc.page_content[:200]
                }
                for i, doc in enumerate(docs)
            ]
        
        # Chain that returns both answer and sources
        rag_chain = RunnableParallel(
            answer=(
                {
                    "context": self.retriever | format_docs_with_ids,
                    "question": RunnablePassthrough()
                }
                | prompt
                | self.llm
                | StrOutputParser()
            ),
            sources=self.retriever | RunnableLambda(get_sources)
        )
        
        return rag_chain
    
    def create_conversational_rag(self):
        """RAG with conversation history."""
        
        contextualize_prompt = ChatPromptTemplate.from_messages([
            ("system", """Dựa vào lịch sử hội thoại và câu hỏi mới, 
hãy viết lại câu hỏi độc lập có thể hiểu được mà không cần lịch sử."""),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{question}")
        ])
        
        qa_prompt = ChatPromptTemplate.from_messages([
            ("system", """Bạn là trợ lý tư vấn quy định môi trường.
Trả lời dựa trên ngữ cảnh được cung cấp.

NGỮCẢNH:
{context}"""),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{question}")
        ])
        
        def format_docs(docs):
            return "\n\n".join(doc.page_content for doc in docs)
        
        # Contextualize question chain
        contextualize_chain = contextualize_prompt | self.llm | StrOutputParser()
        
        # Full RAG chain
        def get_contextualized_question(inputs):
            if inputs.get("chat_history"):
                return contextualize_chain
            return RunnableLambda(lambda x: x["question"])
        
        rag_chain = (
            RunnablePassthrough.assign(
                context=lambda x: format_docs(
                    self.retriever.invoke(
                        get_contextualized_question(x).invoke(x)
                    )
                )
            )
            | qa_prompt
            | self.llm
            | StrOutputParser()
        )
        
        return rag_chain
    
    def create_multi_query_rag(self):
        """RAG with multi-query retrieval."""
        
        # Multi-query generation prompt
        multi_query_prompt = ChatPromptTemplate.from_template(
            """Tạo 3 phiên bản khác nhau của câu hỏi sau để tìm kiếm tài liệu.
Mỗi phiên bản nên sử dụng từ ngữ và góc nhìn khác nhau.

Câu hỏi gốc: {question}

Trả về 3 câu hỏi, mỗi câu một dòng:"""
        )
        
        def parse_queries(text: str) -> List[str]:
            lines = text.strip().split('\n')
            queries = [q.strip() for q in lines if q.strip()]
            return queries[:3]
        
        # Generate multiple queries
        generate_queries = (
            multi_query_prompt 
            | self.llm 
            | StrOutputParser() 
            | RunnableLambda(parse_queries)
        )
        
        def retrieve_all(queries: List[str]) -> List:
            """Retrieve documents for all queries."""
            all_docs = []
            seen_ids = set()
            
            for query in queries:
                docs = self.retriever.invoke(query)
                for doc in docs:
                    doc_id = hash(doc.page_content)
                    if doc_id not in seen_ids:
                        all_docs.append(doc)
                        seen_ids.add(doc_id)
            
            return all_docs
        
        qa_prompt = ChatPromptTemplate.from_template(
            """Dựa vào ngữ cảnh, trả lời câu hỏi:

NGỮCẢNH:
{context}

CÂU HỎI: {question}

TRẢ LỜI:"""
        )
        
        def format_docs(docs):
            return "\n\n---\n\n".join(doc.page_content for doc in docs)
        
        # Full multi-query RAG chain
        multi_query_rag = (
            RunnableParallel(
                question=RunnablePassthrough(),
                queries=generate_queries
            )
            | RunnableParallel(
                question=itemgetter("question"),
                context=itemgetter("queries") | RunnableLambda(retrieve_all) | RunnableLambda(format_docs)
            )
            | qa_prompt
            | self.llm
            | StrOutputParser()
        )
        
        return multi_query_rag


# ==================== CUSTOM COMPONENTS ====================

from langchain_core.retrievers import BaseRetriever
from langchain_core.documents import Document
from langchain_core.callbacks import CallbackManagerForRetrieverRun

class VietnameseEnvironmentalRetriever(BaseRetriever):
    """
    Custom retriever for Vietnamese environmental documents.
    
    Features:
    - Vietnamese text normalization
    - Metadata filtering
    - Hybrid search (semantic + keyword)
    """
    
    vectorstore: Chroma
    search_kwargs: dict = {"k": 5}
    filter_domain: Optional[str] = None
    filter_year: Optional[int] = None
    use_hybrid: bool = False
    bm25_weight: float = 0.3
    
    class Config:
        arbitrary_types_allowed = True
    
    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun
    ) -> List[Document]:
        """Retrieve relevant documents."""
        
        # Normalize Vietnamese query
        query = self._normalize_vietnamese(query)
        
        # Build filter
        filter_dict = {}
        if self.filter_domain:
            filter_dict["domain"] = self.filter_domain
        if self.filter_year:
            filter_dict["year"] = {"$gte": self.filter_year}
        
        # Semantic search
        if filter_dict:
            docs = self.vectorstore.similarity_search(
                query,
                filter=filter_dict,
                **self.search_kwargs
            )
        else:
            docs = self.vectorstore.similarity_search(
                query,
                **self.search_kwargs
            )
        
        return docs
    
    def _normalize_vietnamese(self, text: str) -> str:
        """Normalize Vietnamese text."""
        import unicodedata
        text = unicodedata.normalize('NFC', text)
        return text.strip()


# Usage example
if __name__ == "__main__":
    # Basic LCEL
    basics = LCELBasics()
    
    # Simple chain
    simple_chain = basics.simple_chain()
    # result = simple_chain.invoke({"question": "QCVN 40:2011 quy định gì?"})
    
    # Parallel chain
    parallel_chain = basics.parallel_chain()
    # result = parallel_chain.invoke({"text": "Nước thải công nghiệp phải xử lý đạt QCVN..."})
    
    # Structured output
    structured = StructuredOutputChain()
    analysis_chain = structured.create_analysis_chain()
    # result = analysis_chain.invoke({"situation": "Nhà máy xả nước thải vượt BOD5..."})
    
    # RAG with LCEL
    rag = LCELRagChain()
    rag_chain = rag.create_rag_with_sources()
    # result = rag_chain.invoke("Giới hạn BOD5 là bao nhiêu?")
    
    print("LangChain LCEL examples ready!")
```

### Ngày 3-4: LlamaIndex Deep Dive

#### 2.1 LlamaIndex Architecture

```python
# ============================================
# LLAMAINDEX DEEP DIVE
# ============================================

from llama_index.core import (
    VectorStoreIndex,
    SimpleDirectoryReader,
    Document,
    Settings,
    StorageContext,
    load_index_from_storage
)
from llama_index.core.node_parser import (
    SentenceSplitter,
    SemanticSplitterNodeParser,
    HierarchicalNodeParser
)
from llama_index.core.retrievers import (
    VectorIndexRetriever,
    RouterRetriever
)
from llama_index.core.query_engine import (
    RetrieverQueryEngine,
    RouterQueryEngine,
    SubQuestionQueryEngine
)
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.core.response_synthesizers import (
    get_response_synthesizer,
    ResponseMode
)
from llama_index.core.postprocessor import (
    SimilarityPostprocessor,
    KeywordNodePostprocessor,
    MetadataReplacementPostProcessor
)
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.vector_stores.chroma import ChromaVectorStore
import chromadb
from typing import List, Dict, Optional
import os

# ==================== GLOBAL SETTINGS ====================

def configure_llamaindex():
    """Configure global LlamaIndex settings."""
    
    Settings.llm = OpenAI(
        model="gpt-4-turbo-preview",
        temperature=0.3
    )
    
    Settings.embed_model = OpenAIEmbedding(
        model="text-embedding-3-small"
    )
    
    Settings.chunk_size = 1024
    Settings.chunk_overlap = 200

configure_llamaindex()


# ==================== DOCUMENT LOADING ====================

class VietnameseDocumentLoader:
    """
    Custom document loader for Vietnamese environmental documents.
    """
    
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
    
    def load_documents(self) -> List[Document]:
        """Load documents with Vietnamese-specific processing."""
        
        # Use SimpleDirectoryReader for basic loading
        reader = SimpleDirectoryReader(
            input_dir=self.data_dir,
            recursive=True,
            filename_as_id=True,
            file_extractor={
                ".pdf": self._extract_pdf,
                ".docx": self._extract_docx,
            }
        )
        
        documents = reader.load_data()
        
        # Add Vietnamese-specific metadata
        for doc in documents:
            doc.metadata = self._extract_metadata(doc)
        
        return documents
    
    def _extract_pdf(self, file_path: str) -> List[Document]:
        """Extract text from PDF with Vietnamese support."""
        # Implementation would use PyMuPDF or similar
        pass
    
    def _extract_docx(self, file_path: str) -> List[Document]:
        """Extract text from DOCX."""
        # Implementation would use python-docx
        pass
    
    def _extract_metadata(self, doc: Document) -> Dict:
        """Extract metadata from document content."""
        import re
        
        content = doc.text
        metadata = doc.metadata.copy()
        
        # Extract QCVN/TCVN references
        qcvn_pattern = r'QCVN\s+(\d+):(\d{4})/(\w+)'
        matches = re.findall(qcvn_pattern, content)
        if matches:
            metadata['qcvn_refs'] = [f"QCVN {m[0]}:{m[1]}/{m[2]}" for m in matches]
        
        # Extract article references
        article_pattern = r'Điều\s+(\d+)'
        articles = re.findall(article_pattern, content)
        if articles:
            metadata['articles'] = list(set(articles))
        
        return metadata
    
    def create_documents_from_regulations(
        self,
        regulations: List[Dict]
    ) -> List[Document]:
        """Create LlamaIndex documents from regulation data."""
        
        documents = []
        
        for reg in regulations:
            doc = Document(
                text=reg['content'],
                metadata={
                    'doc_number': reg.get('doc_number'),
                    'doc_type': reg.get('doc_type'),
                    'domain': reg.get('domain'),
                    'year': reg.get('year'),
                    'status': reg.get('status', 'active'),
                    'article': reg.get('article'),
                },
                doc_id=reg.get('id')
            )
            documents.append(doc)
        
        return documents


# ==================== NODE PARSING ====================

class VietnameseNodeParser:
    """
    Node parsers optimized for Vietnamese legal documents.
    """
    
    @staticmethod
    def get_sentence_splitter(
        chunk_size: int = 1024,
        chunk_overlap: int = 200
    ) -> SentenceSplitter:
        """Basic sentence splitter."""
        return SentenceSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            separator=". ",
            paragraph_separator="\n\n"
        )
    
    @staticmethod
    def get_semantic_splitter() -> SemanticSplitterNodeParser:
        """Semantic splitter based on embedding similarity."""
        return SemanticSplitterNodeParser(
            buffer_size=1,
            breakpoint_percentile_threshold=95,
            embed_model=Settings.embed_model
        )
    
    @staticmethod
    def get_hierarchical_splitter() -> HierarchicalNodeParser:
        """
        Hierarchical splitter for Vietnamese legal document structure.
        
        Structure:
        - Level 1: Chương (Chapter) - 2048 tokens
        - Level 2: Điều (Article) - 1024 tokens
        - Level 3: Khoản (Clause) - 512 tokens
        """
        return HierarchicalNodeParser.from_defaults(
            chunk_sizes=[2048, 1024, 512]
        )
    
    @staticmethod
    def create_vietnamese_article_parser():
        """
        Custom parser that splits by Vietnamese legal article structure.
        """
        import re
        from llama_index.core.node_parser import NodeParser
        from llama_index.core.schema import TextNode
        
        class VietnameseArticleParser(NodeParser):
            """Parse Vietnamese legal documents by article."""
            
            def _parse_nodes(
                self,
                documents: List[Document],
                show_progress: bool = False
            ) -> List[TextNode]:
                nodes = []
                
                for doc in documents:
                    text = doc.text
                    
                    # Split by Điều
                    article_pattern = r'(Điều\s+\d+[a-z]?\..*?)(?=Điều\s+\d+[a-z]?\.|$)'
                    articles = re.findall(article_pattern, text, re.DOTALL)
                    
                    for i, article in enumerate(articles):
                        # Extract article number
                        article_num_match = re.match(r'Điều\s+(\d+[a-z]?)\.', article)
                        article_num = article_num_match.group(1) if article_num_match else str(i+1)
                        
                        node = TextNode(
                            text=article.strip(),
                            metadata={
                                **doc.metadata,
                                'article': f'Điều {article_num}',
                                'node_type': 'article'
                            }
                        )
                        nodes.append(node)
                
                return nodes
        
        return VietnameseArticleParser()


# ==================== INDEX CREATION ====================

class EnvironmentalIndexBuilder:
    """
    Build and manage LlamaIndex indexes for environmental documents.
    """
    
    def __init__(
        self,
        persist_dir: str = "./storage",
        collection_name: str = "environmental_docs"
    ):
        self.persist_dir = persist_dir
        self.collection_name = collection_name
        
        # Initialize Chroma
        self.chroma_client = chromadb.PersistentClient(path=persist_dir)
        self.chroma_collection = self.chroma_client.get_or_create_collection(
            name=collection_name
        )
        
        self.vector_store = ChromaVectorStore(
            chroma_collection=self.chroma_collection
        )
        
        self.index = None
    
    def build_index(
        self,
        documents: List[Document],
        node_parser=None
    ) -> VectorStoreIndex:
        """Build vector store index from documents."""
        
        if node_parser is None:
            node_parser = VietnameseNodeParser.get_sentence_splitter()
        
        # Create storage context
        storage_context = StorageContext.from_defaults(
            vector_store=self.vector_store
        )
        
        # Build index
        self.index = VectorStoreIndex.from_documents(
            documents,
            storage_context=storage_context,
            transformations=[node_parser],
            show_progress=True
        )
        
        return self.index
    
    def load_index(self) -> VectorStoreIndex:
        """Load existing index from storage."""
        
        storage_context = StorageContext.from_defaults(
            vector_store=self.vector_store,
            persist_dir=self.persist_dir
        )
        
        self.index = load_index_from_storage(storage_context)
        
        return self.index
    
    def add_documents(self, documents: List[Document]):
        """Add documents to existing index."""
        
        if self.index is None:
            raise ValueError("Index not initialized. Build or load index first.")
        
        for doc in documents:
            self.index.insert(doc)


# ==================== QUERY ENGINES ====================

class EnvironmentalQueryEngines:
    """
    Different query engine configurations for environmental Q&A.
    """
    
    def __init__(self, index: VectorStoreIndex):
        self.index = index
    
    def get_basic_query_engine(
        self,
        similarity_top_k: int = 5
    ):
        """Basic query engine with similarity search."""
        
        return self.index.as_query_engine(
            similarity_top_k=similarity_top_k,
            response_mode=ResponseMode.COMPACT
        )
    
    def get_query_engine_with_postprocessors(
        self,
        similarity_top_k: int = 10,
        similarity_cutoff: float = 0.7,
        required_keywords: List[str] = None
    ):
        """Query engine with post-processing filters."""
        
        # Retriever
        retriever = VectorIndexRetriever(
            index=self.index,
            similarity_top_k=similarity_top_k
        )
        
        # Post-processors
        postprocessors = [
            SimilarityPostprocessor(similarity_cutoff=similarity_cutoff)
        ]
        
        if required_keywords:
            postprocessors.append(
                KeywordNodePostprocessor(
                    required_keywords=required_keywords
                )
            )
        
        # Response synthesizer
        response_synthesizer = get_response_synthesizer(
            response_mode=ResponseMode.TREE_SUMMARIZE,
            use_async=False
        )
        
        # Query engine
        query_engine = RetrieverQueryEngine(
            retriever=retriever,
            node_postprocessors=postprocessors,
            response_synthesizer=response_synthesizer
        )
        
        return query_engine
    
    def get_sub_question_query_engine(
        self,
        query_engine_tools: List[QueryEngineTool] = None
    ):
        """
        Query engine that breaks complex questions into sub-questions.
        
        Good for questions that span multiple topics.
        """
        
        if query_engine_tools is None:
            # Create default tools from the index
            query_engine_tools = [
                QueryEngineTool(
                    query_engine=self.index.as_query_engine(),
                    metadata=ToolMetadata(
                        name="environmental_regulations",
                        description="Tìm kiếm quy định môi trường Việt Nam"
                    )
                )
            ]
        
        query_engine = SubQuestionQueryEngine.from_defaults(
            query_engine_tools=query_engine_tools,
            use_async=True,
            verbose=True
        )
        
        return query_engine
    
    def get_router_query_engine(
        self,
        domain_indexes: Dict[str, VectorStoreIndex]
    ):
        """
        Router that directs queries to domain-specific indexes.
        
        Args:
            domain_indexes: Dict mapping domain names to indexes
                e.g., {"water": water_index, "air": air_index}
        """
        
        query_engine_tools = []
        
        domain_descriptions = {
            "water": "Quy định về nước thải, chất lượng nước, QCVN 40:2011",
            "air": "Quy định về khí thải, chất lượng không khí, QCVN 05:2023",
            "waste": "Quy định về chất thải rắn, chất thải nguy hại",
            "eia": "Quy định về đánh giá tác động môi trường (ĐTM)",
            "permit": "Quy định về giấy phép môi trường"
        }
        
        for domain, index in domain_indexes.items():
            tool = QueryEngineTool(
                query_engine=index.as_query_engine(),
                metadata=ToolMetadata(
                    name=f"{domain}_regulations",
                    description=domain_descriptions.get(domain, f"Quy định về {domain}")
                )
            )
            query_engine_tools.append(tool)
        
        query_engine = RouterQueryEngine.from_defaults(
            query_engine_tools=query_engine_tools,
            select_multi=True  # Can select multiple tools
        )
        
        return query_engine


# ==================== ADVANCED RETRIEVAL ====================

class AdvancedLlamaIndexRetrieval:
    """
    Advanced retrieval techniques with LlamaIndex.
    """
    
    def __init__(self, index: VectorStoreIndex):
        self.index = index
    
    def create_auto_merging_retriever(self):
        """
        Auto-merging retriever for hierarchical document structure.
        
        Retrieves leaf nodes, then merges to parent if threshold met.
        """
        from llama_index.core.retrievers import AutoMergingRetriever
        from llama_index.core.storage.docstore import SimpleDocumentStore
        
        # Need hierarchical index
        retriever = AutoMergingRetriever(
            vector_retriever=self.index.as_retriever(similarity_top_k=12),
            storage_context=self.index.storage_context,
            verbose=True
        )
        
        return retriever
    
    def create_sentence_window_retriever(self):
        """
        Sentence window retriever for precise matching with context expansion.
        """
        from llama_index.core.postprocessor import MetadataReplacementPostProcessor
        
        # The index should be built with sentence window nodes
        # that have 'window' metadata containing surrounding context
        
        retriever = self.index.as_retriever(similarity_top_k=5)
        
        # Replace retrieved sentence with full window
        postprocessor = MetadataReplacementPostProcessor(
            target_metadata_key="window"
        )
        
        return retriever, postprocessor
    
    def create_hybrid_retriever(self):
        """
        Hybrid retriever combining vector and keyword search.
        """
        from llama_index.core.retrievers import QueryFusionRetriever
        from llama_index.retrievers.bm25 import BM25Retriever
        
        # Vector retriever
        vector_retriever = self.index.as_retriever(similarity_top_k=5)
        
        # BM25 retriever (need to build separately)
        # bm25_retriever = BM25Retriever.from_defaults(
        #     nodes=self.index.docstore.docs.values(),
        #     similarity_top_k=5
        # )
        
        # Fusion retriever
        # retriever = QueryFusionRetriever(
        #     retrievers=[vector_retriever, bm25_retriever],
        #     similarity_top_k=5,
        #     num_queries=1,  # Don't generate additional queries
        #     mode="reciprocal_rerank"
        # )
        
        return vector_retriever


# ==================== CUSTOM RESPONSE SYNTHESIS ====================

class VietnameseResponseSynthesizer:
    """
    Custom response synthesizer for Vietnamese environmental Q&A.
    """
    
    @staticmethod
    def get_vietnamese_qa_prompt():
        """Get Vietnamese QA prompt template."""
        from llama_index.core import PromptTemplate
        
        template = """Bạn là chuyên gia tư vấn pháp luật môi trường Việt Nam.

Dưới đây là thông tin từ các văn bản pháp luật:
---------------------
{context_str}
---------------------

Dựa vào thông tin trên, hãy trả lời câu hỏi sau:
{query_str}

Yêu cầu:
1. Trả lời chính xác dựa trên thông tin được cung cấp
2. Trích dẫn số hiệu văn bản và điều khoản cụ thể
3. Nếu thông tin không có trong nguồn, nói rõ
4. Sử dụng ngôn ngữ chuyên môn nhưng dễ hiểu

Trả lời:"""
        
        return PromptTemplate(template)
    
    @staticmethod
    def get_compliance_check_prompt():
        """Get compliance checking prompt."""
        from llama_index.core import PromptTemplate
        
        template = """Kiểm tra tuân thủ môi trường.

QUY ĐỊNH:
{context_str}

TÌNH HUỐNG CẦN KIỂM TRA:
{query_str}

Phân tích theo format:

## Quy định áp dụng
[Liệt kê các quy định liên quan]

## Đánh giá tuân thủ
| Thông số | Giá trị | Giới hạn | Kết quả |
|----------|---------|----------|---------|

## Kết luận
[ĐẠT / KHÔNG ĐẠT]

## Khuyến nghị
[Nếu có]"""
        
        return PromptTemplate(template)


# Usage example
if __name__ == "__main__":
    # Configure settings
    configure_llamaindex()
    
    # Create sample documents
    sample_docs = [
        Document(
            text="""Điều 5. Giá trị giới hạn các thông số ô nhiễm
            1. BOD5 không vượt quá 30 mg/L đối với cột A
            2. BOD5 không vượt quá 50 mg/L đối với cột B""",
            metadata={
                "doc_number": "QCVN 40:2011/BTNMT",
                "domain": "water_quality"
            }
        )
    ]
    
    # Build index
    builder = EnvironmentalIndexBuilder(persist_dir="./test_storage")
    index = builder.build_index(sample_docs)
    
    # Create query engine
    engines = EnvironmentalQueryEngines(index)
    query_engine = engines.get_basic_query_engine()
    
    # Query
    # response = query_engine.query("Giới hạn BOD5 là bao nhiêu?")
    # print(response)
    
    print("LlamaIndex setup complete!")
```

### Ngày 5-6: Framework Comparison

#### 3.1 Side-by-side Comparison

```python
# ============================================
# LANGCHAIN VS LLAMAINDEX COMPARISON
# ============================================

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import time
import asyncio

@dataclass
class BenchmarkResult:
    """Result from benchmark test."""
    framework: str
    task: str
    latency_ms: float
    tokens_used: int
    answer_quality: float  # 0-1
    memory_mb: float
    error: Optional[str] = None

class FrameworkComparison:
    """
    Compare LangChain and LlamaIndex for various RAG tasks.
    """
    
    # Comparison matrix
    COMPARISON_MATRIX = {
        "feature": {
            "LangChain": {
                "LCEL composition": "⭐⭐⭐⭐⭐",
                "Agent support": "⭐⭐⭐⭐⭐",
                "Memory management": "⭐⭐⭐⭐",
                "Tool/Function calling": "⭐⭐⭐⭐⭐",
                "Streaming": "⭐⭐⭐⭐⭐",
                "Production ready": "⭐⭐⭐⭐",
                "Documentation": "⭐⭐⭐⭐",
                "Community": "⭐⭐⭐⭐⭐"
            },
            "LlamaIndex": {
                "Data indexing": "⭐⭐⭐⭐⭐",
                "Query engines": "⭐⭐⭐⭐⭐",
                "Document parsing": "⭐⭐⭐⭐⭐",
                "Retrieval strategies": "⭐⭐⭐⭐⭐",
                "Evaluation": "⭐⭐⭐⭐",
                "Production ready": "⭐⭐⭐⭐",
                "Documentation": "⭐⭐⭐⭐⭐",
                "Community": "⭐⭐⭐⭐"
            }
        },
        "use_case": {
            "Simple RAG": "Both equal",
            "Complex document processing": "LlamaIndex",
            "Multi-agent systems": "LangChain",
            "Conversational AI": "LangChain",
            "Knowledge base QA": "LlamaIndex",
            "Tool/API integration": "LangChain",
            "Structured data extraction": "Both equal",
            "Production deployment": "Both equal"
        }
    }
    
    def __init__(
        self,
        langchain_rag,
        llamaindex_rag
    ):
        self.langchain = langchain_rag
        self.llamaindex = llamaindex_rag
        self.results = []
    
    def benchmark_query(
        self,
        query: str,
        ground_truth: Optional[str] = None
    ) -> Dict[str, BenchmarkResult]:
        """Run same query on both frameworks and compare."""
        
        results = {}
        
        # LangChain
        lc_result = self._run_langchain(query, ground_truth)
        results["langchain"] = lc_result
        
        # LlamaIndex
        li_result = self._run_llamaindex(query, ground_truth)
        results["llamaindex"] = li_result
        
        self.results.append({
            "query": query,
            "results": results
        })
        
        return results
    
    def _run_langchain(
        self,
        query: str,
        ground_truth: Optional[str]
    ) -> BenchmarkResult:
        """Run query with LangChain."""
        import tracemalloc
        
        tracemalloc.start()
        start_time = time.perf_counter()
        
        try:
            response = self.langchain.invoke(query)
            
            latency = (time.perf_counter() - start_time) * 1000
            current, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            
            # Evaluate quality if ground truth provided
            quality = self._evaluate_quality(
                str(response), 
                ground_truth
            ) if ground_truth else 0.0
            
            return BenchmarkResult(
                framework="LangChain",
                task="query",
                latency_ms=latency,
                tokens_used=0,  # Would need to track from response
                answer_quality=quality,
                memory_mb=peak / 1024 / 1024
            )
            
        except Exception as e:
            tracemalloc.stop()
            return BenchmarkResult(
                framework="LangChain",
                task="query",
                latency_ms=0,
                tokens_used=0,
                answer_quality=0,
                memory_mb=0,
                error=str(e)
            )
    
    def _run_llamaindex(
        self,
        query: str,
        ground_truth: Optional[str]
    ) -> BenchmarkResult:
        """Run query with LlamaIndex."""
        import tracemalloc
        
        tracemalloc.start()
        start_time = time.perf_counter()
        
        try:
            response = self.llamaindex.query(query)
            
            latency = (time.perf_counter() - start_time) * 1000
            current, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            
            quality = self._evaluate_quality(
                str(response),
                ground_truth
            ) if ground_truth else 0.0
            
            return BenchmarkResult(
                framework="LlamaIndex",
                task="query",
                latency_ms=latency,
                tokens_used=0,
                answer_quality=quality,
                memory_mb=peak / 1024 / 1024
            )
            
        except Exception as e:
            tracemalloc.stop()
            return BenchmarkResult(
                framework="LlamaIndex",
                task="query",
                latency_ms=0,
                tokens_used=0,
                answer_quality=0,
                memory_mb=0,
                error=str(e)
            )
    
    def _evaluate_quality(
        self,
        answer: str,
        ground_truth: str
    ) -> float:
        """Simple quality evaluation based on overlap."""
        if not ground_truth:
            return 0.0
        
        # Extract key terms from ground truth
        ground_terms = set(ground_truth.lower().split())
        answer_terms = set(answer.lower().split())
        
        overlap = len(ground_terms & answer_terms)
        return overlap / len(ground_terms) if ground_terms else 0.0
    
    def generate_report(self) -> str:
        """Generate comparison report."""
        
        report = ["# Framework Comparison Report", ""]
        
        # Summary statistics
        lc_latencies = [r["results"]["langchain"].latency_ms for r in self.results if not r["results"]["langchain"].error]
        li_latencies = [r["results"]["llamaindex"].latency_ms for r in self.results if not r["results"]["llamaindex"].error]
        
        report.append("## Summary")
        report.append("")
        report.append("| Metric | LangChain | LlamaIndex |")
        report.append("|--------|-----------|------------|")
        
        if lc_latencies and li_latencies:
            report.append(f"| Avg Latency (ms) | {sum(lc_latencies)/len(lc_latencies):.2f} | {sum(li_latencies)/len(li_latencies):.2f} |")
        
        lc_quality = [r["results"]["langchain"].answer_quality for r in self.results if not r["results"]["langchain"].error]
        li_quality = [r["results"]["llamaindex"].answer_quality for r in self.results if not r["results"]["llamaindex"].error]
        
        if lc_quality and li_quality:
            report.append(f"| Avg Quality | {sum(lc_quality)/len(lc_quality):.2f} | {sum(li_quality)/len(li_quality):.2f} |")
        
        report.append("")
        
        # Feature comparison
        report.append("## Feature Comparison")
        report.append("")
        report.append("### LangChain Strengths")
        for feature, rating in self.COMPARISON_MATRIX["feature"]["LangChain"].items():
            report.append(f"- {feature}: {rating}")
        
        report.append("")
        report.append("### LlamaIndex Strengths")
        for feature, rating in self.COMPARISON_MATRIX["feature"]["LlamaIndex"].items():
            report.append(f"- {feature}: {rating}")
        
        report.append("")
        
        # Use case recommendations
        report.append("## Use Case Recommendations")
        report.append("")
        for use_case, recommendation in self.COMPARISON_MATRIX["use_case"].items():
            report.append(f"- **{use_case}**: {recommendation}")
        
        return "\n".join(report)
    
    @staticmethod
    def get_selection_guide() -> str:
        """Get guide for choosing framework."""
        
        return """
# Framework Selection Guide

## Choose LangChain when:
- Building conversational AI with complex memory
- Need extensive tool/function calling
- Building multi-agent systems
- Want maximum flexibility in chain composition
- Integrating many external APIs/services

## Choose LlamaIndex when:
- Primary focus is document QA/search
- Need advanced document parsing
- Building knowledge base applications
- Want specialized retrieval strategies
- Need structured data extraction from documents

## Use Both when:
- Complex enterprise applications
- Different components need different strengths
- LangChain for orchestration + LlamaIndex for retrieval

## Environmental Domain Recommendation:
For Vietnamese Environmental Compliance RAG:
- **Document Indexing**: LlamaIndex (better document structure handling)
- **Query Processing**: Either (similar capability)
- **Agent/Tool Use**: LangChain (compliance checking tools)
- **Production**: LangChain (better observability with LangSmith)

**Recommended Architecture**:
- Use LlamaIndex for document processing and indexing
- Use LangChain for chain composition and agent orchestration
- Combine via LangChain's LlamaIndex integration
"""
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: LangChain LCEL Mastery (Ngày 1-2)

```
🎯 Mục tiêu: Thành thạo LCEL composition

📋 Yêu cầu:
1. Build RAG chain với LCEL
2. Implement multi-query generation
3. Add structured output với Pydantic
4. Create conversational RAG với memory

📁 Deliverables:
- src/chains/lcel_rag.py
- src/chains/structured_output.py
- tests/test_lcel_chains.py
```

### Bài tập 2: LlamaIndex Query Engines (Ngày 3-4)

```
🎯 Mục tiêu: Master LlamaIndex query engines

📋 Yêu cầu:
1. Build hierarchical index cho legal docs
2. Implement sub-question query engine
3. Create router for domain-specific queries
4. Add custom Vietnamese node parser

📁 Deliverables:
- src/indexes/environmental_index.py
- src/query_engines/advanced_engines.py
- Custom node parser
```

### Bài tập 3: Framework Comparison (Ngày 5-7)

```
🎯 Mục tiêu: Compare và benchmark frameworks

📋 Yêu cầu:
1. Build same RAG với cả hai frameworks
2. Benchmark performance (latency, quality)
3. Document pros/cons
4. Choose optimal for Environmental RAG

📁 Deliverables:
- Benchmark code
- Comparison report
- **PROJECT 2 Continued**: Enhanced RAG với chosen framework
```

---

## ✅ CHECKLIST TUẦN 6

### Kiến thức đã học
- [ ] LangChain LCEL composition
- [ ] LangChain memory và chat history
- [ ] LlamaIndex index types
- [ ] LlamaIndex query engines
- [ ] Framework comparison và selection

### Skills thực hành
- [ ] Build chains với LCEL
- [ ] Create custom retrievers
- [ ] Implement query engines
- [ ] Benchmark và compare frameworks

### Deliverables
- [ ] LCEL-based RAG chain
- [ ] LlamaIndex query engines
- [ ] Framework comparison report
- [ ] Optimal architecture decision

---

*Hoàn thành Tuần 6 để tiếp tục sang Tuần 7: Production RAG Optimization*
