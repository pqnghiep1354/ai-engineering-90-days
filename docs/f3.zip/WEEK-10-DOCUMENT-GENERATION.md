# 📅 TUẦN 10: DOCUMENT GENERATION PIPELINE

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Build automated document generation pipelines |
| **Output** | Environmental Report Generation System |
| **Độ khó** | ⭐⭐⭐⭐ Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu document generation architectures
- [ ] Nắm vững template engines và dynamic content
- [ ] Hiểu PDF/DOCX generation
- [ ] Biết quality assurance cho generated content

### Kỹ năng (Skills)
- [ ] Build template-based generation systems
- [ ] Implement structured document pipelines
- [ ] Create multi-format export (PDF, DOCX, HTML)
- [ ] Add charts và visualizations

### Ứng dụng (Application)
- [ ] Environmental Compliance Report Generator
- [ ] Automated monitoring report creation
- [ ] Professional document templates

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: Document Generation Architecture

#### 1.1 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DOCUMENT GENERATION PIPELINE                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                         INPUT LAYER                                  │    │
│  │                                                                      │    │
│  │   Data Sources        Templates          User Input                 │    │
│  │   ┌──────────┐       ┌──────────┐       ┌──────────┐               │    │
│  │   │ Database │       │  Jinja2  │       │  Config  │               │    │
│  │   │   API    │       │ Markdown │       │  Params  │               │    │
│  │   │   RAG    │       │  DOCX    │       │  Style   │               │    │
│  │   └──────────┘       └──────────┘       └──────────┘               │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                               │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      PROCESSING LAYER                                │    │
│  │                                                                      │    │
│  │   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │    │
│  │   │   Content    │  │    LLM       │  │    Data      │             │    │
│  │   │  Extraction  │──│  Generation  │──│ Formatting   │             │    │
│  │   └──────────────┘  └──────────────┘  └──────────────┘             │    │
│  │                                                                      │    │
│  │   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐             │    │
│  │   │    Chart     │  │   Table      │  │   Image      │             │    │
│  │   │  Generation  │  │  Formatting  │  │  Processing  │             │    │
│  │   └──────────────┘  └──────────────┘  └──────────────┘             │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                               │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      ASSEMBLY LAYER                                  │    │
│  │                                                                      │    │
│  │   Template + Data ──▶ Document Assembly ──▶ Quality Check           │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                              │                                               │
│                              ▼                                               │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                       OUTPUT LAYER                                   │    │
│  │                                                                      │    │
│  │   ┌──────────┐       ┌──────────┐       ┌──────────┐               │    │
│  │   │   PDF    │       │   DOCX   │       │   HTML   │               │    │
│  │   └──────────┘       └──────────┘       └──────────┘               │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 Template Engine Setup

```python
# ============================================
# DOCUMENT TEMPLATE ENGINE
# ============================================

from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape
from enum import Enum
import json

class DocumentFormat(Enum):
    """Supported document formats."""
    PDF = "pdf"
    DOCX = "docx"
    HTML = "html"
    MARKDOWN = "markdown"

@dataclass
class DocumentConfig:
    """Configuration for document generation."""
    title: str
    template_name: str
    output_format: DocumentFormat
    output_path: str
    
    # Metadata
    author: str = "Environmental Compliance System"
    organization: str = ""
    version: str = "1.0"
    
    # Styling
    theme: str = "professional"
    logo_path: Optional[str] = None
    primary_color: str = "#2C3E50"
    
    # Options
    include_toc: bool = True
    include_page_numbers: bool = True
    include_header_footer: bool = True
    
    # Quality
    spell_check: bool = True
    grammar_check: bool = False

@dataclass
class DocumentSection:
    """A section in the document."""
    id: str
    title: str
    content: str
    level: int = 1  # Header level
    order: int = 0
    subsections: List['DocumentSection'] = field(default_factory=list)
    
    # Rich content
    tables: List[Dict] = field(default_factory=list)
    charts: List[Dict] = field(default_factory=list)
    images: List[Dict] = field(default_factory=list)

class TemplateEngine:
    """
    Jinja2-based template engine for document generation.
    """
    
    def __init__(self, template_dir: str = "./templates"):
        self.template_dir = Path(template_dir)
        self.template_dir.mkdir(exist_ok=True)
        
        # Setup Jinja2 environment
        self.env = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            autoescape=select_autoescape(['html', 'xml']),
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Register custom filters
        self._register_filters()
    
    def _register_filters(self):
        """Register custom Jinja2 filters."""
        
        # Date formatting
        def format_date(value, format_str="%d/%m/%Y"):
            if isinstance(value, str):
                value = datetime.fromisoformat(value)
            return value.strftime(format_str)
        
        # Number formatting
        def format_number(value, decimals=2):
            return f"{value:,.{decimals}f}"
        
        # Vietnamese currency
        def format_vnd(value):
            return f"{value:,.0f} VNĐ"
        
        # Status badge
        def status_badge(value, positive="ĐẠT", negative="KHÔNG ĐẠT"):
            if isinstance(value, bool):
                return positive if value else negative
            return value
        
        # Risk level color
        def risk_color(level):
            colors = {
                "LOW": "#27ae60",
                "MEDIUM": "#f39c12",
                "HIGH": "#e74c3c",
                "CRITICAL": "#8e44ad"
            }
            return colors.get(level.upper(), "#95a5a6")
        
        self.env.filters['format_date'] = format_date
        self.env.filters['format_number'] = format_number
        self.env.filters['format_vnd'] = format_vnd
        self.env.filters['status_badge'] = status_badge
        self.env.filters['risk_color'] = risk_color
    
    def render(self, template_name: str, data: Dict) -> str:
        """Render template with data."""
        template = self.env.get_template(template_name)
        return template.render(**data)
    
    def render_string(self, template_string: str, data: Dict) -> str:
        """Render template from string."""
        template = self.env.from_string(template_string)
        return template.render(**data)
    
    def create_template(self, name: str, content: str):
        """Create a new template file."""
        template_path = self.template_dir / name
        template_path.write_text(content, encoding='utf-8')


# ============================================
# PREDEFINED TEMPLATES
# ============================================

COMPLIANCE_REPORT_TEMPLATE = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config.title }}</title>
    <style>
        :root {
            --primary-color: {{ config.primary_color }};
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 210mm;
            margin: 0 auto;
            padding: 20mm;
        }
        
        .header {
            text-align: center;
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: var(--primary-color);
            margin-bottom: 10px;
        }
        
        .header .subtitle {
            color: #666;
            font-size: 14px;
        }
        
        .meta-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 30px;
        }
        
        .meta-info .label {
            font-weight: bold;
            color: #555;
        }
        
        .summary-box {
            background: linear-gradient(135deg, var(--primary-color), #34495e);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        
        .summary-box h2 {
            margin-top: 0;
            border-bottom: 1px solid rgba(255,255,255,0.3);
            padding-bottom: 10px;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
        }
        
        .status-compliant {
            background: #27ae60;
            color: white;
        }
        
        .status-non-compliant {
            background: #e74c3c;
            color: white;
        }
        
        .risk-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
            color: white;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        
        th {
            background: var(--primary-color);
            color: white;
        }
        
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        
        .section {
            margin-bottom: 30px;
        }
        
        .section h2 {
            color: var(--primary-color);
            border-left: 4px solid var(--primary-color);
            padding-left: 15px;
        }
        
        .recommendation {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin: 10px 0;
        }
        
        .chart-container {
            text-align: center;
            margin: 20px 0;
        }
        
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #666;
            font-size: 12px;
        }
        
        @media print {
            body {
                padding: 0;
            }
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        {% if config.logo_path %}
        <img src="{{ config.logo_path }}" alt="Logo" height="60">
        {% endif %}
        <h1>{{ config.title }}</h1>
        <div class="subtitle">{{ config.organization }}</div>
    </div>
    
    <!-- Meta Information -->
    <div class="meta-info">
        <div><span class="label">Cơ sở:</span> {{ facility_name }}</div>
        <div><span class="label">Kỳ báo cáo:</span> {{ period }}</div>
        <div><span class="label">Ngày lấy mẫu:</span> {{ monitoring_data.sampling_date | format_date }}</div>
        <div><span class="label">Vị trí:</span> {{ monitoring_data.sampling_location }}</div>
        <div><span class="label">Quy chuẩn:</span> {{ regulation_lookup.qcvn_applied }}</div>
        <div><span class="label">Ngày lập:</span> {{ generated_at | format_date }}</div>
    </div>
    
    <!-- Executive Summary -->
    <div class="summary-box">
        <h2>TÓM TẮT ĐIỀU HÀNH</h2>
        <p>
            <strong>Trạng thái tuân thủ:</strong>
            <span class="status-badge {% if compliance_check.overall_compliant %}status-compliant{% else %}status-non-compliant{% endif %}">
                {{ compliance_check.overall_compliant | status_badge }}
            </span>
        </p>
        <p>
            <strong>Mức độ rủi ro:</strong>
            <span class="risk-badge" style="background: {{ risk_assessment.risk_level | risk_color }}">
                {{ risk_assessment.risk_level }}
            </span>
        </p>
        <p>
            <strong>Tỷ lệ tuân thủ:</strong> {{ risk_assessment.compliance_rate }}%
        </p>
        <p>
            <strong>Số thông số:</strong> 
            {{ compliance_check.compliant_count }} đạt / 
            {{ compliance_check.non_compliant_count }} không đạt
        </p>
    </div>
    
    <!-- Detailed Results -->
    <div class="section">
        <h2>KẾT QUẢ CHI TIẾT</h2>
        
        <table>
            <thead>
                <tr>
                    <th>Thông số</th>
                    <th>Giá trị</th>
                    <th>Đơn vị</th>
                    <th>Giới hạn</th>
                    <th>Trạng thái</th>
                    <th>Vượt (%)</th>
                </tr>
            </thead>
            <tbody>
                {% for param, result in compliance_check.parameter_results.items() %}
                <tr>
                    <td><strong>{{ param }}</strong></td>
                    <td>{{ result.value | format_number }}</td>
                    <td>{{ result.unit }}</td>
                    <td>{{ result.limit }}</td>
                    <td>
                        <span class="status-badge {% if result.compliant %}status-compliant{% else %}status-non-compliant{% endif %}">
                            {{ result.status }}
                        </span>
                    </td>
                    <td>{{ result.exceedance_percent | format_number }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
    
    <!-- Risk Assessment -->
    <div class="section">
        <h2>ĐÁNH GIÁ RỦI RO</h2>
        
        <p>
            <strong>Mức độ rủi ro tổng thể:</strong>
            <span class="risk-badge" style="background: {{ risk_assessment.risk_level | risk_color }}">
                {{ risk_assessment.risk_level }}
            </span>
        </p>
        
        {% if risk_assessment.high_risk_parameters %}
        <h3>Các thông số rủi ro cao:</h3>
        <ul>
            {% for param in risk_assessment.high_risk_parameters %}
            <li><strong>{{ param.parameter }}</strong>: Vượt {{ param.exceedance | format_number }}%</li>
            {% endfor %}
        </ul>
        {% endif %}
    </div>
    
    <!-- Recommendations -->
    <div class="section">
        <h2>KHUYẾN NGHỊ</h2>
        
        {% for rec in risk_assessment.recommendations %}
        <div class="recommendation">
            {{ loop.index }}. {{ rec }}
        </div>
        {% endfor %}
    </div>
    
    <!-- Conclusion -->
    <div class="section">
        <h2>KẾT LUẬN</h2>
        <p>
            Cơ sở <strong>{{ facility_name }}</strong> 
            {% if compliance_check.overall_compliant %}
            <span style="color: #27ae60;"><strong>ĐẠT</strong></span> yêu cầu tuân thủ
            {% else %}
            <span style="color: #e74c3c;"><strong>KHÔNG ĐẠT</strong></span> yêu cầu tuân thủ
            {% endif %}
            theo {{ regulation_lookup.qcvn_applied }}.
        </p>
        {% if not compliance_check.overall_compliant %}
        <p style="color: #e74c3c;">
            ⚠️ Cần thực hiện ngay các biện pháp khắc phục để đảm bảo tuân thủ quy định.
        </p>
        {% endif %}
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <p>Báo cáo được tạo tự động bởi {{ config.author }}</p>
        <p>Phiên bản: {{ config.version }} | Ngày tạo: {{ generated_at | format_date('%d/%m/%Y %H:%M') }}</p>
    </div>
</body>
</html>
"""

MONITORING_REPORT_TEMPLATE = """
# BÁO CÁO QUAN TRẮC MÔI TRƯỜNG

## Thông tin chung

| Thông tin | Giá trị |
|-----------|---------|
| Cơ sở | {{ facility_name }} |
| Kỳ báo cáo | {{ period }} |
| Ngày lấy mẫu | {{ sampling_date }} |
| Đơn vị thực hiện | {{ organization }} |

## Kết quả quan trắc

{% for category, params in parameters.items() %}
### {{ category }}

| Thông số | Giá trị | Đơn vị | QCVN | Trạng thái |
|----------|---------|--------|------|------------|
{% for p in params %}
| {{ p.name }} | {{ p.value | format_number }} | {{ p.unit }} | {{ p.limit }} | {{ p.status }} |
{% endfor %}

{% endfor %}

## Nhận xét

{{ comments }}

## Đề xuất

{% for rec in recommendations %}
{{ loop.index }}. {{ rec }}
{% endfor %}

---
*Báo cáo được tạo tự động ngày {{ generated_at | format_date }}*
"""
```

### Ngày 3-4: PDF và DOCX Generation

#### 2.1 PDF Generation

```python
# ============================================
# PDF GENERATION
# ============================================

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime
import io

# Using weasyprint for HTML to PDF
# pip install weasyprint
from weasyprint import HTML, CSS

# Using reportlab for programmatic PDF
# pip install reportlab
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm, cm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    Image, PageBreak, ListFlowable, ListItem
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY

class PDFGenerator:
    """
    PDF document generator with multiple approaches.
    """
    
    def __init__(self, output_dir: str = "./output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Setup styles
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles."""
        
        # Vietnamese font support
        # Note: You may need to register Vietnamese fonts
        
        self.styles.add(ParagraphStyle(
            name='VNTitle',
            parent=self.styles['Title'],
            fontSize=24,
            textColor=colors.HexColor('#2C3E50'),
            spaceAfter=30
        ))
        
        self.styles.add(ParagraphStyle(
            name='VNHeading1',
            parent=self.styles['Heading1'],
            fontSize=16,
            textColor=colors.HexColor('#2C3E50'),
            spaceBefore=20,
            spaceAfter=10
        ))
        
        self.styles.add(ParagraphStyle(
            name='VNHeading2',
            parent=self.styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#34495E'),
            spaceBefore=15,
            spaceAfter=8
        ))
        
        self.styles.add(ParagraphStyle(
            name='VNBody',
            parent=self.styles['Normal'],
            fontSize=11,
            leading=16,
            alignment=TA_JUSTIFY
        ))
        
        self.styles.add(ParagraphStyle(
            name='VNCaption',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.grey,
            alignment=TA_CENTER
        ))
    
    def from_html(
        self,
        html_content: str,
        output_path: str,
        css_string: str = None
    ) -> str:
        """
        Generate PDF from HTML content using WeasyPrint.
        
        Best for complex layouts rendered from templates.
        """
        output_file = self.output_dir / output_path
        
        # Create HTML object
        html = HTML(string=html_content)
        
        # Apply CSS if provided
        stylesheets = []
        if css_string:
            stylesheets.append(CSS(string=css_string))
        
        # Generate PDF
        html.write_pdf(
            str(output_file),
            stylesheets=stylesheets
        )
        
        return str(output_file)
    
    def generate_compliance_report(
        self,
        data: Dict,
        output_path: str
    ) -> str:
        """
        Generate compliance report PDF using ReportLab.
        
        Provides more control over layout.
        """
        output_file = self.output_dir / output_path
        
        # Create document
        doc = SimpleDocTemplate(
            str(output_file),
            pagesize=A4,
            rightMargin=20*mm,
            leftMargin=20*mm,
            topMargin=20*mm,
            bottomMargin=20*mm
        )
        
        # Build content
        elements = []
        
        # Title
        elements.append(Paragraph(
            "BÁO CÁO TUÂN THỦ MÔI TRƯỜNG",
            self.styles['VNTitle']
        ))
        elements.append(Spacer(1, 10*mm))
        
        # Meta info table
        meta_data = [
            ['Cơ sở:', data.get('facility_name', '')],
            ['Kỳ báo cáo:', data.get('period', '')],
            ['Quy chuẩn:', data.get('regulation_lookup', {}).get('qcvn_applied', '')],
            ['Ngày lập:', datetime.now().strftime('%d/%m/%Y')]
        ]
        
        meta_table = Table(meta_data, colWidths=[40*mm, 120*mm])
        meta_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F5F5F5')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('PADDING', (0, 0), (-1, -1), 8),
        ]))
        
        elements.append(meta_table)
        elements.append(Spacer(1, 10*mm))
        
        # Executive Summary
        elements.append(Paragraph("TÓM TẮT ĐIỀU HÀNH", self.styles['VNHeading1']))
        
        compliance = data.get('compliance_check', {})
        risk = data.get('risk_assessment', {})
        
        status = "ĐẠT" if compliance.get('overall_compliant') else "KHÔNG ĐẠT"
        status_color = colors.green if compliance.get('overall_compliant') else colors.red
        
        summary_data = [
            ['Trạng thái:', status],
            ['Mức độ rủi ro:', risk.get('risk_level', 'N/A')],
            ['Tỷ lệ tuân thủ:', f"{risk.get('compliance_rate', 0)}%"],
            ['Thông số đạt:', str(compliance.get('compliant_count', 0))],
            ['Thông số không đạt:', str(compliance.get('non_compliant_count', 0))]
        ]
        
        summary_table = Table(summary_data, colWidths=[50*mm, 80*mm])
        summary_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('PADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ]))
        
        elements.append(summary_table)
        elements.append(Spacer(1, 10*mm))
        
        # Detailed Results
        elements.append(Paragraph("KẾT QUẢ CHI TIẾT", self.styles['VNHeading1']))
        
        # Results table
        param_results = compliance.get('parameter_results', {})
        
        results_header = ['Thông số', 'Giá trị', 'Đơn vị', 'Giới hạn', 'Trạng thái', 'Vượt (%)']
        results_data = [results_header]
        
        for param, result in param_results.items():
            results_data.append([
                param,
                str(result.get('value', '')),
                result.get('unit', ''),
                str(result.get('limit', '')),
                result.get('status', ''),
                str(result.get('exceedance_percent', 0))
            ])
        
        results_table = Table(results_data, colWidths=[30*mm, 25*mm, 20*mm, 30*mm, 30*mm, 25*mm])
        results_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2C3E50')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('PADDING', (0, 0), (-1, -1), 6),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F9F9F9')])
        ]))
        
        # Color code status column
        for i, (param, result) in enumerate(param_results.items(), start=1):
            if result.get('compliant'):
                results_table.setStyle(TableStyle([
                    ('TEXTCOLOR', (4, i), (4, i), colors.green)
                ]))
            else:
                results_table.setStyle(TableStyle([
                    ('TEXTCOLOR', (4, i), (4, i), colors.red)
                ]))
        
        elements.append(results_table)
        elements.append(Spacer(1, 10*mm))
        
        # Recommendations
        elements.append(Paragraph("KHUYẾN NGHỊ", self.styles['VNHeading1']))
        
        recommendations = risk.get('recommendations', [])
        if recommendations:
            rec_items = [
                ListItem(Paragraph(rec, self.styles['VNBody']))
                for rec in recommendations
            ]
            elements.append(ListFlowable(rec_items, bulletType='1'))
        
        elements.append(Spacer(1, 10*mm))
        
        # Conclusion
        elements.append(Paragraph("KẾT LUẬN", self.styles['VNHeading1']))
        
        conclusion = f"Cơ sở {data.get('facility_name', '')} "
        if compliance.get('overall_compliant'):
            conclusion += "ĐẠT yêu cầu tuân thủ "
        else:
            conclusion += "KHÔNG ĐẠT yêu cầu tuân thủ "
        conclusion += f"theo {data.get('regulation_lookup', {}).get('qcvn_applied', '')}."
        
        elements.append(Paragraph(conclusion, self.styles['VNBody']))
        
        # Build PDF
        doc.build(elements)
        
        return str(output_file)


# ============================================
# DOCX GENERATION
# ============================================

from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE

class DOCXGenerator:
    """
    DOCX document generator using python-docx.
    """
    
    def __init__(self, output_dir: str = "./output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
    
    def _setup_styles(self, doc: Document):
        """Setup custom styles for the document."""
        
        # Title style
        title_style = doc.styles.add_style('VNTitle', WD_STYLE_TYPE.PARAGRAPH)
        title_style.font.size = Pt(24)
        title_style.font.bold = True
        title_style.font.color.rgb = RGBColor(44, 62, 80)
        title_style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_style.paragraph_format.space_after = Pt(20)
        
        # Heading 1
        h1_style = doc.styles.add_style('VNHeading1', WD_STYLE_TYPE.PARAGRAPH)
        h1_style.font.size = Pt(16)
        h1_style.font.bold = True
        h1_style.font.color.rgb = RGBColor(44, 62, 80)
        h1_style.paragraph_format.space_before = Pt(18)
        h1_style.paragraph_format.space_after = Pt(10)
        
        # Heading 2
        h2_style = doc.styles.add_style('VNHeading2', WD_STYLE_TYPE.PARAGRAPH)
        h2_style.font.size = Pt(14)
        h2_style.font.bold = True
        h2_style.font.color.rgb = RGBColor(52, 73, 94)
        h2_style.paragraph_format.space_before = Pt(14)
        h2_style.paragraph_format.space_after = Pt(8)
    
    def generate_compliance_report(
        self,
        data: Dict,
        output_path: str
    ) -> str:
        """Generate compliance report as DOCX."""
        
        output_file = self.output_dir / output_path
        
        # Create document
        doc = Document()
        self._setup_styles(doc)
        
        # Title
        title = doc.add_paragraph("BÁO CÁO TUÂN THỦ MÔI TRƯỜNG", style='VNTitle')
        
        # Subtitle
        subtitle = doc.add_paragraph()
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = subtitle.add_run(data.get('facility_name', ''))
        run.font.size = Pt(14)
        run.font.color.rgb = RGBColor(127, 140, 141)
        
        # Meta info table
        doc.add_paragraph("THÔNG TIN CHUNG", style='VNHeading1')
        
        meta_table = doc.add_table(rows=4, cols=2)
        meta_table.style = 'Table Grid'
        
        meta_data = [
            ('Cơ sở:', data.get('facility_name', '')),
            ('Kỳ báo cáo:', data.get('period', '')),
            ('Quy chuẩn áp dụng:', data.get('regulation_lookup', {}).get('qcvn_applied', '')),
            ('Ngày lập báo cáo:', datetime.now().strftime('%d/%m/%Y'))
        ]
        
        for i, (label, value) in enumerate(meta_data):
            meta_table.rows[i].cells[0].text = label
            meta_table.rows[i].cells[1].text = value
            meta_table.rows[i].cells[0].paragraphs[0].runs[0].bold = True
        
        # Executive Summary
        doc.add_paragraph("TÓM TẮT ĐIỀU HÀNH", style='VNHeading1')
        
        compliance = data.get('compliance_check', {})
        risk = data.get('risk_assessment', {})
        
        status = "ĐẠT" if compliance.get('overall_compliant') else "KHÔNG ĐẠT"
        
        summary = doc.add_paragraph()
        summary.add_run("Trạng thái tuân thủ: ").bold = True
        status_run = summary.add_run(status)
        if compliance.get('overall_compliant'):
            status_run.font.color.rgb = RGBColor(39, 174, 96)
        else:
            status_run.font.color.rgb = RGBColor(231, 76, 60)
        status_run.bold = True
        
        summary2 = doc.add_paragraph()
        summary2.add_run("Mức độ rủi ro: ").bold = True
        summary2.add_run(risk.get('risk_level', 'N/A'))
        
        summary3 = doc.add_paragraph()
        summary3.add_run("Tỷ lệ tuân thủ: ").bold = True
        summary3.add_run(f"{risk.get('compliance_rate', 0)}%")
        
        # Detailed Results
        doc.add_paragraph("KẾT QUẢ CHI TIẾT", style='VNHeading1')
        
        param_results = compliance.get('parameter_results', {})
        
        if param_results:
            results_table = doc.add_table(rows=1 + len(param_results), cols=6)
            results_table.style = 'Table Grid'
            
            # Header
            headers = ['Thông số', 'Giá trị', 'Đơn vị', 'Giới hạn', 'Trạng thái', 'Vượt (%)']
            for i, header in enumerate(headers):
                cell = results_table.rows[0].cells[i]
                cell.text = header
                cell.paragraphs[0].runs[0].bold = True
                # Header background (requires additional styling)
            
            # Data rows
            for row_idx, (param, result) in enumerate(param_results.items(), start=1):
                results_table.rows[row_idx].cells[0].text = param
                results_table.rows[row_idx].cells[1].text = str(result.get('value', ''))
                results_table.rows[row_idx].cells[2].text = result.get('unit', '')
                results_table.rows[row_idx].cells[3].text = str(result.get('limit', ''))
                results_table.rows[row_idx].cells[4].text = result.get('status', '')
                results_table.rows[row_idx].cells[5].text = str(result.get('exceedance_percent', 0))
        
        # Recommendations
        doc.add_paragraph("KHUYẾN NGHỊ", style='VNHeading1')
        
        for i, rec in enumerate(risk.get('recommendations', []), 1):
            doc.add_paragraph(f"{i}. {rec}")
        
        # Conclusion
        doc.add_paragraph("KẾT LUẬN", style='VNHeading1')
        
        conclusion = doc.add_paragraph()
        conclusion.add_run(f"Cơ sở {data.get('facility_name', '')} ")
        if compliance.get('overall_compliant'):
            run = conclusion.add_run("ĐẠT")
            run.font.color.rgb = RGBColor(39, 174, 96)
            run.bold = True
        else:
            run = conclusion.add_run("KHÔNG ĐẠT")
            run.font.color.rgb = RGBColor(231, 76, 60)
            run.bold = True
        conclusion.add_run(f" yêu cầu tuân thủ theo {data.get('regulation_lookup', {}).get('qcvn_applied', '')}.")
        
        # Save
        doc.save(str(output_file))
        
        return str(output_file)
```

### Ngày 5-6: Chart Generation và Visualization

#### 3.1 Chart Generation

```python
# ============================================
# CHART GENERATION FOR REPORTS
# ============================================

from typing import Dict, List, Optional, Tuple, Any
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
from matplotlib.figure import Figure
import numpy as np
from io import BytesIO
import base64
from dataclasses import dataclass

@dataclass
class ChartConfig:
    """Configuration for chart generation."""
    width: int = 10
    height: int = 6
    dpi: int = 100
    style: str = "seaborn-v0_8-whitegrid"
    font_family: str = "sans-serif"
    title_fontsize: int = 14
    label_fontsize: int = 11
    primary_color: str = "#2C3E50"
    secondary_color: str = "#3498DB"
    success_color: str = "#27AE60"
    danger_color: str = "#E74C3C"
    warning_color: str = "#F39C12"

class ChartGenerator:
    """
    Generate charts for environmental reports.
    """
    
    def __init__(self, config: ChartConfig = None):
        self.config = config or ChartConfig()
        plt.style.use(self.config.style)
    
    def _create_figure(self) -> Tuple[Figure, Any]:
        """Create figure with configured size."""
        fig, ax = plt.subplots(
            figsize=(self.config.width, self.config.height),
            dpi=self.config.dpi
        )
        return fig, ax
    
    def _save_figure(self, fig: Figure, format: str = "png") -> bytes:
        """Save figure to bytes."""
        buffer = BytesIO()
        fig.savefig(buffer, format=format, bbox_inches='tight')
        buffer.seek(0)
        plt.close(fig)
        return buffer.getvalue()
    
    def _to_base64(self, image_bytes: bytes) -> str:
        """Convert image bytes to base64."""
        return base64.b64encode(image_bytes).decode('utf-8')
    
    def compliance_bar_chart(
        self,
        parameters: Dict[str, Dict],
        title: str = "Kết quả tuân thủ theo thông số"
    ) -> bytes:
        """
        Generate bar chart showing compliance status.
        
        Args:
            parameters: Dict of {param_name: {value, limit, compliant}}
        """
        fig, ax = self._create_figure()
        
        params = list(parameters.keys())
        values = [p.get('value', 0) for p in parameters.values()]
        limits = [p.get('limit', 0) if not isinstance(p.get('limit'), list) else p.get('limit')[1] for p in parameters.values()]
        compliant = [p.get('compliant', True) for p in parameters.values()]
        
        x = np.arange(len(params))
        width = 0.35
        
        # Bars
        colors = [self.config.success_color if c else self.config.danger_color for c in compliant]
        bars = ax.bar(x, values, width, label='Giá trị đo', color=colors, alpha=0.8)
        
        # Limit line
        ax.scatter(x, limits, color=self.config.primary_color, marker='_', s=200, linewidths=3, label='Giới hạn QCVN', zorder=5)
        
        # Labels
        ax.set_xlabel('Thông số', fontsize=self.config.label_fontsize)
        ax.set_ylabel('Giá trị', fontsize=self.config.label_fontsize)
        ax.set_title(title, fontsize=self.config.title_fontsize, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(params, rotation=45, ha='right')
        ax.legend()
        
        # Add value labels on bars
        for bar, val in zip(bars, values):
            ax.annotate(f'{val:.1f}',
                       xy=(bar.get_x() + bar.get_width() / 2, bar.get_height()),
                       xytext=(0, 3),
                       textcoords="offset points",
                       ha='center', va='bottom', fontsize=9)
        
        plt.tight_layout()
        return self._save_figure(fig)
    
    def compliance_pie_chart(
        self,
        compliant_count: int,
        non_compliant_count: int,
        title: str = "Tỷ lệ tuân thủ"
    ) -> bytes:
        """
        Generate pie chart showing compliance ratio.
        """
        fig, ax = self._create_figure()
        
        sizes = [compliant_count, non_compliant_count]
        labels = ['Đạt', 'Không đạt']
        colors = [self.config.success_color, self.config.danger_color]
        explode = (0.05, 0.05)
        
        wedges, texts, autotexts = ax.pie(
            sizes,
            explode=explode,
            labels=labels,
            colors=colors,
            autopct='%1.1f%%',
            shadow=True,
            startangle=90
        )
        
        # Style
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
        
        ax.set_title(title, fontsize=self.config.title_fontsize, fontweight='bold')
        ax.axis('equal')
        
        return self._save_figure(fig)
    
    def trend_line_chart(
        self,
        dates: List[str],
        values: Dict[str, List[float]],
        limits: Dict[str, float] = None,
        title: str = "Xu hướng thông số theo thời gian"
    ) -> bytes:
        """
        Generate line chart showing parameter trends over time.
        
        Args:
            dates: List of date strings
            values: Dict of {param_name: [values]}
            limits: Dict of {param_name: limit_value}
        """
        fig, ax = self._create_figure()
        
        colors = plt.cm.Set2(np.linspace(0, 1, len(values)))
        
        for i, (param, vals) in enumerate(values.items()):
            ax.plot(dates, vals, marker='o', label=param, color=colors[i], linewidth=2)
            
            # Add limit line if provided
            if limits and param in limits:
                ax.axhline(y=limits[param], color=colors[i], linestyle='--', alpha=0.5,
                          label=f'{param} limit')
        
        ax.set_xlabel('Ngày', fontsize=self.config.label_fontsize)
        ax.set_ylabel('Giá trị', fontsize=self.config.label_fontsize)
        ax.set_title(title, fontsize=self.config.title_fontsize, fontweight='bold')
        ax.legend(loc='upper right')
        
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        return self._save_figure(fig)
    
    def risk_gauge_chart(
        self,
        risk_level: str,
        risk_score: int,  # 1-4
        title: str = "Mức độ rủi ro"
    ) -> bytes:
        """
        Generate gauge chart showing risk level.
        """
        fig, ax = self._create_figure()
        
        # Risk levels and colors
        levels = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']
        colors = [self.config.success_color, self.config.warning_color, 
                 '#E67E22', self.config.danger_color]
        
        # Create gauge sections
        theta = np.linspace(0, np.pi, 100)
        
        for i, (level, color) in enumerate(zip(levels, colors)):
            start = i * np.pi / 4
            end = (i + 1) * np.pi / 4
            theta_section = np.linspace(start, end, 25)
            
            ax.fill_between(
                theta_section,
                0.6, 1.0,
                alpha=0.3 if level != risk_level else 0.8,
                color=color
            )
            
            # Label
            mid_angle = (start + end) / 2
            ax.text(
                mid_angle, 1.15,
                level,
                ha='center', va='center',
                fontsize=9,
                fontweight='bold' if level == risk_level else 'normal'
            )
        
        # Needle
        needle_angle = (risk_score - 0.5) * np.pi / 4
        ax.annotate('',
                   xy=(needle_angle, 0.9),
                   xytext=(np.pi/2, 0),
                   arrowprops=dict(arrowstyle='->', color='black', lw=2))
        
        # Center circle
        circle = plt.Circle((np.pi/2, 0), 0.1, color='black')
        ax.add_patch(circle)
        
        ax.set_xlim(0, np.pi)
        ax.set_ylim(0, 1.5)
        ax.axis('off')
        ax.set_title(title, fontsize=self.config.title_fontsize, fontweight='bold', y=1.1)
        
        # Add current level text
        ax.text(np.pi/2, -0.3, risk_level, ha='center', va='center',
               fontsize=16, fontweight='bold', 
               color=colors[levels.index(risk_level)])
        
        return self._save_figure(fig)
    
    def exceedance_heatmap(
        self,
        data: Dict[str, Dict[str, float]],
        title: str = "Heatmap vượt chuẩn"
    ) -> bytes:
        """
        Generate heatmap showing exceedance across parameters and time.
        
        Args:
            data: Dict of {date: {param: exceedance_percent}}
        """
        fig, ax = self._create_figure()
        
        dates = list(data.keys())
        params = list(set(p for d in data.values() for p in d.keys()))
        
        # Create matrix
        matrix = np.zeros((len(params), len(dates)))
        for j, date in enumerate(dates):
            for i, param in enumerate(params):
                matrix[i, j] = data[date].get(param, 0)
        
        # Create heatmap
        im = ax.imshow(matrix, cmap='RdYlGn_r', aspect='auto')
        
        # Labels
        ax.set_xticks(np.arange(len(dates)))
        ax.set_yticks(np.arange(len(params)))
        ax.set_xticklabels(dates, rotation=45, ha='right')
        ax.set_yticklabels(params)
        
        # Colorbar
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('Vượt chuẩn (%)')
        
        # Add text annotations
        for i in range(len(params)):
            for j in range(len(dates)):
                value = matrix[i, j]
                if value > 0:
                    text_color = 'white' if value > 50 else 'black'
                    ax.text(j, i, f'{value:.0f}', ha='center', va='center',
                           color=text_color, fontsize=8)
        
        ax.set_title(title, fontsize=self.config.title_fontsize, fontweight='bold')
        
        plt.tight_layout()
        return self._save_figure(fig)


# ============================================
# INTEGRATED DOCUMENT GENERATOR
# ============================================

class EnvironmentalReportGenerator:
    """
    Complete environmental report generator with templates, charts, and export.
    """
    
    def __init__(self, output_dir: str = "./output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.template_engine = TemplateEngine()
        self.pdf_generator = PDFGenerator(output_dir)
        self.docx_generator = DOCXGenerator(output_dir)
        self.chart_generator = ChartGenerator()
        
        # Setup templates
        self._setup_templates()
    
    def _setup_templates(self):
        """Initialize default templates."""
        self.template_engine.create_template(
            "compliance_report.html",
            COMPLIANCE_REPORT_TEMPLATE
        )
    
    def generate(
        self,
        data: Dict,
        config: DocumentConfig,
        include_charts: bool = True
    ) -> Dict[str, str]:
        """
        Generate complete report in multiple formats.
        
        Args:
            data: Report data
            config: Document configuration
            include_charts: Whether to include charts
        
        Returns:
            Dict of {format: file_path}
        """
        outputs = {}
        
        # Add generated timestamp
        data['generated_at'] = datetime.now().isoformat()
        data['config'] = config.__dict__
        
        # Generate charts if requested
        if include_charts:
            charts = self._generate_charts(data)
            data['charts'] = charts
        
        # Generate HTML
        html_content = self.template_engine.render(
            "compliance_report.html",
            data
        )
        
        html_path = self.output_dir / f"{config.title.replace(' ', '_')}.html"
        html_path.write_text(html_content, encoding='utf-8')
        outputs['html'] = str(html_path)
        
        # Generate PDF from HTML
        if config.output_format in [DocumentFormat.PDF, DocumentFormat.HTML]:
            pdf_path = self.pdf_generator.from_html(
                html_content,
                f"{config.title.replace(' ', '_')}.pdf"
            )
            outputs['pdf'] = pdf_path
        
        # Generate DOCX
        if config.output_format == DocumentFormat.DOCX:
            docx_path = self.docx_generator.generate_compliance_report(
                data,
                f"{config.title.replace(' ', '_')}.docx"
            )
            outputs['docx'] = docx_path
        
        return outputs
    
    def _generate_charts(self, data: Dict) -> Dict[str, str]:
        """Generate all charts for the report."""
        charts = {}
        
        compliance = data.get('compliance_check', {})
        param_results = compliance.get('parameter_results', {})
        
        if param_results:
            # Bar chart
            bar_chart = self.chart_generator.compliance_bar_chart(param_results)
            charts['bar_chart'] = self.chart_generator._to_base64(bar_chart)
            
            # Pie chart
            pie_chart = self.chart_generator.compliance_pie_chart(
                compliance.get('compliant_count', 0),
                compliance.get('non_compliant_count', 0)
            )
            charts['pie_chart'] = self.chart_generator._to_base64(pie_chart)
        
        # Risk gauge
        risk = data.get('risk_assessment', {})
        if risk:
            gauge_chart = self.chart_generator.risk_gauge_chart(
                risk.get('risk_level', 'LOW'),
                risk.get('risk_score', 1)
            )
            charts['gauge_chart'] = self.chart_generator._to_base64(gauge_chart)
        
        return charts


# Usage example
if __name__ == "__main__":
    # Sample data
    sample_data = {
        "facility_name": "Nhà máy ABC",
        "period": "01/2024",
        "monitoring_data": {
            "sampling_date": "2024-01-15",
            "sampling_location": "Điểm xả thải chính"
        },
        "regulation_lookup": {
            "qcvn_applied": "QCVN 40:2011/BTNMT"
        },
        "compliance_check": {
            "overall_compliant": False,
            "compliant_count": 3,
            "non_compliant_count": 2,
            "parameter_results": {
                "BOD5": {"value": 45, "unit": "mg/L", "limit": 50, "compliant": True, "status": "ĐẠT", "exceedance_percent": 0},
                "COD": {"value": 180, "unit": "mg/L", "limit": 150, "compliant": False, "status": "KHÔNG ĐẠT", "exceedance_percent": 20},
                "TSS": {"value": 80, "unit": "mg/L", "limit": 100, "compliant": True, "status": "ĐẠT", "exceedance_percent": 0},
                "pH": {"value": 7.5, "unit": "-", "limit": "5.5-9", "compliant": True, "status": "ĐẠT", "exceedance_percent": 0},
                "Amonia": {"value": 15, "unit": "mg/L", "limit": 10, "compliant": False, "status": "KHÔNG ĐẠT", "exceedance_percent": 50}
            }
        },
        "risk_assessment": {
            "risk_level": "HIGH",
            "risk_score": 3,
            "compliance_rate": 60,
            "recommendations": [
                "Kiểm tra và nâng cấp hệ thống xử lý COD",
                "Tăng cường xử lý Amonia",
                "Tăng tần suất quan trắc"
            ]
        }
    }
    
    # Generate report
    generator = EnvironmentalReportGenerator()
    
    config = DocumentConfig(
        title="Báo cáo tuân thủ môi trường",
        template_name="compliance_report.html",
        output_format=DocumentFormat.PDF,
        output_path="./output"
    )
    
    outputs = generator.generate(sample_data, config)
    print(f"Generated reports: {outputs}")
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Template Engine (Ngày 1-2)

```
🎯 Mục tiêu: Build document template system

📋 Yêu cầu:
1. Setup Jinja2 template engine
2. Create custom filters for Vietnamese
3. Build compliance report template
4. Support multiple output formats

📁 Deliverables:
- src/documents/template_engine.py
- templates/compliance_report.html
- templates/monitoring_report.md
```

### Bài tập 2: PDF & DOCX Generation (Ngày 3-4)

```
🎯 Mục tiêu: Implement document export

📋 Yêu cầu:
1. PDF generation với WeasyPrint và ReportLab
2. DOCX generation với python-docx
3. Table và styling support
4. Vietnamese font support

📁 Deliverables:
- src/documents/pdf_generator.py
- src/documents/docx_generator.py
- Sample output documents
```

### Bài tập 3: Chart Integration (Ngày 5-7)

```
🎯 Mục tiêu: Add visualizations to reports

📋 Yêu cầu:
1. Compliance bar/pie charts
2. Trend line charts
3. Risk gauge visualization
4. Integrate charts into documents

📁 Deliverables:
- src/charts/chart_generator.py
- src/documents/report_generator.py
- **PROJECT 3 Continued**: Full document generation
```

---

## ✅ CHECKLIST TUẦN 10

### Kiến thức đã học
- [ ] Document generation architecture
- [ ] Jinja2 template engine
- [ ] PDF generation (WeasyPrint, ReportLab)
- [ ] DOCX generation (python-docx)
- [ ] Chart generation (Matplotlib)

### Skills thực hành
- [ ] Build template-based systems
- [ ] Generate professional PDFs
- [ ] Create DOCX documents
- [ ] Integrate charts và visualizations

### Deliverables
- [ ] Template engine với custom filters
- [ ] PDF generator
- [ ] DOCX generator
- [ ] Chart generator
- [ ] Integrated report system

---

*Hoàn thành Tuần 10 để tiếp tục sang Tuần 11: Testing & Deployment*
