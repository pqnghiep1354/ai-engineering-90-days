# 📅 TUẦN 9: MULTI-AGENT SYSTEMS VỚI LANGGRAPH

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Xây dựng multi-agent systems với LangGraph |
| **Output** | Environmental Compliance Multi-Agent System |
| **Độ khó** | ⭐⭐⭐⭐⭐ Rất khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu multi-agent architectures và patterns
- [ ] Nắm vững LangGraph concepts (nodes, edges, state)
- [ ] Hiểu agent communication và coordination
- [ ] Biết supervisor và hierarchical patterns

### Kỹ năng (Skills)
- [ ] Build state machines với LangGraph
- [ ] Implement agent workflows
- [ ] Create supervisor agents
- [ ] Handle agent errors và recovery

### Ứng dụng (Application)
- [ ] Environmental Compliance Multi-Agent System
- [ ] Automated compliance checking workflow
- [ ] Report generation pipeline

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: Multi-Agent Architecture Fundamentals

#### 1.1 Multi-Agent Patterns Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      MULTI-AGENT ARCHITECTURE PATTERNS                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    PATTERN 1: SUPERVISOR                             │    │
│  │                                                                      │    │
│  │                     ┌──────────────┐                                │    │
│  │                     │  Supervisor  │                                │    │
│  │                     │    Agent     │                                │    │
│  │                     └──────┬───────┘                                │    │
│  │                            │                                        │    │
│  │            ┌───────────────┼───────────────┐                        │    │
│  │            ▼               ▼               ▼                        │    │
│  │     ┌──────────┐    ┌──────────┐    ┌──────────┐                   │    │
│  │     │ Worker 1 │    │ Worker 2 │    │ Worker 3 │                   │    │
│  │     │(Research)│    │(Analysis)│    │ (Write)  │                   │    │
│  │     └──────────┘    └──────────┘    └──────────┘                   │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    PATTERN 2: HIERARCHICAL                           │    │
│  │                                                                      │    │
│  │                     ┌──────────────┐                                │    │
│  │                     │    Top       │                                │    │
│  │                     │  Supervisor  │                                │    │
│  │                     └──────┬───────┘                                │    │
│  │                            │                                        │    │
│  │            ┌───────────────┴───────────────┐                        │    │
│  │            ▼                               ▼                        │    │
│  │     ┌──────────────┐              ┌──────────────┐                 │    │
│  │     │ Team Lead A  │              │ Team Lead B  │                 │    │
│  │     └──────┬───────┘              └──────┬───────┘                 │    │
│  │            │                              │                         │    │
│  │      ┌─────┴─────┐                  ┌─────┴─────┐                  │    │
│  │      ▼           ▼                  ▼           ▼                  │    │
│  │  ┌───────┐  ┌───────┐          ┌───────┐  ┌───────┐              │    │
│  │  │Agent 1│  │Agent 2│          │Agent 3│  │Agent 4│              │    │
│  │  └───────┘  └───────┘          └───────┘  └───────┘              │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    PATTERN 3: COLLABORATIVE                          │    │
│  │                                                                      │    │
│  │         ┌───────────┐                 ┌───────────┐                 │    │
│  │         │  Agent A  │◄───────────────►│  Agent B  │                 │    │
│  │         └─────┬─────┘                 └─────┬─────┘                 │    │
│  │               │                             │                       │    │
│  │               │      ┌───────────┐         │                       │    │
│  │               └─────►│  Agent C  │◄────────┘                       │    │
│  │                      └───────────┘                                  │    │
│  │              (Peer-to-peer communication)                          │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    PATTERN 4: SEQUENTIAL (PIPELINE)                  │    │
│  │                                                                      │    │
│  │   Input ──▶ Agent 1 ──▶ Agent 2 ──▶ Agent 3 ──▶ Output             │    │
│  │            (Extract)    (Process)   (Generate)                      │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 LangGraph Fundamentals

```python
# ============================================
# LANGGRAPH FUNDAMENTALS
# ============================================

from typing import TypedDict, Annotated, Sequence, Literal, Dict, List, Any, Optional
from langgraph.graph import StateGraph, END, START
from langgraph.prebuilt import ToolNode
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
import operator
from dataclasses import dataclass
from enum import Enum

# ==================== STATE DEFINITION ====================

class AgentState(TypedDict):
    """
    State shared across all agents in the graph.
    
    LangGraph uses TypedDict for type-safe state management.
    Annotated fields with operator.add will accumulate values.
    """
    # Accumulated messages
    messages: Annotated[Sequence[BaseMessage], operator.add]
    
    # Current task/query
    task: str
    
    # Results from different agents
    research_results: Optional[Dict]
    analysis_results: Optional[Dict]
    report_content: Optional[str]
    
    # Workflow control
    next_agent: str
    iteration_count: int
    max_iterations: int
    
    # Error handling
    errors: Annotated[List[str], operator.add]
    
    # Final output
    final_output: Optional[str]


# ==================== BASIC GRAPH ====================

class BasicLangGraph:
    """
    Basic LangGraph example demonstrating core concepts.
    """
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0)
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build a simple sequential graph."""
        
        # Create graph with state schema
        graph = StateGraph(AgentState)
        
        # Add nodes
        graph.add_node("researcher", self._research_node)
        graph.add_node("analyzer", self._analyze_node)
        graph.add_node("writer", self._write_node)
        
        # Add edges
        graph.add_edge(START, "researcher")
        graph.add_edge("researcher", "analyzer")
        graph.add_edge("analyzer", "writer")
        graph.add_edge("writer", END)
        
        # Compile
        return graph.compile()
    
    def _research_node(self, state: AgentState) -> Dict:
        """Research node - gathers information."""
        
        messages = [
            SystemMessage(content="Bạn là nhà nghiên cứu. Thu thập thông tin về chủ đề được yêu cầu."),
            HumanMessage(content=f"Nghiên cứu về: {state['task']}")
        ]
        
        response = self.llm.invoke(messages)
        
        return {
            "messages": [response],
            "research_results": {"content": response.content}
        }
    
    def _analyze_node(self, state: AgentState) -> Dict:
        """Analysis node - analyzes research results."""
        
        research = state.get("research_results", {}).get("content", "")
        
        messages = [
            SystemMessage(content="Bạn là nhà phân tích. Phân tích thông tin đã thu thập."),
            HumanMessage(content=f"Phân tích thông tin sau:\n{research}")
        ]
        
        response = self.llm.invoke(messages)
        
        return {
            "messages": [response],
            "analysis_results": {"content": response.content}
        }
    
    def _write_node(self, state: AgentState) -> Dict:
        """Writer node - creates final output."""
        
        analysis = state.get("analysis_results", {}).get("content", "")
        
        messages = [
            SystemMessage(content="Bạn là writer. Viết báo cáo tổng hợp."),
            HumanMessage(content=f"Viết báo cáo dựa trên phân tích:\n{analysis}")
        ]
        
        response = self.llm.invoke(messages)
        
        return {
            "messages": [response],
            "final_output": response.content
        }
    
    def run(self, task: str) -> Dict:
        """Run the graph."""
        
        initial_state = {
            "messages": [],
            "task": task,
            "research_results": None,
            "analysis_results": None,
            "report_content": None,
            "next_agent": "researcher",
            "iteration_count": 0,
            "max_iterations": 10,
            "errors": [],
            "final_output": None
        }
        
        result = self.graph.invoke(initial_state)
        
        return result


# ==================== CONDITIONAL ROUTING ====================

class ConditionalGraph:
    """
    Graph with conditional routing based on state.
    """
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0)
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build graph with conditional edges."""
        
        graph = StateGraph(AgentState)
        
        # Add nodes
        graph.add_node("classifier", self._classify_node)
        graph.add_node("simple_handler", self._simple_handler)
        graph.add_node("complex_handler", self._complex_handler)
        graph.add_node("finalizer", self._finalizer)
        
        # Add conditional edges
        graph.add_edge(START, "classifier")
        
        graph.add_conditional_edges(
            "classifier",
            self._route_by_complexity,
            {
                "simple": "simple_handler",
                "complex": "complex_handler"
            }
        )
        
        graph.add_edge("simple_handler", "finalizer")
        graph.add_edge("complex_handler", "finalizer")
        graph.add_edge("finalizer", END)
        
        return graph.compile()
    
    def _classify_node(self, state: AgentState) -> Dict:
        """Classify task complexity."""
        
        messages = [
            SystemMessage(content="""Phân loại độ phức tạp của yêu cầu.
Trả lời CHỈ một từ: 'simple' hoặc 'complex'.
- simple: câu hỏi đơn giản, có thể trả lời ngắn gọn
- complex: câu hỏi phức tạp, cần phân tích nhiều khía cạnh"""),
            HumanMessage(content=state["task"])
        ]
        
        response = self.llm.invoke(messages)
        classification = response.content.strip().lower()
        
        return {
            "messages": [response],
            "next_agent": classification if classification in ["simple", "complex"] else "complex"
        }
    
    def _route_by_complexity(self, state: AgentState) -> str:
        """Route based on classification."""
        return state.get("next_agent", "complex")
    
    def _simple_handler(self, state: AgentState) -> Dict:
        """Handle simple tasks."""
        messages = [
            SystemMessage(content="Trả lời ngắn gọn và trực tiếp."),
            HumanMessage(content=state["task"])
        ]
        response = self.llm.invoke(messages)
        return {"messages": [response], "final_output": response.content}
    
    def _complex_handler(self, state: AgentState) -> Dict:
        """Handle complex tasks with detailed analysis."""
        messages = [
            SystemMessage(content="""Phân tích chi tiết với cấu trúc:
1. Tổng quan vấn đề
2. Phân tích các khía cạnh
3. Kết luận và khuyến nghị"""),
            HumanMessage(content=state["task"])
        ]
        response = self.llm.invoke(messages)
        return {"messages": [response], "final_output": response.content}
    
    def _finalizer(self, state: AgentState) -> Dict:
        """Finalize output."""
        return {"final_output": state.get("final_output")}


# ==================== CYCLIC GRAPH WITH ITERATION ====================

class CyclicGraph:
    """
    Graph with cycles for iterative refinement.
    """
    
    def __init__(self, max_iterations: int = 3):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0)
        self.max_iterations = max_iterations
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build graph with cycles."""
        
        graph = StateGraph(AgentState)
        
        # Add nodes
        graph.add_node("generator", self._generate_node)
        graph.add_node("critic", self._critic_node)
        graph.add_node("refiner", self._refine_node)
        
        # Add edges with cycle
        graph.add_edge(START, "generator")
        graph.add_edge("generator", "critic")
        
        # Conditional: continue refining or finish
        graph.add_conditional_edges(
            "critic",
            self._should_continue,
            {
                "continue": "refiner",
                "finish": END
            }
        )
        
        graph.add_edge("refiner", "critic")  # Cycle back
        
        return graph.compile()
    
    def _generate_node(self, state: AgentState) -> Dict:
        """Generate initial response."""
        messages = [
            SystemMessage(content="Tạo câu trả lời cho yêu cầu."),
            HumanMessage(content=state["task"])
        ]
        response = self.llm.invoke(messages)
        return {
            "messages": [response],
            "final_output": response.content,
            "iteration_count": 1
        }
    
    def _critic_node(self, state: AgentState) -> Dict:
        """Critique the current output."""
        current = state.get("final_output", "")
        
        messages = [
            SystemMessage(content="""Đánh giá chất lượng câu trả lời.
Trả về JSON với format:
{"score": 1-10, "feedback": "phản hồi", "needs_improvement": true/false}"""),
            HumanMessage(content=f"Đánh giá câu trả lời:\n{current}")
        ]
        
        response = self.llm.invoke(messages)
        
        # Parse critique
        try:
            import json
            critique = json.loads(response.content)
        except:
            critique = {"score": 7, "feedback": "", "needs_improvement": False}
        
        return {
            "messages": [response],
            "analysis_results": critique
        }
    
    def _should_continue(self, state: AgentState) -> str:
        """Decide whether to continue refining."""
        iteration = state.get("iteration_count", 0)
        critique = state.get("analysis_results", {})
        
        if iteration >= self.max_iterations:
            return "finish"
        
        if critique.get("needs_improvement", False) and critique.get("score", 10) < 8:
            return "continue"
        
        return "finish"
    
    def _refine_node(self, state: AgentState) -> Dict:
        """Refine based on critique."""
        current = state.get("final_output", "")
        feedback = state.get("analysis_results", {}).get("feedback", "")
        
        messages = [
            SystemMessage(content="Cải thiện câu trả lời dựa trên phản hồi."),
            HumanMessage(content=f"Câu trả lời hiện tại:\n{current}\n\nPhản hồi:\n{feedback}")
        ]
        
        response = self.llm.invoke(messages)
        
        return {
            "messages": [response],
            "final_output": response.content,
            "iteration_count": state.get("iteration_count", 0) + 1
        }
```

### Ngày 3-4: Supervisor Agent Pattern

#### 2.1 Supervisor Implementation

```python
# ============================================
# SUPERVISOR AGENT PATTERN
# ============================================

from typing import TypedDict, Annotated, Sequence, Literal, Dict, List, Optional
from langgraph.graph import StateGraph, END, START
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
import operator
import json

# ==================== STATE ====================

class SupervisorState(TypedDict):
    """State for supervisor-worker pattern."""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    task: str
    subtasks: List[Dict]
    worker_results: Annotated[List[Dict], operator.add]
    current_worker: str
    iteration: int
    max_iterations: int
    final_output: Optional[str]
    status: str  # "running", "completed", "failed"


# ==================== WORKER AGENTS ====================

class WorkerAgent:
    """Base class for worker agents."""
    
    def __init__(self, name: str, description: str, system_prompt: str):
        self.name = name
        self.description = description
        self.system_prompt = system_prompt
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0.3)
    
    def execute(self, task: str, context: Dict = None) -> Dict:
        """Execute worker task."""
        messages = [
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=self._build_prompt(task, context))
        ]
        
        response = self.llm.invoke(messages)
        
        return {
            "worker": self.name,
            "task": task,
            "result": response.content,
            "status": "completed"
        }
    
    def _build_prompt(self, task: str, context: Dict = None) -> str:
        """Build prompt with context."""
        prompt = f"Task: {task}"
        
        if context:
            prompt += f"\n\nContext:\n{json.dumps(context, ensure_ascii=False, indent=2)}"
        
        return prompt


class ResearchWorker(WorkerAgent):
    """Worker for research tasks."""
    
    def __init__(self):
        super().__init__(
            name="researcher",
            description="Nghiên cứu và thu thập thông tin về quy định môi trường",
            system_prompt="""Bạn là chuyên gia nghiên cứu quy định môi trường Việt Nam.

Nhiệm vụ:
1. Thu thập thông tin liên quan
2. Xác định các văn bản pháp luật áp dụng
3. Tóm tắt các điểm chính

Trả về kết quả có cấu trúc rõ ràng."""
        )


class AnalysisWorker(WorkerAgent):
    """Worker for analysis tasks."""
    
    def __init__(self):
        super().__init__(
            name="analyst",
            description="Phân tích tuân thủ và đánh giá rủi ro",
            system_prompt="""Bạn là chuyên gia phân tích tuân thủ môi trường.

Nhiệm vụ:
1. Phân tích dữ liệu được cung cấp
2. So sánh với quy chuẩn
3. Đánh giá mức độ tuân thủ
4. Xác định rủi ro

Cung cấp phân tích chi tiết với số liệu cụ thể."""
        )


class ReportWorker(WorkerAgent):
    """Worker for report generation."""
    
    def __init__(self):
        super().__init__(
            name="reporter",
            description="Viết báo cáo tuân thủ môi trường",
            system_prompt="""Bạn là chuyên gia viết báo cáo môi trường.

Nhiệm vụ:
1. Tổng hợp thông tin từ nghiên cứu và phân tích
2. Viết báo cáo chuyên nghiệp
3. Đề xuất khuyến nghị

Format báo cáo:
- Tóm tắt điều hành
- Kết quả chi tiết
- Kết luận
- Khuyến nghị"""
        )


# ==================== SUPERVISOR ====================

class RouterOutput(BaseModel):
    """Output schema for supervisor routing."""
    next_worker: Literal["researcher", "analyst", "reporter", "FINISH"]
    reasoning: str
    task_for_worker: Optional[str] = None


class SupervisorAgent:
    """
    Supervisor that coordinates worker agents.
    """
    
    def __init__(self, workers: List[WorkerAgent]):
        self.workers = {w.name: w for w in workers}
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0)
        
        # Build worker descriptions
        self.worker_descriptions = "\n".join([
            f"- {w.name}: {w.description}"
            for w in workers
        ])
    
    def route(self, state: SupervisorState) -> RouterOutput:
        """Decide which worker to call next."""
        
        prompt = ChatPromptTemplate.from_messages([
            ("system", """Bạn là supervisor điều phối các worker agents.

Workers có sẵn:
{worker_descriptions}

Dựa trên task và kết quả hiện tại, quyết định:
1. Worker nào nên thực hiện tiếp (hoặc FINISH nếu hoàn thành)
2. Lý do
3. Task cụ thể cho worker (nếu có)

Trả về JSON với format:
{{"next_worker": "worker_name hoặc FINISH", "reasoning": "lý do", "task_for_worker": "task cụ thể"}}"""),
            ("human", """Task gốc: {task}

Kết quả từ các worker trước:
{worker_results}

Quyết định bước tiếp theo:""")
        ])
        
        # Format worker results
        results_str = ""
        for r in state.get("worker_results", []):
            results_str += f"\n[{r['worker']}]: {r['result'][:500]}..."
        
        messages = prompt.format_messages(
            worker_descriptions=self.worker_descriptions,
            task=state["task"],
            worker_results=results_str if results_str else "Chưa có kết quả"
        )
        
        response = self.llm.invoke(messages)
        
        # Parse response
        try:
            data = json.loads(response.content)
            return RouterOutput(**data)
        except:
            return RouterOutput(
                next_worker="FINISH",
                reasoning="Could not parse response",
                task_for_worker=None
            )


# ==================== SUPERVISOR GRAPH ====================

class SupervisorGraph:
    """
    LangGraph implementation of supervisor pattern.
    """
    
    def __init__(self):
        # Initialize workers
        self.workers = [
            ResearchWorker(),
            AnalysisWorker(),
            ReportWorker()
        ]
        
        self.supervisor = SupervisorAgent(self.workers)
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build the supervisor graph."""
        
        graph = StateGraph(SupervisorState)
        
        # Add supervisor node
        graph.add_node("supervisor", self._supervisor_node)
        
        # Add worker nodes
        for worker in self.workers:
            graph.add_node(worker.name, self._create_worker_node(worker))
        
        # Start with supervisor
        graph.add_edge(START, "supervisor")
        
        # Supervisor routes to workers or END
        graph.add_conditional_edges(
            "supervisor",
            self._route_from_supervisor,
            {
                "researcher": "researcher",
                "analyst": "analyst",
                "reporter": "reporter",
                "FINISH": END
            }
        )
        
        # Workers return to supervisor
        for worker in self.workers:
            graph.add_edge(worker.name, "supervisor")
        
        return graph.compile()
    
    def _supervisor_node(self, state: SupervisorState) -> Dict:
        """Supervisor decides next action."""
        
        # Check iteration limit
        if state.get("iteration", 0) >= state.get("max_iterations", 10):
            return {
                "current_worker": "FINISH",
                "status": "completed"
            }
        
        routing = self.supervisor.route(state)
        
        return {
            "current_worker": routing.next_worker,
            "messages": [AIMessage(content=f"Supervisor: {routing.reasoning}")],
            "subtasks": state.get("subtasks", []) + [
                {"worker": routing.next_worker, "task": routing.task_for_worker}
            ] if routing.task_for_worker else state.get("subtasks", []),
            "iteration": state.get("iteration", 0) + 1
        }
    
    def _route_from_supervisor(self, state: SupervisorState) -> str:
        """Route based on supervisor decision."""
        return state.get("current_worker", "FINISH")
    
    def _create_worker_node(self, worker: WorkerAgent):
        """Create a node function for a worker."""
        
        def worker_node(state: SupervisorState) -> Dict:
            # Get task for this worker
            subtasks = state.get("subtasks", [])
            current_task = None
            
            for st in reversed(subtasks):
                if st.get("worker") == worker.name:
                    current_task = st.get("task")
                    break
            
            if not current_task:
                current_task = state["task"]
            
            # Build context from previous results
            context = {
                "original_task": state["task"],
                "previous_results": state.get("worker_results", [])
            }
            
            # Execute worker
            result = worker.execute(current_task, context)
            
            return {
                "worker_results": [result],
                "messages": [AIMessage(content=f"[{worker.name}] Completed: {result['result'][:200]}...")]
            }
        
        return worker_node
    
    def run(self, task: str, max_iterations: int = 10) -> Dict:
        """Run the supervisor graph."""
        
        initial_state = {
            "messages": [],
            "task": task,
            "subtasks": [],
            "worker_results": [],
            "current_worker": "",
            "iteration": 0,
            "max_iterations": max_iterations,
            "final_output": None,
            "status": "running"
        }
        
        result = self.graph.invoke(initial_state)
        
        # Extract final output from worker results
        if result.get("worker_results"):
            # Get report worker result if available
            for r in reversed(result["worker_results"]):
                if r.get("worker") == "reporter":
                    result["final_output"] = r.get("result")
                    break
            
            if not result.get("final_output"):
                result["final_output"] = result["worker_results"][-1].get("result")
        
        return result
```

### Ngày 5-6: Environmental Multi-Agent System

#### 3.1 Complete Implementation

```python
# ============================================
# ENVIRONMENTAL COMPLIANCE MULTI-AGENT SYSTEM
# ============================================

from typing import TypedDict, Annotated, Sequence, Literal, Dict, List, Optional, Any
from langgraph.graph import StateGraph, END, START
from langgraph.checkpoint.memory import MemorySaver
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from pydantic import BaseModel, Field
import operator
import json
from datetime import datetime
from enum import Enum

# ==================== STATE ====================

class ComplianceWorkflowState(TypedDict):
    """State for environmental compliance workflow."""
    
    # Messages
    messages: Annotated[Sequence[BaseMessage], operator.add]
    
    # Input
    facility_name: str
    monitoring_data: Dict[str, Any]
    period: str
    
    # Agent outputs
    data_validation: Optional[Dict]
    regulation_lookup: Optional[Dict]
    compliance_check: Optional[Dict]
    risk_assessment: Optional[Dict]
    report_draft: Optional[str]
    final_report: Optional[str]
    
    # Workflow control
    current_stage: str
    completed_stages: List[str]
    errors: Annotated[List[str], operator.add]
    
    # Metadata
    started_at: str
    completed_at: Optional[str]


# ==================== SPECIALIZED AGENTS ====================

class DataValidationAgent:
    """Agent for validating input monitoring data."""
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0)
    
    def validate(self, state: ComplianceWorkflowState) -> Dict:
        """Validate monitoring data."""
        
        data = state.get("monitoring_data", {})
        
        validation_result = {
            "is_valid": True,
            "issues": [],
            "warnings": [],
            "data_summary": {}
        }
        
        # Check required fields
        required_fields = ["parameters", "sampling_date", "sampling_location"]
        for field in required_fields:
            if field not in data:
                validation_result["is_valid"] = False
                validation_result["issues"].append(f"Missing required field: {field}")
        
        # Validate parameters
        parameters = data.get("parameters", {})
        for param, value in parameters.items():
            if not isinstance(value, (int, float)):
                validation_result["warnings"].append(f"Non-numeric value for {param}")
            elif value < 0:
                validation_result["warnings"].append(f"Negative value for {param}")
        
        # Summary
        validation_result["data_summary"] = {
            "total_parameters": len(parameters),
            "sampling_date": data.get("sampling_date"),
            "sampling_location": data.get("sampling_location")
        }
        
        return validation_result


class RegulationLookupAgent:
    """Agent for finding applicable regulations."""
    
    def __init__(self, vector_store=None):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0)
        self.vector_store = vector_store
        
        # Hardcoded regulations for demo
        self.regulations_db = {
            "wastewater": {
                "qcvn": "QCVN 40:2011/BTNMT",
                "parameters": {
                    "BOD5": {"column_A": 30, "column_B": 50, "unit": "mg/L"},
                    "COD": {"column_A": 75, "column_B": 150, "unit": "mg/L"},
                    "TSS": {"column_A": 50, "column_B": 100, "unit": "mg/L"},
                    "pH": {"column_A": [6, 9], "column_B": [5.5, 9], "unit": "-"},
                    "Amonia": {"column_A": 5, "column_B": 10, "unit": "mg/L"},
                    "Tong_Nito": {"column_A": 20, "column_B": 40, "unit": "mg/L"},
                    "Coliform": {"column_A": 3000, "column_B": 5000, "unit": "MPN/100mL"}
                }
            },
            "air": {
                "qcvn": "QCVN 05:2023/BTNMT",
                "parameters": {
                    "PM2.5": {"24h": 50, "year": 25, "unit": "μg/m³"},
                    "PM10": {"24h": 100, "year": 50, "unit": "μg/m³"},
                    "SO2": {"1h": 350, "24h": 125, "unit": "μg/m³"},
                    "NO2": {"1h": 200, "24h": 100, "unit": "μg/m³"}
                }
            }
        }
    
    def lookup(self, state: ComplianceWorkflowState) -> Dict:
        """Find applicable regulations."""
        
        data = state.get("monitoring_data", {})
        parameters = data.get("parameters", {})
        media_type = data.get("media_type", "wastewater")
        discharge_type = data.get("discharge_type", "B")  # Column A or B
        
        applicable = self.regulations_db.get(media_type, {})
        
        result = {
            "qcvn_applied": applicable.get("qcvn"),
            "media_type": media_type,
            "discharge_column": discharge_type,
            "applicable_limits": {},
            "unmapped_parameters": []
        }
        
        reg_params = applicable.get("parameters", {})
        
        for param in parameters.keys():
            if param in reg_params:
                param_spec = reg_params[param]
                
                if media_type == "wastewater":
                    limit_key = f"column_{discharge_type}"
                    limit = param_spec.get(limit_key, param_spec.get("column_B"))
                else:
                    limit = param_spec.get("24h")
                
                result["applicable_limits"][param] = {
                    "limit": limit,
                    "unit": param_spec.get("unit")
                }
            else:
                result["unmapped_parameters"].append(param)
        
        return result


class ComplianceCheckAgent:
    """Agent for checking compliance against regulations."""
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0)
    
    def check(self, state: ComplianceWorkflowState) -> Dict:
        """Check compliance for all parameters."""
        
        data = state.get("monitoring_data", {})
        regulations = state.get("regulation_lookup", {})
        
        parameters = data.get("parameters", {})
        limits = regulations.get("applicable_limits", {})
        
        result = {
            "overall_compliant": True,
            "qcvn_applied": regulations.get("qcvn_applied"),
            "parameter_results": {},
            "non_compliant_count": 0,
            "compliant_count": 0
        }
        
        for param, value in parameters.items():
            if param not in limits:
                continue
            
            limit_info = limits[param]
            limit = limit_info["limit"]
            unit = limit_info["unit"]
            
            # Check compliance
            if isinstance(limit, list):
                # Range check (pH)
                compliant = limit[0] <= value <= limit[1]
                limit_str = f"{limit[0]} - {limit[1]}"
                if not compliant:
                    if value < limit[0]:
                        exceedance = ((limit[0] - value) / limit[0]) * 100
                    else:
                        exceedance = ((value - limit[1]) / limit[1]) * 100
                else:
                    exceedance = 0
            else:
                compliant = value <= limit
                limit_str = str(limit)
                exceedance = ((value - limit) / limit * 100) if not compliant else 0
            
            result["parameter_results"][param] = {
                "value": value,
                "unit": unit,
                "limit": limit_str,
                "compliant": compliant,
                "status": "ĐẠT" if compliant else "KHÔNG ĐẠT",
                "exceedance_percent": round(exceedance, 2)
            }
            
            if compliant:
                result["compliant_count"] += 1
            else:
                result["non_compliant_count"] += 1
                result["overall_compliant"] = False
        
        return result


class RiskAssessmentAgent:
    """Agent for assessing environmental risks."""
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0.3)
    
    def assess(self, state: ComplianceWorkflowState) -> Dict:
        """Assess risks based on compliance results."""
        
        compliance = state.get("compliance_check", {})
        
        # Calculate risk level
        non_compliant = compliance.get("non_compliant_count", 0)
        total = non_compliant + compliance.get("compliant_count", 0)
        
        if total == 0:
            risk_level = "UNKNOWN"
            risk_score = 0
        elif non_compliant == 0:
            risk_level = "LOW"
            risk_score = 1
        elif non_compliant / total <= 0.2:
            risk_level = "MEDIUM"
            risk_score = 2
        elif non_compliant / total <= 0.5:
            risk_level = "HIGH"
            risk_score = 3
        else:
            risk_level = "CRITICAL"
            risk_score = 4
        
        # Identify high-risk parameters
        high_risk_params = []
        param_results = compliance.get("parameter_results", {})
        
        for param, result in param_results.items():
            if not result.get("compliant") and result.get("exceedance_percent", 0) > 50:
                high_risk_params.append({
                    "parameter": param,
                    "exceedance": result.get("exceedance_percent")
                })
        
        # Generate recommendations
        recommendations = []
        
        if risk_level in ["HIGH", "CRITICAL"]:
            recommendations.append("Dừng hoạt động xả thải ngay lập tức")
            recommendations.append("Kiểm tra và nâng cấp hệ thống xử lý")
            recommendations.append("Báo cáo cơ quan chức năng")
        elif risk_level == "MEDIUM":
            recommendations.append("Tăng cường giám sát các thông số vượt chuẩn")
            recommendations.append("Xem xét cải thiện quy trình xử lý")
        else:
            recommendations.append("Tiếp tục duy trì vận hành")
            recommendations.append("Quan trắc định kỳ theo quy định")
        
        return {
            "risk_level": risk_level,
            "risk_score": risk_score,
            "high_risk_parameters": high_risk_params,
            "compliance_rate": round((1 - non_compliant / total) * 100, 2) if total > 0 else 0,
            "recommendations": recommendations
        }


class ReportGenerationAgent:
    """Agent for generating compliance reports."""
    
    def __init__(self):
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0.3)
    
    def generate(self, state: ComplianceWorkflowState) -> str:
        """Generate comprehensive compliance report."""
        
        facility = state.get("facility_name", "Unknown")
        period = state.get("period", "N/A")
        data = state.get("monitoring_data", {})
        regulations = state.get("regulation_lookup", {})
        compliance = state.get("compliance_check", {})
        risk = state.get("risk_assessment", {})
        
        report = f"""
# BÁO CÁO TUÂN THỦ MÔI TRƯỜNG

## THÔNG TIN CHUNG

| Thông tin | Chi tiết |
|-----------|----------|
| **Cơ sở** | {facility} |
| **Kỳ báo cáo** | {period} |
| **Ngày lấy mẫu** | {data.get('sampling_date', 'N/A')} |
| **Vị trí lấy mẫu** | {data.get('sampling_location', 'N/A')} |
| **Quy chuẩn áp dụng** | {regulations.get('qcvn_applied', 'N/A')} |
| **Ngày lập báo cáo** | {datetime.now().strftime('%d/%m/%Y')} |

---

## TÓM TẮT ĐIỀU HÀNH

### Kết quả tổng thể
- **Trạng thái**: {'✅ ĐẠT' if compliance.get('overall_compliant') else '❌ KHÔNG ĐẠT'}
- **Tỷ lệ tuân thủ**: {risk.get('compliance_rate', 0)}%
- **Mức độ rủi ro**: {risk.get('risk_level', 'N/A')}
- **Số thông số đạt**: {compliance.get('compliant_count', 0)}
- **Số thông số không đạt**: {compliance.get('non_compliant_count', 0)}

---

## KẾT QUẢ CHI TIẾT

### Bảng kết quả quan trắc

| Thông số | Giá trị | Đơn vị | Giới hạn | Trạng thái | Vượt (%) |
|----------|---------|--------|----------|------------|----------|
"""
        
        # Add parameter results
        for param, result in compliance.get("parameter_results", {}).items():
            status_icon = "✅" if result["compliant"] else "❌"
            report += f"| {param} | {result['value']} | {result['unit']} | {result['limit']} | {status_icon} {result['status']} | {result.get('exceedance_percent', 0)} |\n"
        
        report += f"""
---

## ĐÁNH GIÁ RỦI RO

### Mức độ rủi ro: **{risk.get('risk_level', 'N/A')}**

"""
        
        # High risk parameters
        if risk.get("high_risk_parameters"):
            report += "### Các thông số rủi ro cao:\n"
            for hp in risk["high_risk_parameters"]:
                report += f"- **{hp['parameter']}**: Vượt {hp['exceedance']}%\n"
            report += "\n"
        
        # Recommendations
        report += "### Khuyến nghị:\n"
        for i, rec in enumerate(risk.get("recommendations", []), 1):
            report += f"{i}. {rec}\n"
        
        report += f"""
---

## KẾT LUẬN

Cơ sở {facility} {'**ĐẠT**' if compliance.get('overall_compliant') else '**KHÔNG ĐẠT**'} yêu cầu tuân thủ theo {regulations.get('qcvn_applied', 'quy chuẩn áp dụng')}.

{'Cần thực hiện ngay các biện pháp khắc phục.' if not compliance.get('overall_compliant') else 'Tiếp tục duy trì các biện pháp kiểm soát hiện tại.'}

---

*Báo cáo được tạo tự động bởi Environmental Compliance Multi-Agent System*
"""
        
        return report


# ==================== MULTI-AGENT GRAPH ====================

class EnvironmentalComplianceGraph:
    """
    Complete multi-agent system for environmental compliance checking.
    """
    
    def __init__(self, vector_store=None):
        # Initialize agents
        self.data_validator = DataValidationAgent()
        self.regulation_agent = RegulationLookupAgent(vector_store)
        self.compliance_agent = ComplianceCheckAgent()
        self.risk_agent = RiskAssessmentAgent()
        self.report_agent = ReportGenerationAgent()
        
        # Build graph
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build the multi-agent workflow graph."""
        
        graph = StateGraph(ComplianceWorkflowState)
        
        # Add nodes
        graph.add_node("validate_data", self._validate_data_node)
        graph.add_node("lookup_regulations", self._lookup_regulations_node)
        graph.add_node("check_compliance", self._check_compliance_node)
        graph.add_node("assess_risk", self._assess_risk_node)
        graph.add_node("generate_report", self._generate_report_node)
        graph.add_node("handle_error", self._handle_error_node)
        
        # Add edges
        graph.add_edge(START, "validate_data")
        
        # Conditional: valid data or error
        graph.add_conditional_edges(
            "validate_data",
            self._check_validation,
            {
                "valid": "lookup_regulations",
                "invalid": "handle_error"
            }
        )
        
        # Sequential flow
        graph.add_edge("lookup_regulations", "check_compliance")
        graph.add_edge("check_compliance", "assess_risk")
        graph.add_edge("assess_risk", "generate_report")
        graph.add_edge("generate_report", END)
        graph.add_edge("handle_error", END)
        
        # Compile with checkpointer for persistence
        memory = MemorySaver()
        return graph.compile(checkpointer=memory)
    
    def _validate_data_node(self, state: ComplianceWorkflowState) -> Dict:
        """Validate input data."""
        result = self.data_validator.validate(state)
        
        return {
            "data_validation": result,
            "current_stage": "validate_data",
            "completed_stages": ["validate_data"],
            "messages": [AIMessage(content=f"Data validation: {'Valid' if result['is_valid'] else 'Invalid'}")]
        }
    
    def _check_validation(self, state: ComplianceWorkflowState) -> str:
        """Check if validation passed."""
        validation = state.get("data_validation", {})
        return "valid" if validation.get("is_valid", False) else "invalid"
    
    def _lookup_regulations_node(self, state: ComplianceWorkflowState) -> Dict:
        """Lookup applicable regulations."""
        result = self.regulation_agent.lookup(state)
        
        return {
            "regulation_lookup": result,
            "current_stage": "lookup_regulations",
            "completed_stages": state.get("completed_stages", []) + ["lookup_regulations"],
            "messages": [AIMessage(content=f"Applied regulation: {result.get('qcvn_applied')}")]
        }
    
    def _check_compliance_node(self, state: ComplianceWorkflowState) -> Dict:
        """Check compliance against regulations."""
        result = self.compliance_agent.check(state)
        
        status = "COMPLIANT" if result["overall_compliant"] else "NON-COMPLIANT"
        
        return {
            "compliance_check": result,
            "current_stage": "check_compliance",
            "completed_stages": state.get("completed_stages", []) + ["check_compliance"],
            "messages": [AIMessage(content=f"Compliance check: {status}")]
        }
    
    def _assess_risk_node(self, state: ComplianceWorkflowState) -> Dict:
        """Assess environmental risks."""
        result = self.risk_agent.assess(state)
        
        return {
            "risk_assessment": result,
            "current_stage": "assess_risk",
            "completed_stages": state.get("completed_stages", []) + ["assess_risk"],
            "messages": [AIMessage(content=f"Risk level: {result.get('risk_level')}")]
        }
    
    def _generate_report_node(self, state: ComplianceWorkflowState) -> Dict:
        """Generate final report."""
        report = self.report_agent.generate(state)
        
        return {
            "final_report": report,
            "current_stage": "generate_report",
            "completed_stages": state.get("completed_stages", []) + ["generate_report"],
            "completed_at": datetime.now().isoformat(),
            "messages": [AIMessage(content="Report generated successfully")]
        }
    
    def _handle_error_node(self, state: ComplianceWorkflowState) -> Dict:
        """Handle validation errors."""
        validation = state.get("data_validation", {})
        issues = validation.get("issues", [])
        
        error_report = f"""
# LỖI XỬ LÝ

Không thể hoàn thành kiểm tra tuân thủ do dữ liệu đầu vào không hợp lệ.

## Các vấn đề phát hiện:
{"".join(f"- {issue}" for issue in issues)}

## Hướng khắc phục:
Vui lòng kiểm tra và cung cấp lại dữ liệu với đầy đủ thông tin yêu cầu.
"""
        
        return {
            "final_report": error_report,
            "errors": issues,
            "current_stage": "error",
            "completed_at": datetime.now().isoformat()
        }
    
    def run(
        self,
        facility_name: str,
        monitoring_data: Dict,
        period: str = None,
        thread_id: str = None
    ) -> Dict:
        """
        Run the compliance checking workflow.
        
        Args:
            facility_name: Name of the facility
            monitoring_data: Monitoring data dict with 'parameters', 'sampling_date', etc.
            period: Reporting period
            thread_id: Thread ID for persistence
        
        Returns:
            Final state with report
        """
        import uuid
        
        initial_state = {
            "messages": [],
            "facility_name": facility_name,
            "monitoring_data": monitoring_data,
            "period": period or datetime.now().strftime("%m/%Y"),
            "data_validation": None,
            "regulation_lookup": None,
            "compliance_check": None,
            "risk_assessment": None,
            "report_draft": None,
            "final_report": None,
            "current_stage": "start",
            "completed_stages": [],
            "errors": [],
            "started_at": datetime.now().isoformat(),
            "completed_at": None
        }
        
        config = {
            "configurable": {
                "thread_id": thread_id or str(uuid.uuid4())
            }
        }
        
        result = self.graph.invoke(initial_state, config)
        
        return result


# Usage example
if __name__ == "__main__":
    # Sample monitoring data
    sample_data = {
        "parameters": {
            "BOD5": 45,
            "COD": 120,
            "TSS": 80,
            "pH": 7.5,
            "Amonia": 8
        },
        "sampling_date": "2024-01-15",
        "sampling_location": "Điểm xả thải chính",
        "media_type": "wastewater",
        "discharge_type": "B"
    }
    
    # Run workflow
    system = EnvironmentalComplianceGraph()
    
    result = system.run(
        facility_name="Nhà máy ABC",
        monitoring_data=sample_data,
        period="01/2024"
    )
    
    print(result.get("final_report"))
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Basic LangGraph (Ngày 1-2)

```
🎯 Mục tiêu: Understand LangGraph fundamentals

📋 Yêu cầu:
1. Build basic sequential graph
2. Implement conditional routing
3. Create cyclic graph với iteration
4. Add state persistence

📁 Deliverables:
- src/agents/basic_graph.py
- src/agents/conditional_graph.py
- tests/test_graphs.py
```

### Bài tập 2: Supervisor Pattern (Ngày 3-4)

```
🎯 Mục tiêu: Implement supervisor-worker pattern

📋 Yêu cầu:
1. Create worker agents (research, analysis, report)
2. Implement supervisor routing
3. Build supervisor graph
4. Test với environmental scenarios

📁 Deliverables:
- src/agents/workers.py
- src/agents/supervisor.py
- Demo notebook
```

### Bài tập 3: Environmental Multi-Agent System (Ngày 5-7)

```
🎯 Mục tiêu: Build complete multi-agent system

📋 Yêu cầu:
1. Implement all specialized agents
2. Build compliance workflow graph
3. Add error handling
4. Generate professional reports

📁 Deliverables:
- src/systems/compliance_agents.py
- src/systems/compliance_graph.py
- Sample reports
- **PROJECT 3 Started**: Multi-Agent Compliance System
```

---

## ✅ CHECKLIST TUẦN 9

### Kiến thức đã học
- [ ] Multi-agent architecture patterns
- [ ] LangGraph concepts (nodes, edges, state)
- [ ] Conditional routing
- [ ] Supervisor pattern
- [ ] State persistence

### Skills thực hành
- [ ] Build LangGraph workflows
- [ ] Implement custom agents
- [ ] Create supervisor coordination
- [ ] Handle errors gracefully

### Deliverables
- [ ] Basic graph implementations
- [ ] Supervisor pattern
- [ ] Environmental multi-agent system
- [ ] Compliance reports

---

*Hoàn thành Tuần 9 để tiếp tục sang Tuần 10: Document Generation Pipeline*
