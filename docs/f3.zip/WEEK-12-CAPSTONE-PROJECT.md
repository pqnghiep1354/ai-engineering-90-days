# 📅 TUẦN 12: CAPSTONE PROJECT

## 🎯 Environmental Compliance Management System

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (20-30 giờ tập trung) |
| **Mục tiêu chính** | Tích hợp toàn bộ kiến thức vào hệ thống hoàn chỉnh |
| **Output** | Production-ready Environmental Compliance Platform |
| **Độ khó** | ⭐⭐⭐⭐⭐ Expert |

---

## 📋 TỔNG QUAN DỰ ÁN

### Project Description

**Environmental Compliance Management System (ECMS)** là một nền tảng AI hoàn chỉnh giúp các doanh nghiệp tự động hóa quy trình kiểm tra và báo cáo tuân thủ môi trường theo quy định Việt Nam.

### Key Features

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              ENVIRONMENTAL COMPLIANCE MANAGEMENT SYSTEM                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                         CORE FEATURES                                │    │
│  │                                                                      │    │
│  │   ✅ Intelligent Q&A          ✅ Compliance Checking                │    │
│  │      - RAG-based answers         - Real-time validation             │    │
│  │      - Vietnamese support        - QCVN standards                   │    │
│  │      - Source citations          - Multi-parameter                  │    │
│  │                                                                      │    │
│  │   ✅ Automated Reports        ✅ Multi-Agent Workflow               │    │
│  │      - PDF/DOCX export           - Data validation                  │    │
│  │      - Charts & visuals          - Risk assessment                  │    │
│  │      - Professional templates    - Report generation                │    │
│  │                                                                      │    │
│  │   ✅ Tool Integration         ✅ Monitoring Dashboard               │    │
│  │      - Regulation search         - Real-time metrics                │    │
│  │      - Data analysis             - Cost tracking                    │    │
│  │      - Report generation         - Alert system                     │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      TECHNICAL STACK                                 │    │
│  │                                                                      │    │
│  │   Frontend        Backend         AI/ML            Infrastructure   │    │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐      ┌─────────┐       │    │
│  │   │Streamlit│    │ FastAPI │    │LangChain│      │ Docker  │       │    │
│  │   │  React  │    │  Redis  │    │LangGraph│      │   K8s   │       │    │
│  │   └─────────┘    └─────────┘    │ OpenAI  │      │Prometheus│      │    │
│  │                                 │ChromaDB │      │ Grafana │       │    │
│  │                                 └─────────┘      └─────────┘       │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🏗️ SYSTEM ARCHITECTURE

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SYSTEM ARCHITECTURE                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│                              ┌──────────────┐                               │
│                              │    Users     │                               │
│                              └──────┬───────┘                               │
│                                     │                                        │
│                              ┌──────▼───────┐                               │
│                              │   Frontend   │                               │
│                              │  (Streamlit) │                               │
│                              └──────┬───────┘                               │
│                                     │                                        │
│  ┌──────────────────────────────────┼──────────────────────────────────┐    │
│  │                           API Gateway                                │    │
│  │                           (FastAPI)                                  │    │
│  └──────────────────────────────────┼──────────────────────────────────┘    │
│                                     │                                        │
│     ┌───────────────┬───────────────┼───────────────┬───────────────┐       │
│     │               │               │               │               │       │
│     ▼               ▼               ▼               ▼               ▼       │
│  ┌──────┐      ┌──────┐       ┌──────────┐    ┌──────┐       ┌──────┐      │
│  │ RAG  │      │Tools │       │Multi-Agent│   │Report│       │Monitor│     │
│  │Engine│      │Service│      │  System   │   │ Gen  │       │Service│     │
│  └──┬───┘      └──┬───┘       └────┬─────┘   └──┬───┘       └──┬───┘      │
│     │             │                │            │              │           │
│     └─────────────┴────────────────┼────────────┴──────────────┘           │
│                                    │                                        │
│  ┌─────────────────────────────────┼─────────────────────────────────┐     │
│  │                          Data Layer                                │     │
│  │                                                                    │     │
│  │   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐       │     │
│  │   │ChromaDB │    │  Redis  │    │PostgreSQL│   │   S3    │       │     │
│  │   │(Vectors)│    │ (Cache) │    │ (Data)  │    │ (Files) │       │     │
│  │   └─────────┘    └─────────┘    └─────────┘    └─────────┘       │     │
│  │                                                                    │     │
│  └────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Component Details

```python
# ============================================
# PROJECT STRUCTURE
# ============================================

"""
environmental-compliance-system/
│
├── 📁 src/
│   ├── 📁 api/                    # FastAPI backend
│   │   ├── __init__.py
│   │   ├── main.py               # API entry point
│   │   ├── routes/
│   │   │   ├── compliance.py     # Compliance endpoints
│   │   │   ├── qa.py             # Q&A endpoints
│   │   │   ├── reports.py        # Report endpoints
│   │   │   └── monitoring.py     # Monitoring endpoints
│   │   ├── middleware/
│   │   │   ├── auth.py           # Authentication
│   │   │   ├── rate_limit.py     # Rate limiting
│   │   │   └── logging.py        # Request logging
│   │   └── schemas/
│   │       ├── compliance.py     # Pydantic models
│   │       ├── reports.py
│   │       └── responses.py
│   │
│   ├── 📁 rag/                    # RAG system
│   │   ├── __init__.py
│   │   ├── engine.py             # Main RAG engine
│   │   ├── retriever.py          # Hybrid retriever
│   │   ├── reranker.py           # Cohere reranker
│   │   ├── generator.py          # Response generator
│   │   └── evaluator.py          # RAGAS evaluator
│   │
│   ├── 📁 agents/                 # Multi-agent system
│   │   ├── __init__.py
│   │   ├── workers/
│   │   │   ├── validator.py      # Data validation agent
│   │   │   ├── researcher.py     # Research agent
│   │   │   ├── analyzer.py       # Analysis agent
│   │   │   └── reporter.py       # Report agent
│   │   ├── supervisor.py         # Supervisor agent
│   │   └── workflow.py           # LangGraph workflow
│   │
│   ├── 📁 tools/                  # Tool implementations
│   │   ├── __init__.py
│   │   ├── base.py               # Base tool class
│   │   ├── compliance.py         # Compliance checker
│   │   ├── search.py             # Regulation search
│   │   ├── analysis.py           # Data analysis
│   │   └── reports.py            # Report generation
│   │
│   ├── 📁 documents/              # Document generation
│   │   ├── __init__.py
│   │   ├── templates/
│   │   │   ├── compliance_report.html
│   │   │   └── monitoring_report.html
│   │   ├── generator.py          # Report generator
│   │   ├── pdf.py                # PDF export
│   │   └── docx.py               # DOCX export
│   │
│   ├── 📁 cache/                  # Caching layer
│   │   ├── __init__.py
│   │   ├── semantic.py           # Semantic cache
│   │   └── redis.py              # Redis backend
│   │
│   ├── 📁 monitoring/             # Observability
│   │   ├── __init__.py
│   │   ├── metrics.py            # Prometheus metrics
│   │   ├── tracing.py            # Request tracing
│   │   └── alerts.py             # Alert system
│   │
│   └── 📁 core/                   # Core utilities
│       ├── __init__.py
│       ├── config.py             # Configuration
│       ├── database.py           # Database connections
│       └── logging.py            # Logging setup
│
├── 📁 frontend/                   # Streamlit frontend
│   ├── app.py                    # Main app
│   ├── pages/
│   │   ├── 1_qa.py               # Q&A page
│   │   ├── 2_compliance.py       # Compliance check
│   │   ├── 3_reports.py          # Reports
│   │   └── 4_dashboard.py        # Dashboard
│   └── components/
│       ├── chat.py               # Chat component
│       ├── charts.py             # Chart components
│       └── forms.py              # Form components
│
├── 📁 tests/                      # Test suite
│   ├── unit/
│   ├── integration/
│   └── e2e/
│
├── 📁 data/                       # Data files
│   ├── regulations/              # QCVN documents
│   └── samples/                  # Sample data
│
├── 📁 config/                     # Configuration
│   ├── prometheus.yml
│   └── grafana/
│
├── 📁 k8s/                        # Kubernetes manifests
│   ├── deployment.yaml
│   ├── service.yaml
│   └── ingress.yaml
│
├── Dockerfile
├── docker-compose.yml
├── pyproject.toml
├── README.md
└── .github/
    └── workflows/
        └── ci.yml
"""
```

---

## 📝 IMPLEMENTATION GUIDE

### Day 1-2: Core Integration

#### 1.1 Main API Application

```python
# ============================================
# src/api/main.py - MAIN APPLICATION
# ============================================

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager
from typing import Dict, List, Optional
import uvicorn

from src.core.config import settings
from src.core.logging import setup_logging
from src.api.routes import compliance, qa, reports, monitoring
from src.api.middleware.rate_limit import RateLimitMiddleware
from src.monitoring.metrics import PrometheusMetrics

# Lifespan management
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management."""
    # Startup
    setup_logging()
    await initialize_services()
    yield
    # Shutdown
    await cleanup_services()

async def initialize_services():
    """Initialize all services on startup."""
    from src.rag.engine import RAGEngine
    from src.agents.workflow import ComplianceWorkflow
    from src.cache.semantic import SemanticCache
    
    # Initialize RAG
    app.state.rag_engine = RAGEngine(
        vector_store_path=settings.CHROMA_PATH,
        embedding_model=settings.EMBEDDING_MODEL,
        llm_model=settings.LLM_MODEL
    )
    
    # Initialize workflow
    app.state.workflow = ComplianceWorkflow()
    
    # Initialize cache
    app.state.cache = SemanticCache(
        redis_url=settings.REDIS_URL
    )
    
    # Initialize metrics
    app.state.metrics = PrometheusMetrics()

async def cleanup_services():
    """Cleanup services on shutdown."""
    if hasattr(app.state, 'cache'):
        await app.state.cache.close()

# Create application
app = FastAPI(
    title="Environmental Compliance Management System",
    description="AI-powered environmental compliance checking and reporting",
    version="1.0.0",
    lifespan=lifespan
)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(RateLimitMiddleware, rate_limit=100, window=60)

# Include routers
app.include_router(qa.router, prefix="/api/qa", tags=["Q&A"])
app.include_router(compliance.router, prefix="/api/compliance", tags=["Compliance"])
app.include_router(reports.router, prefix="/api/reports", tags=["Reports"])
app.include_router(monitoring.router, prefix="/api/monitoring", tags=["Monitoring"])

# Health check
@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "services": {
            "rag": "operational",
            "cache": "operational",
            "database": "operational"
        }
    }

# Metrics endpoint
@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint."""
    return app.state.metrics.export()

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG
    )


# ============================================
# src/api/routes/compliance.py - COMPLIANCE ROUTES
# ============================================

from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from typing import Dict, List, Optional
from datetime import datetime

router = APIRouter()

class ComplianceCheckRequest(BaseModel):
    """Request model for compliance check."""
    parameter: str = Field(..., description="Parameter name (e.g., BOD5, COD)")
    value: float = Field(..., description="Measured value")
    standard: str = Field(default="QCVN_40_2011", description="Standard to check against")
    column: str = Field(default="B", description="Column A or B")

class ComplianceCheckResponse(BaseModel):
    """Response model for compliance check."""
    parameter: str
    measured_value: float
    unit: str
    standard: str
    limit: str
    compliant: bool
    status: str
    exceedance_percent: float
    checked_at: str

class WorkflowRequest(BaseModel):
    """Request for full compliance workflow."""
    facility_name: str
    monitoring_data: Dict
    period: Optional[str] = None

class WorkflowResponse(BaseModel):
    """Response from compliance workflow."""
    workflow_id: str
    status: str
    compliance_result: Optional[Dict] = None
    risk_assessment: Optional[Dict] = None
    report_url: Optional[str] = None
    completed_at: Optional[str] = None

@router.post("/check", response_model=ComplianceCheckResponse)
async def check_compliance(
    request: ComplianceCheckRequest,
    req: Request
):
    """
    Check single parameter compliance against QCVN standard.
    """
    from src.tools.compliance import ComplianceCheckerTool
    
    checker = ComplianceCheckerTool()
    
    result = checker.execute(
        parameter=request.parameter,
        value=request.value,
        standard=request.standard,
        column=request.column
    )
    
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    
    # Track metrics
    req.app.state.metrics.track_compliance_check(
        parameter=request.parameter,
        compliant=result["compliant"]
    )
    
    return ComplianceCheckResponse(**result)

@router.post("/workflow", response_model=WorkflowResponse)
async def run_compliance_workflow(
    request: WorkflowRequest,
    req: Request
):
    """
    Run full compliance checking workflow.
    
    This executes the multi-agent system that:
    1. Validates input data
    2. Looks up applicable regulations
    3. Checks compliance for all parameters
    4. Assesses risks
    5. Generates report
    """
    import uuid
    
    workflow_id = str(uuid.uuid4())
    
    try:
        result = req.app.state.workflow.run(
            facility_name=request.facility_name,
            monitoring_data=request.monitoring_data,
            period=request.period
        )
        
        # Generate report
        report_url = None
        if result.get("final_report"):
            from src.documents.generator import ReportGenerator
            
            generator = ReportGenerator()
            report_path = generator.generate_pdf(
                data=result,
                filename=f"report_{workflow_id}.pdf"
            )
            report_url = f"/api/reports/download/{workflow_id}"
        
        return WorkflowResponse(
            workflow_id=workflow_id,
            status="completed",
            compliance_result=result.get("compliance_check"),
            risk_assessment=result.get("risk_assessment"),
            report_url=report_url,
            completed_at=datetime.now().isoformat()
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/batch")
async def batch_compliance_check(
    parameters: List[ComplianceCheckRequest],
    req: Request
):
    """
    Check compliance for multiple parameters.
    """
    from src.tools.compliance import ComplianceCheckerTool
    
    checker = ComplianceCheckerTool()
    results = []
    
    for param in parameters:
        result = checker.execute(
            parameter=param.parameter,
            value=param.value,
            standard=param.standard,
            column=param.column
        )
        results.append(result)
    
    # Summary
    compliant_count = sum(1 for r in results if r.get("compliant", False))
    
    return {
        "total": len(results),
        "compliant": compliant_count,
        "non_compliant": len(results) - compliant_count,
        "results": results
    }


# ============================================
# src/api/routes/qa.py - Q&A ROUTES
# ============================================

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from typing import Dict, List, Optional
from sse_starlette.sse import EventSourceResponse
import asyncio

router = APIRouter()

class QARequest(BaseModel):
    """Request model for Q&A."""
    query: str = Field(..., description="User question")
    conversation_id: Optional[str] = None
    stream: bool = Field(default=False, description="Enable streaming response")

class QAResponse(BaseModel):
    """Response model for Q&A."""
    answer: str
    sources: List[Dict]
    conversation_id: str
    latency_ms: float

@router.post("/ask", response_model=QAResponse)
async def ask_question(
    request: QARequest,
    req: Request
):
    """
    Ask a question about environmental regulations.
    
    Uses RAG to retrieve relevant context and generate answer.
    """
    import time
    import uuid
    
    start_time = time.perf_counter()
    
    # Check cache first
    cached = await req.app.state.cache.get(request.query)
    if cached:
        return QAResponse(
            answer=cached["answer"],
            sources=cached["sources"],
            conversation_id=request.conversation_id or str(uuid.uuid4()),
            latency_ms=(time.perf_counter() - start_time) * 1000
        )
    
    # Query RAG
    result = req.app.state.rag_engine.query(
        query=request.query,
        conversation_id=request.conversation_id
    )
    
    # Cache result
    await req.app.state.cache.set(
        request.query,
        {"answer": result["answer"], "sources": result["sources"]}
    )
    
    latency = (time.perf_counter() - start_time) * 1000
    
    # Track metrics
    req.app.state.metrics.track_query(latency_ms=latency)
    
    return QAResponse(
        answer=result["answer"],
        sources=result["sources"],
        conversation_id=result.get("conversation_id", str(uuid.uuid4())),
        latency_ms=latency
    )

@router.post("/ask/stream")
async def ask_question_stream(
    request: QARequest,
    req: Request
):
    """
    Ask a question with streaming response.
    """
    async def generate():
        async for chunk in req.app.state.rag_engine.aquery_stream(
            query=request.query
        ):
            yield {
                "event": "message",
                "data": chunk
            }
        yield {"event": "done", "data": ""}
    
    return EventSourceResponse(generate())
```

### Day 3-4: Frontend Development

#### 2.1 Streamlit Application

```python
# ============================================
# frontend/app.py - MAIN STREAMLIT APP
# ============================================

import streamlit as st
import requests
from typing import Dict, List, Optional
import json

# Page config
st.set_page_config(
    page_title="Environmental Compliance System",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded"
)

# API configuration
API_BASE_URL = st.secrets.get("API_URL", "http://localhost:8000")

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #2C3E50;
        text-align: center;
        padding: 1rem;
    }
    .status-compliant {
        background-color: #27AE60;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-weight: bold;
    }
    .status-non-compliant {
        background-color: #E74C3C;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-weight: bold;
    }
    .metric-card {
        background-color: #F8F9FA;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
    }
    .chat-message {
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 1rem;
    }
    .user-message {
        background-color: #E3F2FD;
    }
    .assistant-message {
        background-color: #F5F5F5;
    }
</style>
""", unsafe_allow_html=True)

# Session state initialization
if "messages" not in st.session_state:
    st.session_state.messages = []
if "conversation_id" not in st.session_state:
    st.session_state.conversation_id = None

def main():
    """Main application."""
    
    # Header
    st.markdown('<h1 class="main-header">🌿 Hệ Thống Quản Lý Tuân Thủ Môi Trường</h1>', 
                unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.image("https://via.placeholder.com/150x50?text=ECMS", width=150)
        st.markdown("---")
        
        page = st.radio(
            "📋 Chức năng",
            ["💬 Hỏi đáp", "✅ Kiểm tra tuân thủ", "📊 Báo cáo", "📈 Dashboard"],
            index=0
        )
        
        st.markdown("---")
        st.markdown("### ℹ️ Thông tin")
        st.markdown("""
        - **Version**: 1.0.0
        - **API**: Connected ✅
        """)
    
    # Page routing
    if page == "💬 Hỏi đáp":
        qa_page()
    elif page == "✅ Kiểm tra tuân thủ":
        compliance_page()
    elif page == "📊 Báo cáo":
        reports_page()
    elif page == "📈 Dashboard":
        dashboard_page()

def qa_page():
    """Q&A page with chat interface."""
    
    st.subheader("💬 Hỏi đáp về quy định môi trường")
    
    # Display chat history
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("sources"):
                with st.expander("📚 Nguồn tham khảo"):
                    for source in message["sources"]:
                        st.markdown(f"- {source.get('doc_number', 'N/A')}: {source.get('title', '')}")
    
    # Chat input
    if prompt := st.chat_input("Nhập câu hỏi của bạn..."):
        # Add user message
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # Get response
        with st.chat_message("assistant"):
            with st.spinner("Đang tìm kiếm..."):
                try:
                    response = requests.post(
                        f"{API_BASE_URL}/api/qa/ask",
                        json={
                            "query": prompt,
                            "conversation_id": st.session_state.conversation_id
                        }
                    )
                    
                    if response.status_code == 200:
                        data = response.json()
                        st.markdown(data["answer"])
                        
                        # Show sources
                        if data.get("sources"):
                            with st.expander("📚 Nguồn tham khảo"):
                                for source in data["sources"]:
                                    st.markdown(f"- {source.get('doc_number', 'N/A')}")
                        
                        # Update session
                        st.session_state.conversation_id = data.get("conversation_id")
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": data["answer"],
                            "sources": data.get("sources", [])
                        })
                        
                        # Show latency
                        st.caption(f"⏱️ {data['latency_ms']:.0f}ms")
                    else:
                        st.error("Có lỗi xảy ra. Vui lòng thử lại.")
                        
                except Exception as e:
                    st.error(f"Lỗi kết nối: {str(e)}")
    
    # Clear chat button
    if st.button("🗑️ Xóa lịch sử chat"):
        st.session_state.messages = []
        st.session_state.conversation_id = None
        st.rerun()

def compliance_page():
    """Compliance checking page."""
    
    st.subheader("✅ Kiểm tra tuân thủ môi trường")
    
    tab1, tab2 = st.tabs(["📝 Kiểm tra đơn lẻ", "📋 Kiểm tra hàng loạt"])
    
    with tab1:
        single_check_form()
    
    with tab2:
        batch_check_form()

def single_check_form():
    """Single parameter check form."""
    
    col1, col2 = st.columns(2)
    
    with col1:
        parameter = st.selectbox(
            "Thông số",
            ["BOD5", "COD", "TSS", "pH", "Amonia", "Tong_Nito", "Tong_Photpho", "Coliform"]
        )
        
        value = st.number_input(
            "Giá trị đo",
            min_value=0.0,
            max_value=10000.0,
            value=30.0
        )
    
    with col2:
        standard = st.selectbox(
            "Quy chuẩn",
            ["QCVN_40_2011", "QCVN_05_2023"]
        )
        
        column = st.selectbox(
            "Cột áp dụng",
            ["A", "B"]
        )
    
    if st.button("🔍 Kiểm tra", type="primary"):
        with st.spinner("Đang kiểm tra..."):
            try:
                response = requests.post(
                    f"{API_BASE_URL}/api/compliance/check",
                    json={
                        "parameter": parameter,
                        "value": value,
                        "standard": standard,
                        "column": column
                    }
                )
                
                if response.status_code == 200:
                    result = response.json()
                    display_compliance_result(result)
                else:
                    st.error("Có lỗi xảy ra")
                    
            except Exception as e:
                st.error(f"Lỗi: {str(e)}")

def batch_check_form():
    """Batch compliance check form."""
    
    st.markdown("### Nhập dữ liệu quan trắc")
    
    # Form for batch input
    with st.form("batch_form"):
        facility_name = st.text_input("Tên cơ sở", "Nhà máy ABC")
        
        col1, col2 = st.columns(2)
        with col1:
            sampling_date = st.date_input("Ngày lấy mẫu")
        with col2:
            sampling_location = st.text_input("Vị trí lấy mẫu", "Điểm xả thải chính")
        
        st.markdown("### Giá trị đo")
        
        # Parameter inputs
        params = {}
        param_cols = st.columns(4)
        
        param_list = ["BOD5", "COD", "TSS", "pH", "Amonia", "Tong_Nito", "Tong_Photpho", "Coliform"]
        
        for i, param in enumerate(param_list):
            with param_cols[i % 4]:
                params[param] = st.number_input(
                    param,
                    min_value=0.0 if param != "pH" else 0.0,
                    max_value=10000.0 if param != "pH" else 14.0,
                    value=30.0 if param != "pH" else 7.0,
                    key=f"param_{param}"
                )
        
        submitted = st.form_submit_button("🚀 Chạy kiểm tra đầy đủ", type="primary")
    
    if submitted:
        with st.spinner("Đang xử lý..."):
            try:
                response = requests.post(
                    f"{API_BASE_URL}/api/compliance/workflow",
                    json={
                        "facility_name": facility_name,
                        "monitoring_data": {
                            "parameters": params,
                            "sampling_date": sampling_date.isoformat(),
                            "sampling_location": sampling_location,
                            "media_type": "wastewater",
                            "discharge_type": "B"
                        }
                    }
                )
                
                if response.status_code == 200:
                    result = response.json()
                    display_workflow_result(result)
                else:
                    st.error("Có lỗi xảy ra")
                    
            except Exception as e:
                st.error(f"Lỗi: {str(e)}")

def display_compliance_result(result: Dict):
    """Display single compliance check result."""
    
    st.markdown("---")
    st.markdown("### Kết quả kiểm tra")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Thông số", result["parameter"])
    
    with col2:
        st.metric("Giá trị đo", f"{result['measured_value']} {result['unit']}")
    
    with col3:
        st.metric("Giới hạn", f"{result['limit']} {result['unit']}")
    
    # Status
    if result["compliant"]:
        st.success(f"✅ **{result['status']}** - Thông số nằm trong giới hạn cho phép")
    else:
        st.error(f"❌ **{result['status']}** - Vượt {result['exceedance_percent']}%")

def display_workflow_result(result: Dict):
    """Display full workflow result."""
    
    st.markdown("---")
    st.markdown("### 📊 Kết quả kiểm tra đầy đủ")
    
    compliance = result.get("compliance_result", {})
    risk = result.get("risk_assessment", {})
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Trạng thái",
            "ĐẠT" if compliance.get("overall_compliant") else "KHÔNG ĐẠT"
        )
    
    with col2:
        st.metric("Mức độ rủi ro", risk.get("risk_level", "N/A"))
    
    with col3:
        st.metric("Tỷ lệ tuân thủ", f"{risk.get('compliance_rate', 0)}%")
    
    with col4:
        st.metric(
            "Thông số",
            f"{compliance.get('compliant_count', 0)}/{compliance.get('compliant_count', 0) + compliance.get('non_compliant_count', 0)}"
        )
    
    # Detailed results table
    st.markdown("### 📋 Chi tiết kết quả")
    
    import pandas as pd
    
    param_results = compliance.get("parameter_results", {})
    if param_results:
        df = pd.DataFrame([
            {
                "Thông số": param,
                "Giá trị": data["value"],
                "Đơn vị": data["unit"],
                "Giới hạn": data["limit"],
                "Trạng thái": data["status"],
                "Vượt (%)": data.get("exceedance_percent", 0)
            }
            for param, data in param_results.items()
        ])
        
        st.dataframe(df, use_container_width=True)
    
    # Download report
    if result.get("report_url"):
        st.markdown("### 📥 Tải báo cáo")
        st.download_button(
            "📄 Tải báo cáo PDF",
            data=requests.get(f"{API_BASE_URL}{result['report_url']}").content,
            file_name="compliance_report.pdf",
            mime="application/pdf"
        )

def reports_page():
    """Reports management page."""
    
    st.subheader("📊 Quản lý báo cáo")
    
    # Report history (mock)
    st.markdown("### 📋 Lịch sử báo cáo")
    
    reports = [
        {"id": "RPT001", "facility": "Nhà máy ABC", "date": "2024-01-15", "status": "Completed"},
        {"id": "RPT002", "facility": "Công ty XYZ", "date": "2024-01-14", "status": "Completed"},
    ]
    
    for report in reports:
        col1, col2, col3, col4 = st.columns([2, 3, 2, 2])
        
        with col1:
            st.write(report["id"])
        with col2:
            st.write(report["facility"])
        with col3:
            st.write(report["date"])
        with col4:
            st.button("📥 Tải", key=f"dl_{report['id']}")

def dashboard_page():
    """Monitoring dashboard page."""
    
    st.subheader("📈 Dashboard giám sát")
    
    # Metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Tổng truy vấn hôm nay", "156", "+12%")
    
    with col2:
        st.metric("Kiểm tra tuân thủ", "45", "-5%")
    
    with col3:
        st.metric("Báo cáo tạo", "12", "+20%")
    
    with col4:
        st.metric("Độ trễ trung bình", "234ms", "-15ms")
    
    # Charts
    st.markdown("### 📊 Thống kê")
    
    import plotly.express as px
    import pandas as pd
    
    # Sample data
    dates = pd.date_range(start="2024-01-01", periods=30, freq="D")
    df = pd.DataFrame({
        "date": dates,
        "queries": [50 + i * 2 + (i % 7) * 5 for i in range(30)],
        "compliance_checks": [20 + i + (i % 5) * 3 for i in range(30)]
    })
    
    fig = px.line(
        df, x="date", y=["queries", "compliance_checks"],
        title="Hoạt động hệ thống"
    )
    st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()
```

### Day 5-6: Testing và Documentation

#### 3.1 Comprehensive Test Suite

```python
# ============================================
# tests/test_integration.py - INTEGRATION TESTS
# ============================================

import pytest
from fastapi.testclient import TestClient
from unittest.mock import MagicMock, patch
import json

# Import app
from src.api.main import app

@pytest.fixture
def client():
    """Create test client."""
    return TestClient(app)

@pytest.fixture
def mock_rag_engine():
    """Mock RAG engine."""
    mock = MagicMock()
    mock.query.return_value = {
        "answer": "BOD5 theo QCVN 40:2011 có giới hạn 50 mg/L cho cột B.",
        "sources": [{"doc_number": "QCVN 40:2011", "title": "Nước thải công nghiệp"}],
        "conversation_id": "test-123"
    }
    return mock

class TestHealthEndpoint:
    """Tests for health endpoint."""
    
    def test_health_returns_200(self, client):
        response = client.get("/health")
        assert response.status_code == 200
    
    def test_health_returns_status(self, client):
        response = client.get("/health")
        assert response.json()["status"] == "healthy"

class TestComplianceEndpoints:
    """Tests for compliance endpoints."""
    
    def test_check_compliant_parameter(self, client):
        response = client.post(
            "/api/compliance/check",
            json={
                "parameter": "BOD5",
                "value": 30,
                "standard": "QCVN_40_2011",
                "column": "B"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["compliant"] is True
        assert data["status"] == "ĐẠT"
    
    def test_check_non_compliant_parameter(self, client):
        response = client.post(
            "/api/compliance/check",
            json={
                "parameter": "BOD5",
                "value": 100,
                "standard": "QCVN_40_2011",
                "column": "B"
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["compliant"] is False
        assert data["status"] == "KHÔNG ĐẠT"
        assert data["exceedance_percent"] > 0
    
    def test_check_invalid_parameter(self, client):
        response = client.post(
            "/api/compliance/check",
            json={
                "parameter": "INVALID",
                "value": 30,
                "standard": "QCVN_40_2011",
                "column": "B"
            }
        )
        
        assert response.status_code == 400
    
    def test_batch_compliance_check(self, client):
        response = client.post(
            "/api/compliance/batch",
            json=[
                {"parameter": "BOD5", "value": 30, "standard": "QCVN_40_2011", "column": "B"},
                {"parameter": "COD", "value": 200, "standard": "QCVN_40_2011", "column": "B"}
            ]
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 2
        assert "compliant" in data
        assert "non_compliant" in data

class TestQAEndpoints:
    """Tests for Q&A endpoints."""
    
    @patch('src.api.routes.qa.requests')
    def test_ask_returns_answer(self, mock_requests, client, mock_rag_engine):
        # Setup mock
        with patch.object(app.state, 'rag_engine', mock_rag_engine):
            with patch.object(app.state, 'cache', MagicMock(get=MagicMock(return_value=None))):
                response = client.post(
                    "/api/qa/ask",
                    json={"query": "Giới hạn BOD5?"}
                )
                
                assert response.status_code == 200
                data = response.json()
                assert "answer" in data
                assert "sources" in data

class TestWorkflowEndpoints:
    """Tests for workflow endpoints."""
    
    def test_workflow_completes(self, client):
        response = client.post(
            "/api/compliance/workflow",
            json={
                "facility_name": "Test Facility",
                "monitoring_data": {
                    "parameters": {"BOD5": 30, "COD": 100},
                    "sampling_date": "2024-01-15",
                    "sampling_location": "Test",
                    "media_type": "wastewater"
                }
            }
        )
        
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "completed"
        assert "workflow_id" in data
```

### Day 7: Final Integration và Demo

#### 4.1 Demo Script

```python
# ============================================
# demo/run_demo.py - DEMONSTRATION SCRIPT
# ============================================

"""
Environmental Compliance Management System - Demo Script

This script demonstrates the full capabilities of the ECMS system.
"""

import requests
import time
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress
import json

console = Console()
API_BASE = "http://localhost:8000"

def demo_header():
    """Print demo header."""
    console.print(Panel.fit(
        "[bold green]🌿 Environmental Compliance Management System[/bold green]\n"
        "[dim]AI-Powered Compliance Checking and Reporting[/dim]",
        border_style="green"
    ))
    console.print()

def demo_health_check():
    """Demo health check."""
    console.print("[bold blue]1. Health Check[/bold blue]")
    
    response = requests.get(f"{API_BASE}/health")
    data = response.json()
    
    table = Table(title="System Status")
    table.add_column("Service", style="cyan")
    table.add_column("Status", style="green")
    
    for service, status in data["services"].items():
        table.add_row(service, status)
    
    console.print(table)
    console.print()

def demo_qa():
    """Demo Q&A system."""
    console.print("[bold blue]2. Q&A System Demo[/bold blue]")
    
    questions = [
        "Giới hạn BOD5 theo QCVN 40:2011 là bao nhiêu?",
        "Quy trình xin giấy phép môi trường gồm những bước nào?",
        "Tần suất quan trắc nước thải theo quy định?"
    ]
    
    for q in questions:
        console.print(f"\n[yellow]Q: {q}[/yellow]")
        
        response = requests.post(
            f"{API_BASE}/api/qa/ask",
            json={"query": q}
        )
        
        if response.status_code == 200:
            data = response.json()
            console.print(f"[green]A: {data['answer'][:200]}...[/green]")
            console.print(f"[dim]Latency: {data['latency_ms']:.0f}ms[/dim]")
    
    console.print()

def demo_compliance_check():
    """Demo compliance checking."""
    console.print("[bold blue]3. Compliance Check Demo[/bold blue]")
    
    # Sample data
    parameters = [
        {"parameter": "BOD5", "value": 45, "standard": "QCVN_40_2011", "column": "B"},
        {"parameter": "COD", "value": 180, "standard": "QCVN_40_2011", "column": "B"},
        {"parameter": "TSS", "value": 80, "standard": "QCVN_40_2011", "column": "B"},
        {"parameter": "pH", "value": 7.5, "standard": "QCVN_40_2011", "column": "B"},
    ]
    
    table = Table(title="Compliance Check Results")
    table.add_column("Parameter")
    table.add_column("Value")
    table.add_column("Limit")
    table.add_column("Status")
    table.add_column("Exceedance")
    
    for param in parameters:
        response = requests.post(
            f"{API_BASE}/api/compliance/check",
            json=param
        )
        
        if response.status_code == 200:
            data = response.json()
            status_style = "green" if data["compliant"] else "red"
            
            table.add_row(
                data["parameter"],
                f"{data['measured_value']} {data['unit']}",
                f"{data['limit']} {data['unit']}",
                f"[{status_style}]{data['status']}[/{status_style}]",
                f"{data['exceedance_percent']}%"
            )
    
    console.print(table)
    console.print()

def demo_full_workflow():
    """Demo full compliance workflow."""
    console.print("[bold blue]4. Full Compliance Workflow Demo[/bold blue]")
    
    console.print("\n[dim]Running multi-agent workflow...[/dim]")
    
    with Progress() as progress:
        task = progress.add_task("[green]Processing...", total=100)
        
        response = requests.post(
            f"{API_BASE}/api/compliance/workflow",
            json={
                "facility_name": "Demo Factory",
                "monitoring_data": {
                    "parameters": {
                        "BOD5": 45,
                        "COD": 180,
                        "TSS": 80,
                        "pH": 7.5,
                        "Amonia": 12
                    },
                    "sampling_date": "2024-01-15",
                    "sampling_location": "Main Discharge Point",
                    "media_type": "wastewater",
                    "discharge_type": "B"
                },
                "period": "01/2024"
            }
        )
        
        progress.update(task, completed=100)
    
    if response.status_code == 200:
        data = response.json()
        
        console.print(Panel(
            f"[bold]Workflow ID:[/bold] {data['workflow_id']}\n"
            f"[bold]Status:[/bold] {data['status']}\n"
            f"[bold]Compliance:[/bold] {'✅ PASS' if data['compliance_result']['overall_compliant'] else '❌ FAIL'}\n"
            f"[bold]Risk Level:[/bold] {data['risk_assessment']['risk_level']}\n"
            f"[bold]Report URL:[/bold] {data.get('report_url', 'N/A')}",
            title="Workflow Result"
        ))
    
    console.print()

def demo_summary():
    """Print demo summary."""
    console.print(Panel.fit(
        "[bold green]✅ Demo Completed Successfully![/bold green]\n\n"
        "The Environmental Compliance Management System provides:\n"
        "• AI-powered Q&A for regulations\n"
        "• Real-time compliance checking\n"
        "• Multi-agent workflow automation\n"
        "• Professional report generation\n"
        "• Monitoring and observability",
        border_style="green"
    ))

def main():
    """Run full demo."""
    demo_header()
    
    console.print("[dim]Starting demonstration...[/dim]\n")
    time.sleep(1)
    
    try:
        demo_health_check()
        time.sleep(0.5)
        
        demo_qa()
        time.sleep(0.5)
        
        demo_compliance_check()
        time.sleep(0.5)
        
        demo_full_workflow()
        time.sleep(0.5)
        
        demo_summary()
        
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        console.print("[yellow]Make sure the API server is running at localhost:8000[/yellow]")

if __name__ == "__main__":
    main()
```

---

## 📋 PROJECT DELIVERABLES CHECKLIST

### Code Deliverables

```
✅ Backend API (FastAPI)
   ├── Health & metrics endpoints
   ├── Compliance checking endpoints
   ├── Q&A endpoints
   ├── Report endpoints
   └── Workflow endpoints

✅ RAG System
   ├── Hybrid retriever
   ├── Reranking
   ├── Response generator
   └── Semantic caching

✅ Multi-Agent System
   ├── Worker agents
   ├── Supervisor agent
   ├── LangGraph workflow
   └── State management

✅ Tools
   ├── Compliance checker
   ├── Regulation search
   ├── Data analysis
   └── Report generation

✅ Document Generation
   ├── HTML templates
   ├── PDF export
   ├── DOCX export
   └── Chart generation

✅ Frontend (Streamlit)
   ├── Q&A interface
   ├── Compliance forms
   ├── Report viewer
   └── Dashboard

✅ Infrastructure
   ├── Dockerfile
   ├── docker-compose.yml
   ├── Kubernetes manifests
   └── CI/CD pipeline
```

### Documentation Deliverables

```
✅ README.md - Project overview
✅ API Documentation - OpenAPI/Swagger
✅ User Guide - How to use the system
✅ Developer Guide - How to extend
✅ Deployment Guide - How to deploy
✅ Architecture Diagram - System design
```

### Quality Deliverables

```
✅ Unit Tests - >80% coverage
✅ Integration Tests - API testing
✅ E2E Tests - Full workflow testing
✅ Performance Tests - Latency benchmarks
✅ Security Scan - Vulnerability check
```

---

## 🎯 EVALUATION CRITERIA

### Technical Quality (40%)

| Criteria | Weight | Target |
|----------|--------|--------|
| Code organization | 10% | Clean, modular |
| Error handling | 10% | Comprehensive |
| Performance | 10% | P95 < 2s |
| Test coverage | 10% | > 80% |

### Functionality (30%)

| Criteria | Weight | Target |
|----------|--------|--------|
| RAG accuracy | 10% | Faithfulness > 0.8 |
| Compliance checking | 10% | 100% accurate |
| Report generation | 10% | Professional quality |

### Production Readiness (20%)

| Criteria | Weight | Target |
|----------|--------|--------|
| Deployment | 10% | Docker ready |
| Monitoring | 5% | Metrics + alerts |
| Documentation | 5% | Complete |

### Innovation (10%)

| Criteria | Weight | Target |
|----------|--------|--------|
| Vietnamese support | 5% | Native handling |
| User experience | 5% | Intuitive UI |

---

## 🚀 DEPLOYMENT COMMANDS

```bash
# Development
docker-compose up -d

# Production
docker-compose -f docker-compose.prod.yml up -d

# Kubernetes
kubectl apply -f k8s/

# Run tests
pytest tests/ -v --cov=src

# Run demo
python demo/run_demo.py
```

---

## ✅ FINAL CHECKLIST

### Project Completion

- [ ] All API endpoints working
- [ ] RAG system functional
- [ ] Multi-agent workflow complete
- [ ] Document generation working
- [ ] Frontend deployed
- [ ] Tests passing
- [ ] Docker images built
- [ ] Documentation complete

### Portfolio Ready

- [ ] GitHub repository organized
- [ ] README with badges
- [ ] Demo video/GIF
- [ ] Architecture diagram
- [ ] Performance benchmarks
- [ ] Live demo link

---

## 🎉 CONGRATULATIONS!

Bạn đã hoàn thành **90-Day AI Engineering Roadmap**!

### Skills Acquired

- ✅ Python & Data Processing
- ✅ ML/NLP Fundamentals
- ✅ Vector Databases
- ✅ LLM & Prompt Engineering
- ✅ Advanced RAG Architecture
- ✅ LangChain & LlamaIndex
- ✅ Production Optimization
- ✅ Function Calling & Tools
- ✅ Multi-Agent Systems
- ✅ Document Generation
- ✅ Testing & Deployment
- ✅ Full Stack AI Application

### Next Steps

1. **Polish Portfolio** - Add demo videos, improve documentation
2. **Deploy Live** - Get a public URL for your project
3. **Apply for Jobs** - You're ready for AI Engineer positions!
4. **Keep Learning** - Explore fine-tuning, multimodal, etc.

---

*🌟 Chúc mừng bạn đã hoàn thành lộ trình! Good luck với career trong AI Engineering! 🚀*
