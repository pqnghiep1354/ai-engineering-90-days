# 📅 TUẦN 11: TESTING & DEPLOYMENT

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Testing strategies và production deployment |
| **Output** | Deployed Environmental Compliance System |
| **Độ khó** | ⭐⭐⭐⭐ Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu testing strategies cho AI systems
- [ ] Nắm vững CI/CD pipelines
- [ ] Hiểu containerization với Docker
- [ ] Biết cloud deployment patterns

### Kỹ năng (Skills)
- [ ] Write unit, integration, và end-to-end tests
- [ ] Setup CI/CD với GitHub Actions
- [ ] Containerize applications với Docker
- [ ] Deploy lên cloud platforms

### Ứng dụng (Application)
- [ ] Complete test suite cho compliance system
- [ ] Docker deployment
- [ ] Production monitoring setup

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: Testing AI Systems

#### 1.1 Testing Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         AI SYSTEM TESTING PYRAMID                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│                           ┌─────────────────┐                               │
│                           │    E2E Tests    │                               │
│                           │   (UI/API)      │  ◄── Few, Slow, Expensive    │
│                           └────────┬────────┘                               │
│                                    │                                        │
│                        ┌───────────┴───────────┐                           │
│                        │  Integration Tests    │                           │
│                        │  (RAG, Agents, LLM)   │  ◄── Medium                │
│                        └───────────┬───────────┘                           │
│                                    │                                        │
│              ┌─────────────────────┴─────────────────────┐                 │
│              │            Unit Tests                      │                 │
│              │  (Functions, Classes, Components)          │ ◄── Many, Fast │
│              └────────────────────────────────────────────┘                 │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    AI-SPECIFIC TESTING                               │    │
│  │                                                                      │    │
│  │   ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐   │    │
│  │   │  Response  │  │  Quality   │  │   Cost     │  │  Latency   │   │    │
│  │   │  Quality   │  │  Metrics   │  │  Testing   │  │  Testing   │   │    │
│  │   └────────────┘  └────────────┘  └────────────┘  └────────────┘   │    │
│  │                                                                      │    │
│  │   ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐   │    │
│  │   │  Edge      │  │ Regression │  │   A/B      │  │  Safety    │   │    │
│  │   │  Cases     │  │  Testing   │  │  Testing   │  │  Testing   │   │    │
│  │   └────────────┘  └────────────┘  └────────────┘  └────────────┘   │    │
│  │                                                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 Testing Framework

```python
# ============================================
# AI SYSTEM TESTING FRAMEWORK
# ============================================

import pytest
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
from unittest.mock import Mock, patch, MagicMock
import json
import asyncio
from abc import ABC, abstractmethod
import numpy as np

# ==================== TEST DATA ====================

@dataclass
class TestCase:
    """Test case for AI system testing."""
    id: str
    name: str
    description: str
    input_data: Dict[str, Any]
    expected_output: Optional[Dict[str, Any]] = None
    validation_fn: Optional[Callable] = None
    tags: List[str] = field(default_factory=list)
    timeout_seconds: int = 30

@dataclass
class TestResult:
    """Result of a test execution."""
    test_case: TestCase
    passed: bool
    actual_output: Any
    error: Optional[str] = None
    latency_ms: float = 0
    cost_usd: float = 0
    metadata: Dict = field(default_factory=dict)


class TestDataset:
    """
    Test dataset for environmental compliance system.
    """
    
    COMPLIANCE_TEST_CASES = [
        TestCase(
            id="compliance_001",
            name="BOD5 compliant value",
            description="Test BOD5 within limit",
            input_data={
                "parameter": "BOD5",
                "value": 30,
                "standard": "QCVN_40_2011",
                "column": "B"
            },
            expected_output={
                "compliant": True,
                "status": "ĐẠT"
            },
            tags=["compliance", "unit", "happy_path"]
        ),
        TestCase(
            id="compliance_002",
            name="BOD5 non-compliant value",
            description="Test BOD5 exceeding limit",
            input_data={
                "parameter": "BOD5",
                "value": 75,
                "standard": "QCVN_40_2011",
                "column": "B"
            },
            expected_output={
                "compliant": False,
                "status": "KHÔNG ĐẠT"
            },
            tags=["compliance", "unit", "edge_case"]
        ),
        TestCase(
            id="compliance_003",
            name="pH within range",
            description="Test pH value in acceptable range",
            input_data={
                "parameter": "pH",
                "value": 7.5,
                "standard": "QCVN_40_2011",
                "column": "B"
            },
            expected_output={
                "compliant": True
            },
            tags=["compliance", "unit", "range_check"]
        ),
        TestCase(
            id="compliance_004",
            name="pH below range",
            description="Test pH value below acceptable range",
            input_data={
                "parameter": "pH",
                "value": 4.5,
                "standard": "QCVN_40_2011",
                "column": "B"
            },
            expected_output={
                "compliant": False
            },
            tags=["compliance", "unit", "range_check", "edge_case"]
        ),
        TestCase(
            id="compliance_005",
            name="Unknown parameter",
            description="Test handling of unknown parameter",
            input_data={
                "parameter": "UNKNOWN_PARAM",
                "value": 100,
                "standard": "QCVN_40_2011",
                "column": "B"
            },
            expected_output={
                "error": True
            },
            tags=["compliance", "unit", "error_handling"]
        ),
    ]
    
    RAG_TEST_CASES = [
        TestCase(
            id="rag_001",
            name="BOD5 limit query",
            description="Query for BOD5 limit in QCVN 40",
            input_data={
                "query": "Giới hạn BOD5 theo QCVN 40:2011 là bao nhiêu?"
            },
            validation_fn=lambda output: (
                "30" in output or "50" in output
            ) and "QCVN" in output,
            tags=["rag", "integration", "retrieval"]
        ),
        TestCase(
            id="rag_002",
            name="Compliance procedure query",
            description="Query about compliance checking procedure",
            input_data={
                "query": "Quy trình kiểm tra tuân thủ môi trường gồm những bước nào?"
            },
            validation_fn=lambda output: len(output) > 100,
            tags=["rag", "integration", "generation"]
        ),
    ]
    
    @classmethod
    def get_compliance_tests(cls) -> List[TestCase]:
        return cls.COMPLIANCE_TEST_CASES
    
    @classmethod
    def get_rag_tests(cls) -> List[TestCase]:
        return cls.RAG_TEST_CASES
    
    @classmethod
    def get_tests_by_tag(cls, tag: str) -> List[TestCase]:
        all_tests = cls.COMPLIANCE_TEST_CASES + cls.RAG_TEST_CASES
        return [t for t in all_tests if tag in t.tags]


# ==================== UNIT TESTS ====================

class TestComplianceChecker:
    """Unit tests for compliance checking."""
    
    @pytest.fixture
    def checker(self):
        """Create compliance checker instance."""
        from src.tools.compliance import ComplianceCheckerTool
        return ComplianceCheckerTool()
    
    def test_bod5_compliant(self, checker):
        """Test BOD5 within limit returns compliant."""
        result = checker.execute(
            parameter="BOD5",
            value=30,
            standard="QCVN_40_2011",
            column="B"
        )
        
        assert result["compliant"] is True
        assert result["status"] == "ĐẠT"
        assert result["exceedance_percent"] == 0
    
    def test_bod5_non_compliant(self, checker):
        """Test BOD5 exceeding limit returns non-compliant."""
        result = checker.execute(
            parameter="BOD5",
            value=75,
            standard="QCVN_40_2011",
            column="B"
        )
        
        assert result["compliant"] is False
        assert result["status"] == "KHÔNG ĐẠT"
        assert result["exceedance_percent"] > 0
    
    def test_ph_within_range(self, checker):
        """Test pH within acceptable range."""
        result = checker.execute(
            parameter="pH",
            value=7.5,
            standard="QCVN_40_2011",
            column="B"
        )
        
        assert result["compliant"] is True
    
    def test_ph_outside_range(self, checker):
        """Test pH outside acceptable range."""
        result = checker.execute(
            parameter="pH",
            value=4.0,
            standard="QCVN_40_2011",
            column="B"
        )
        
        assert result["compliant"] is False
    
    def test_unknown_standard(self, checker):
        """Test handling of unknown standard."""
        result = checker.execute(
            parameter="BOD5",
            value=30,
            standard="UNKNOWN_STANDARD",
            column="B"
        )
        
        assert "error" in result
    
    def test_unknown_parameter(self, checker):
        """Test handling of unknown parameter."""
        result = checker.execute(
            parameter="UNKNOWN",
            value=100,
            standard="QCVN_40_2011",
            column="B"
        )
        
        assert "error" in result
    
    @pytest.mark.parametrize("value,expected", [
        (25, True),   # Well below limit
        (49, True),   # Just below limit
        (50, True),   # At limit
        (51, False),  # Just above limit
        (100, False), # Well above limit
    ])
    def test_bod5_boundary_values(self, checker, value, expected):
        """Test BOD5 boundary values."""
        result = checker.execute(
            parameter="BOD5",
            value=value,
            standard="QCVN_40_2011",
            column="B"
        )
        
        assert result["compliant"] is expected


# ==================== INTEGRATION TESTS ====================

class TestRAGIntegration:
    """Integration tests for RAG system."""
    
    @pytest.fixture
    def rag_system(self):
        """Create RAG system with mocked LLM."""
        from src.rag.advanced_rag import AdvancedRAG
        
        # Mock LLM
        mock_llm = MagicMock()
        mock_llm.complete.return_value = MagicMock(
            content="BOD5 theo QCVN 40:2011 có giới hạn 50 mg/L cho cột B.",
            total_tokens=100
        )
        
        # Create RAG with mock
        rag = AdvancedRAG(
            vector_store=MagicMock(),
            embedding_model=MagicMock(),
            llm_client=mock_llm
        )
        
        return rag
    
    def test_query_returns_response(self, rag_system):
        """Test that query returns a response."""
        # Mock retrieval
        rag_system.vector_store.search.return_value = [
            MagicMock(
                id="doc1",
                content="BOD5 không vượt quá 50 mg/L",
                score=0.9,
                metadata={"doc_number": "QCVN 40:2011"}
            )
        ]
        
        response = rag_system.query("Giới hạn BOD5 là bao nhiêu?")
        
        assert response is not None
        assert "answer" in response
        assert len(response["answer"]) > 0
    
    def test_query_includes_sources(self, rag_system):
        """Test that response includes sources."""
        rag_system.vector_store.search.return_value = [
            MagicMock(
                id="doc1",
                content="BOD5 content",
                score=0.9,
                metadata={"doc_number": "QCVN 40:2011"}
            )
        ]
        
        response = rag_system.query("Giới hạn BOD5?")
        
        assert "sources" in response
        assert len(response["sources"]) > 0
    
    @pytest.mark.asyncio
    async def test_async_query(self, rag_system):
        """Test async query execution."""
        rag_system.vector_store.search.return_value = [
            MagicMock(id="doc1", content="Content", score=0.9, metadata={})
        ]
        
        if hasattr(rag_system, 'aquery'):
            response = await rag_system.aquery("Test query")
            assert response is not None


class TestMultiAgentIntegration:
    """Integration tests for multi-agent system."""
    
    @pytest.fixture
    def agent_system(self):
        """Create multi-agent system with mocks."""
        from src.systems.compliance_graph import EnvironmentalComplianceGraph
        
        # Mock the system
        system = MagicMock(spec=EnvironmentalComplianceGraph)
        
        # Mock run method
        system.run.return_value = {
            "final_report": "Test report",
            "compliance_check": {"overall_compliant": True},
            "risk_assessment": {"risk_level": "LOW"}
        }
        
        return system
    
    def test_workflow_completes(self, agent_system):
        """Test that workflow completes successfully."""
        result = agent_system.run(
            facility_name="Test Facility",
            monitoring_data={
                "parameters": {"BOD5": 30},
                "sampling_date": "2024-01-15",
                "sampling_location": "Test",
                "media_type": "wastewater"
            }
        )
        
        assert result is not None
        assert "final_report" in result
    
    def test_workflow_handles_invalid_data(self, agent_system):
        """Test workflow handles invalid data."""
        agent_system.run.return_value = {
            "errors": ["Missing required field"],
            "final_report": "Error report"
        }
        
        result = agent_system.run(
            facility_name="Test",
            monitoring_data={}
        )
        
        assert "errors" in result or "final_report" in result


# ==================== E2E TESTS ====================

class TestE2ECompliance:
    """End-to-end tests for compliance system."""
    
    @pytest.fixture
    def api_client(self):
        """Create test client for FastAPI."""
        from fastapi.testclient import TestClient
        from src.api.main import app
        
        return TestClient(app)
    
    def test_health_check(self, api_client):
        """Test API health check endpoint."""
        response = api_client.get("/health")
        
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"
    
    def test_compliance_check_endpoint(self, api_client):
        """Test compliance check API endpoint."""
        payload = {
            "parameter": "BOD5",
            "value": 30,
            "standard": "QCVN_40_2011",
            "column": "B"
        }
        
        response = api_client.post("/api/compliance/check", json=payload)
        
        assert response.status_code == 200
        data = response.json()
        assert "compliant" in data
        assert "status" in data
    
    def test_full_workflow_endpoint(self, api_client):
        """Test full compliance workflow endpoint."""
        payload = {
            "facility_name": "Test Facility",
            "monitoring_data": {
                "parameters": {"BOD5": 30, "COD": 100},
                "sampling_date": "2024-01-15",
                "sampling_location": "Test Location",
                "media_type": "wastewater"
            },
            "period": "01/2024"
        }
        
        response = api_client.post("/api/compliance/workflow", json=payload)
        
        assert response.status_code == 200
        data = response.json()
        assert "final_report" in data or "report_url" in data


# ==================== QUALITY TESTS ====================

class TestRAGQuality:
    """Tests for RAG response quality."""
    
    @pytest.fixture
    def evaluator(self):
        """Create RAG evaluator."""
        from src.evaluation.rag_evaluator import RAGEvaluator
        return MagicMock(spec=RAGEvaluator)
    
    def test_faithfulness_above_threshold(self, evaluator):
        """Test that faithfulness score is above threshold."""
        evaluator.evaluate.return_value = MagicMock(
            metrics={"faithfulness": 0.9}
        )
        
        result = evaluator.evaluate(
            query="Test query",
            answer="Test answer",
            contexts=["Test context"]
        )
        
        assert result.metrics["faithfulness"] >= 0.8
    
    def test_answer_relevancy_above_threshold(self, evaluator):
        """Test that answer relevancy is above threshold."""
        evaluator.evaluate.return_value = MagicMock(
            metrics={"answer_relevancy": 0.85}
        )
        
        result = evaluator.evaluate(
            query="Test query",
            answer="Test answer",
            contexts=["Test context"]
        )
        
        assert result.metrics["answer_relevancy"] >= 0.75


# ==================== PERFORMANCE TESTS ====================

class TestPerformance:
    """Performance tests for the system."""
    
    @pytest.fixture
    def system(self):
        """Create system for performance testing."""
        return MagicMock()
    
    def test_query_latency(self, system, benchmark):
        """Test query latency is within acceptable range."""
        system.query.return_value = {"answer": "Test"}
        
        # Use pytest-benchmark
        result = benchmark(system.query, "Test query")
        
        # Assert latency (benchmark provides timing)
        assert result is not None
    
    def test_concurrent_requests(self, system):
        """Test system handles concurrent requests."""
        import concurrent.futures
        
        system.query.return_value = {"answer": "Test"}
        
        def make_request():
            return system.query("Test query")
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(make_request) for _ in range(100)]
            results = [f.result() for f in concurrent.futures.as_completed(futures)]
        
        assert len(results) == 100
        assert all(r is not None for r in results)


# ==================== MOCK LLM FOR TESTING ====================

class MockLLM:
    """
    Mock LLM for testing without API calls.
    """
    
    def __init__(self, responses: Dict[str, str] = None):
        self.responses = responses or {}
        self.calls = []
    
    def complete(self, messages: List[Dict]) -> MagicMock:
        """Mock completion."""
        query = messages[-1].get("content", "") if messages else ""
        self.calls.append(query)
        
        # Find matching response
        response_text = "Mock response"
        for pattern, response in self.responses.items():
            if pattern.lower() in query.lower():
                response_text = response
                break
        
        return MagicMock(
            content=response_text,
            total_tokens=len(response_text.split())
        )


# ==================== TEST RUNNER ====================

class TestRunner:
    """
    Custom test runner for AI system tests.
    """
    
    def __init__(self):
        self.results: List[TestResult] = []
    
    def run_test(
        self,
        test_case: TestCase,
        test_fn: Callable
    ) -> TestResult:
        """Run a single test case."""
        import time
        
        start_time = time.perf_counter()
        
        try:
            actual_output = test_fn(**test_case.input_data)
            
            # Validate output
            if test_case.expected_output:
                passed = self._validate_expected(actual_output, test_case.expected_output)
            elif test_case.validation_fn:
                passed = test_case.validation_fn(actual_output)
            else:
                passed = actual_output is not None
            
            error = None
            
        except Exception as e:
            actual_output = None
            passed = False
            error = str(e)
        
        latency = (time.perf_counter() - start_time) * 1000
        
        result = TestResult(
            test_case=test_case,
            passed=passed,
            actual_output=actual_output,
            error=error,
            latency_ms=latency
        )
        
        self.results.append(result)
        return result
    
    def _validate_expected(self, actual: Dict, expected: Dict) -> bool:
        """Validate actual output against expected."""
        for key, value in expected.items():
            if key not in actual:
                return False
            if actual[key] != value:
                return False
        return True
    
    def run_suite(
        self,
        test_cases: List[TestCase],
        test_fn: Callable
    ) -> Dict:
        """Run a suite of test cases."""
        for tc in test_cases:
            self.run_test(tc, test_fn)
        
        return self.get_summary()
    
    def get_summary(self) -> Dict:
        """Get test run summary."""
        total = len(self.results)
        passed = sum(1 for r in self.results if r.passed)
        failed = total - passed
        
        avg_latency = np.mean([r.latency_ms for r in self.results]) if self.results else 0
        
        return {
            "total_tests": total,
            "passed": passed,
            "failed": failed,
            "pass_rate": passed / total if total > 0 else 0,
            "avg_latency_ms": avg_latency,
            "failed_tests": [
                {
                    "id": r.test_case.id,
                    "name": r.test_case.name,
                    "error": r.error
                }
                for r in self.results if not r.passed
            ]
        }
```

### Ngày 3-4: CI/CD Pipeline

#### 2.1 GitHub Actions Configuration

```yaml
# ============================================
# .github/workflows/ci.yml
# ============================================

name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

env:
  PYTHON_VERSION: "3.11"
  POETRY_VERSION: "1.7.0"

jobs:
  # ==================== LINT & FORMAT ====================
  lint:
    name: Lint and Format Check
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: ${{ env.PYTHON_VERSION }}
      
      - name: Install dependencies
        run: |
          pip install ruff black isort mypy
      
      - name: Run Ruff (linter)
        run: ruff check .
      
      - name: Run Black (formatter)
        run: black --check .
      
      - name: Run isort (import sorter)
        run: isort --check-only .
      
      - name: Run MyPy (type checker)
        run: mypy src/
        continue-on-error: true

  # ==================== UNIT TESTS ====================
  test-unit:
    name: Unit Tests
    runs-on: ubuntu-latest
    needs: lint
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: ${{ env.PYTHON_VERSION }}
      
      - name: Install Poetry
        run: |
          curl -sSL https://install.python-poetry.org | python3 -
          echo "$HOME/.local/bin" >> $GITHUB_PATH
      
      - name: Cache Poetry dependencies
        uses: actions/cache@v4
        with:
          path: ~/.cache/pypoetry
          key: ${{ runner.os }}-poetry-${{ hashFiles('**/poetry.lock') }}
      
      - name: Install dependencies
        run: poetry install --no-root
      
      - name: Run unit tests
        run: |
          poetry run pytest tests/unit \
            --cov=src \
            --cov-report=xml \
            --cov-report=html \
            -v
      
      - name: Upload coverage report
        uses: codecov/codecov-action@v4
        with:
          files: ./coverage.xml
          fail_ci_if_error: true

  # ==================== INTEGRATION TESTS ====================
  test-integration:
    name: Integration Tests
    runs-on: ubuntu-latest
    needs: test-unit
    
    services:
      redis:
        image: redis:7
        ports:
          - 6379:6379
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: ${{ env.PYTHON_VERSION }}
      
      - name: Install Poetry
        run: |
          curl -sSL https://install.python-poetry.org | python3 -
          echo "$HOME/.local/bin" >> $GITHUB_PATH
      
      - name: Install dependencies
        run: poetry install --no-root
      
      - name: Run integration tests
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
          REDIS_URL: redis://localhost:6379
        run: |
          poetry run pytest tests/integration \
            -v \
            --timeout=60
        continue-on-error: true

  # ==================== BUILD ====================
  build:
    name: Build Docker Image
    runs-on: ubuntu-latest
    needs: [test-unit, test-integration]
    if: github.event_name == 'push'
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3
      
      - name: Login to Container Registry
        uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}
      
      - name: Build and push
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: |
            ghcr.io/${{ github.repository }}:${{ github.sha }}
            ghcr.io/${{ github.repository }}:latest
          cache-from: type=gha
          cache-to: type=gha,mode=max

  # ==================== DEPLOY ====================
  deploy-staging:
    name: Deploy to Staging
    runs-on: ubuntu-latest
    needs: build
    if: github.ref == 'refs/heads/develop'
    environment: staging
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Deploy to Staging
        run: |
          echo "Deploying to staging..."
          # Add deployment script here
  
  deploy-production:
    name: Deploy to Production
    runs-on: ubuntu-latest
    needs: build
    if: github.ref == 'refs/heads/main'
    environment: production
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Deploy to Production
        run: |
          echo "Deploying to production..."
          # Add deployment script here
```

### Ngày 5-6: Docker và Deployment

#### 3.1 Docker Configuration

```dockerfile
# ============================================
# Dockerfile
# ============================================

# Build stage
FROM python:3.11-slim as builder

WORKDIR /app

# Install build dependencies
RUN apt-get update && apt-get install -y \
    build-essential \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Install Poetry
RUN curl -sSL https://install.python-poetry.org | python3 -
ENV PATH="/root/.local/bin:$PATH"

# Copy dependency files
COPY pyproject.toml poetry.lock ./

# Install dependencies
RUN poetry config virtualenvs.create false \
    && poetry install --no-dev --no-root

# Production stage
FROM python:3.11-slim as production

WORKDIR /app

# Install runtime dependencies
RUN apt-get update && apt-get install -y \
    libpq5 \
    && rm -rf /var/lib/apt/lists/*

# Copy Python packages from builder
COPY --from=builder /usr/local/lib/python3.11/site-packages /usr/local/lib/python3.11/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin

# Copy application code
COPY src/ ./src/
COPY templates/ ./templates/
COPY config/ ./config/

# Create non-root user
RUN useradd -m -u 1000 appuser
USER appuser

# Environment variables
ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# Expose port
EXPOSE 8000

# Run application
CMD ["uvicorn", "src.api.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

```yaml
# ============================================
# docker-compose.yml
# ============================================

version: "3.9"

services:
  # Main application
  app:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "8000:8000"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - REDIS_URL=redis://redis:6379
      - CHROMA_HOST=chromadb
      - CHROMA_PORT=8001
      - LOG_LEVEL=INFO
    depends_on:
      - redis
      - chromadb
    volumes:
      - ./data:/app/data
      - ./output:/app/output
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Redis for caching
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    command: redis-server --appendonly yes
    restart: unless-stopped

  # ChromaDB for vector storage
  chromadb:
    image: chromadb/chroma:latest
    ports:
      - "8001:8000"
    volumes:
      - chroma_data:/chroma/chroma
    environment:
      - ANONYMIZED_TELEMETRY=False
    restart: unless-stopped

  # Monitoring - Prometheus
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./config/prometheus.yml:/etc/prometheus/prometheus.yml
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
    restart: unless-stopped

  # Monitoring - Grafana
  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    volumes:
      - grafana_data:/var/lib/grafana
      - ./config/grafana/dashboards:/etc/grafana/provisioning/dashboards
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    depends_on:
      - prometheus
    restart: unless-stopped

volumes:
  redis_data:
  chroma_data:
  prometheus_data:
  grafana_data:
```

#### 3.2 Kubernetes Deployment

```yaml
# ============================================
# k8s/deployment.yaml
# ============================================

apiVersion: apps/v1
kind: Deployment
metadata:
  name: environmental-compliance-api
  labels:
    app: compliance-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: compliance-api
  template:
    metadata:
      labels:
        app: compliance-api
    spec:
      containers:
        - name: api
          image: ghcr.io/your-org/compliance-api:latest
          ports:
            - containerPort: 8000
          env:
            - name: OPENAI_API_KEY
              valueFrom:
                secretKeyRef:
                  name: api-secrets
                  key: openai-api-key
            - name: REDIS_URL
              value: "redis://redis-service:6379"
          resources:
            requests:
              memory: "512Mi"
              cpu: "250m"
            limits:
              memory: "1Gi"
              cpu: "500m"
          livenessProbe:
            httpGet:
              path: /health
              port: 8000
            initialDelaySeconds: 10
            periodSeconds: 30
          readinessProbe:
            httpGet:
              path: /health
              port: 8000
            initialDelaySeconds: 5
            periodSeconds: 10
---
apiVersion: v1
kind: Service
metadata:
  name: compliance-api-service
spec:
  selector:
    app: compliance-api
  ports:
    - port: 80
      targetPort: 8000
  type: LoadBalancer
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: compliance-api-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: environmental-compliance-api
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Test Suite (Ngày 1-2)

```
🎯 Mục tiêu: Build comprehensive test suite

📋 Yêu cầu:
1. Unit tests cho compliance checker
2. Integration tests cho RAG
3. E2E tests cho API
4. Quality tests cho responses

📁 Deliverables:
- tests/unit/test_compliance.py
- tests/integration/test_rag.py
- tests/e2e/test_api.py
- pytest.ini với configuration
```

### Bài tập 2: CI/CD Pipeline (Ngày 3-4)

```
🎯 Mục tiêu: Setup CI/CD với GitHub Actions

📋 Yêu cầu:
1. Lint và format checks
2. Test execution
3. Docker build
4. Deployment stages

📁 Deliverables:
- .github/workflows/ci.yml
- .github/workflows/deploy.yml
- Coverage reports
```

### Bài tập 3: Docker Deployment (Ngày 5-7)

```
🎯 Mục tiêu: Containerize và deploy

📋 Yêu cầu:
1. Multi-stage Dockerfile
2. Docker Compose setup
3. Kubernetes manifests
4. Monitoring setup

📁 Deliverables:
- Dockerfile
- docker-compose.yml
- k8s/ directory
- **PROJECT 3 Continued**: Deployed system
```

---

## ✅ CHECKLIST TUẦN 11

### Kiến thức đã học
- [ ] Testing strategies cho AI
- [ ] CI/CD pipeline design
- [ ] Docker containerization
- [ ] Kubernetes basics
- [ ] Production monitoring

### Skills thực hành
- [ ] Write comprehensive tests
- [ ] Setup GitHub Actions
- [ ] Build Docker images
- [ ] Deploy với Docker Compose
- [ ] Configure monitoring

### Deliverables
- [ ] Complete test suite
- [ ] CI/CD pipeline
- [ ] Docker deployment
- [ ] Monitoring dashboard

---

*Hoàn thành Tuần 11 để tiếp tục sang Tuần 12: Capstone Project*
