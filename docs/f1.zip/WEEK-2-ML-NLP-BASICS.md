# 📅 TUẦN 2: MACHINE LEARNING FUNDAMENTALS & NLP BASICS

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Nắm vững ML workflow và NLP pipeline cho Vietnamese text |
| **Output** | Document classifier cho văn bản quy định môi trường |
| **Độ khó** | ⭐⭐⭐ Trung bình - Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu ML workflow: data → features → model → evaluate → deploy
- [ ] Nắm vững các thuật toán ML supervised và unsupervised
- [ ] Hiểu NLP pipeline: tokenization → preprocessing → vectorization
- [ ] Biết các kỹ thuật text classification và named entity recognition

### Kỹ năng (Skills)
- [ ] Sử dụng scikit-learn cho ML tasks
- [ ] Xử lý Vietnamese text với underthesea/pyvi
- [ ] Build text classification models
- [ ] Evaluate models với proper metrics

### Ứng dụng (Application)
- [ ] Phân loại văn bản quy định môi trường
- [ ] Trích xuất entities từ văn bản pháp luật
- [ ] Dự đoán mức độ ô nhiễm từ dữ liệu quan trắc

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: Machine Learning Fundamentals

#### 1.1 ML Workflow Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         MACHINE LEARNING WORKFLOW                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│  │   Problem    │───▶│    Data      │───▶│   Feature    │                  │
│  │  Definition  │    │  Collection  │    │ Engineering  │                  │
│  └──────────────┘    └──────────────┘    └──────────────┘                  │
│         │                   │                   │                           │
│         ▼                   ▼                   ▼                           │
│  • Define objective    • Gather data      • Select features                │
│  • Choose metrics      • Data cleaning    • Transform features              │
│  • Identify features   • EDA              • Create new features             │
│                                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│  │    Model     │───▶│    Model     │───▶│   Model      │                  │
│  │   Training   │    │  Evaluation  │    │  Deployment  │                  │
│  └──────────────┘    └──────────────┘    └──────────────┘                  │
│         │                   │                   │                           │
│         ▼                   ▼                   ▼                           │
│  • Split data         • Cross-validation  • API/Service                    │
│  • Train models       • Metrics analysis  • Monitoring                      │
│  • Hyperparameter     • Error analysis    • Retraining                      │
│    tuning                                                                   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 Supervised Learning Algorithms

```python
# ============================================
# SUPERVISED LEARNING FOR ENVIRONMENTAL DATA
# ============================================

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report,
    mean_squared_error, mean_absolute_error, r2_score
)
from sklearn.pipeline import Pipeline
from typing import Dict, List, Tuple, Any
import joblib

class EnvironmentalMLPipeline:
    """
    ML Pipeline for environmental data analysis.
    Supports both classification and regression tasks.
    """
    
    def __init__(self, task_type: str = "classification"):
        """
        Initialize pipeline.
        
        Args:
            task_type: "classification" or "regression"
        """
        self.task_type = task_type
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.feature_names = None
        self.best_params = None
    
    # ==================== CLASSIFICATION MODELS ====================
    
    def get_classification_models(self) -> Dict[str, Any]:
        """Get dictionary of classification models to try."""
        from sklearn.linear_model import LogisticRegression
        from sklearn.tree import DecisionTreeClassifier
        from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
        from sklearn.svm import SVC
        from sklearn.naive_bayes import MultinomialNB, GaussianNB
        from sklearn.neighbors import KNeighborsClassifier
        
        return {
            "logistic_regression": {
                "model": LogisticRegression(max_iter=1000, random_state=42),
                "params": {
                    "C": [0.1, 1, 10],
                    "penalty": ["l1", "l2"],
                    "solver": ["liblinear"]
                }
            },
            "decision_tree": {
                "model": DecisionTreeClassifier(random_state=42),
                "params": {
                    "max_depth": [3, 5, 10, None],
                    "min_samples_split": [2, 5, 10],
                    "min_samples_leaf": [1, 2, 4]
                }
            },
            "random_forest": {
                "model": RandomForestClassifier(random_state=42),
                "params": {
                    "n_estimators": [50, 100, 200],
                    "max_depth": [5, 10, None],
                    "min_samples_split": [2, 5],
                    "min_samples_leaf": [1, 2]
                }
            },
            "gradient_boosting": {
                "model": GradientBoostingClassifier(random_state=42),
                "params": {
                    "n_estimators": [50, 100],
                    "learning_rate": [0.01, 0.1],
                    "max_depth": [3, 5]
                }
            },
            "svm": {
                "model": SVC(random_state=42, probability=True),
                "params": {
                    "C": [0.1, 1, 10],
                    "kernel": ["rbf", "linear"],
                    "gamma": ["scale", "auto"]
                }
            },
            "knn": {
                "model": KNeighborsClassifier(),
                "params": {
                    "n_neighbors": [3, 5, 7, 9],
                    "weights": ["uniform", "distance"],
                    "metric": ["euclidean", "manhattan"]
                }
            }
        }
    
    # ==================== REGRESSION MODELS ====================
    
    def get_regression_models(self) -> Dict[str, Any]:
        """Get dictionary of regression models to try."""
        from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
        from sklearn.tree import DecisionTreeRegressor
        from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
        from sklearn.svm import SVR
        
        return {
            "linear_regression": {
                "model": LinearRegression(),
                "params": {}
            },
            "ridge": {
                "model": Ridge(random_state=42),
                "params": {
                    "alpha": [0.1, 1, 10, 100]
                }
            },
            "lasso": {
                "model": Lasso(random_state=42),
                "params": {
                    "alpha": [0.1, 1, 10]
                }
            },
            "elastic_net": {
                "model": ElasticNet(random_state=42),
                "params": {
                    "alpha": [0.1, 1],
                    "l1_ratio": [0.25, 0.5, 0.75]
                }
            },
            "random_forest": {
                "model": RandomForestRegressor(random_state=42),
                "params": {
                    "n_estimators": [50, 100],
                    "max_depth": [5, 10, None],
                    "min_samples_split": [2, 5]
                }
            },
            "gradient_boosting": {
                "model": GradientBoostingRegressor(random_state=42),
                "params": {
                    "n_estimators": [50, 100],
                    "learning_rate": [0.01, 0.1],
                    "max_depth": [3, 5]
                }
            }
        }
    
    # ==================== TRAINING ====================
    
    def prepare_data(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        test_size: float = 0.2,
        scale_features: bool = True
    ) -> Tuple:
        """
        Prepare data for training.
        
        Args:
            X: Feature dataframe
            y: Target series
            test_size: Proportion for test set
            scale_features: Whether to scale features
        
        Returns:
            X_train, X_test, y_train, y_test
        """
        self.feature_names = X.columns.tolist()
        
        # Encode labels for classification
        if self.task_type == "classification" and y.dtype == 'object':
            y = self.label_encoder.fit_transform(y)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y if self.task_type == "classification" else None
        )
        
        # Scale features
        if scale_features:
            X_train = self.scaler.fit_transform(X_train)
            X_test = self.scaler.transform(X_test)
        
        return X_train, X_test, y_train, y_test
    
    def train_single_model(
        self,
        model_name: str,
        X_train: np.ndarray,
        y_train: np.ndarray,
        cv: int = 5
    ) -> Dict:
        """Train a single model with cross-validation."""
        
        models = (
            self.get_classification_models() if self.task_type == "classification"
            else self.get_regression_models()
        )
        
        if model_name not in models:
            raise ValueError(f"Unknown model: {model_name}")
        
        model_config = models[model_name]
        model = model_config["model"]
        params = model_config["params"]
        
        # Grid search if params available
        if params:
            scoring = "f1_weighted" if self.task_type == "classification" else "neg_mean_squared_error"
            
            grid_search = GridSearchCV(
                model, params, cv=cv, scoring=scoring, n_jobs=-1
            )
            grid_search.fit(X_train, y_train)
            
            best_model = grid_search.best_estimator_
            best_params = grid_search.best_params_
            cv_score = grid_search.best_score_
        else:
            best_model = model
            best_model.fit(X_train, y_train)
            best_params = {}
            cv_scores = cross_val_score(model, X_train, y_train, cv=cv)
            cv_score = cv_scores.mean()
        
        return {
            "model": best_model,
            "best_params": best_params,
            "cv_score": cv_score
        }
    
    def compare_models(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_test: np.ndarray,
        y_test: np.ndarray,
        models_to_try: List[str] = None
    ) -> pd.DataFrame:
        """
        Compare multiple models and return results.
        
        Args:
            X_train, y_train: Training data
            X_test, y_test: Test data
            models_to_try: List of model names (None = try all)
        
        Returns:
            DataFrame with model comparison results
        """
        all_models = (
            self.get_classification_models() if self.task_type == "classification"
            else self.get_regression_models()
        )
        
        if models_to_try is None:
            models_to_try = list(all_models.keys())
        
        results = []
        
        for model_name in models_to_try:
            print(f"Training {model_name}...")
            
            try:
                result = self.train_single_model(model_name, X_train, y_train)
                
                model = result["model"]
                y_pred = model.predict(X_test)
                
                if self.task_type == "classification":
                    metrics = {
                        "model": model_name,
                        "cv_score": result["cv_score"],
                        "accuracy": accuracy_score(y_test, y_pred),
                        "precision": precision_score(y_test, y_pred, average='weighted'),
                        "recall": recall_score(y_test, y_pred, average='weighted'),
                        "f1": f1_score(y_test, y_pred, average='weighted'),
                        "best_params": str(result["best_params"])
                    }
                else:
                    metrics = {
                        "model": model_name,
                        "cv_score": -result["cv_score"],  # Negative MSE
                        "mse": mean_squared_error(y_test, y_pred),
                        "rmse": np.sqrt(mean_squared_error(y_test, y_pred)),
                        "mae": mean_absolute_error(y_test, y_pred),
                        "r2": r2_score(y_test, y_pred),
                        "best_params": str(result["best_params"])
                    }
                
                results.append(metrics)
                
            except Exception as e:
                print(f"Error training {model_name}: {e}")
        
        results_df = pd.DataFrame(results)
        
        # Sort by best metric
        sort_col = "f1" if self.task_type == "classification" else "r2"
        results_df = results_df.sort_values(sort_col, ascending=False)
        
        return results_df
    
    # ==================== EVALUATION ====================
    
    def evaluate_classification(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        class_names: List[str] = None
    ) -> Dict:
        """
        Comprehensive classification evaluation.
        
        Returns metrics and confusion matrix.
        """
        if class_names is None:
            class_names = [str(c) for c in np.unique(y_true)]
        
        return {
            "accuracy": accuracy_score(y_true, y_pred),
            "precision": precision_score(y_true, y_pred, average='weighted'),
            "recall": recall_score(y_true, y_pred, average='weighted'),
            "f1": f1_score(y_true, y_pred, average='weighted'),
            "confusion_matrix": confusion_matrix(y_true, y_pred),
            "classification_report": classification_report(
                y_true, y_pred, target_names=class_names, output_dict=True
            )
        }
    
    def get_feature_importance(self) -> pd.DataFrame:
        """Get feature importance if model supports it."""
        
        if self.model is None:
            raise ValueError("No model trained yet")
        
        if hasattr(self.model, 'feature_importances_'):
            importances = self.model.feature_importances_
        elif hasattr(self.model, 'coef_'):
            importances = np.abs(self.model.coef_).mean(axis=0) if self.model.coef_.ndim > 1 else np.abs(self.model.coef_)
        else:
            return None
        
        return pd.DataFrame({
            'feature': self.feature_names,
            'importance': importances
        }).sort_values('importance', ascending=False)
    
    # ==================== SAVE/LOAD ====================
    
    def save_model(self, path: str):
        """Save trained model and preprocessing objects."""
        model_data = {
            'model': self.model,
            'scaler': self.scaler,
            'label_encoder': self.label_encoder,
            'feature_names': self.feature_names,
            'task_type': self.task_type
        }
        joblib.dump(model_data, path)
    
    @classmethod
    def load_model(cls, path: str) -> 'EnvironmentalMLPipeline':
        """Load saved model."""
        model_data = joblib.load(path)
        
        pipeline = cls(task_type=model_data['task_type'])
        pipeline.model = model_data['model']
        pipeline.scaler = model_data['scaler']
        pipeline.label_encoder = model_data['label_encoder']
        pipeline.feature_names = model_data['feature_names']
        
        return pipeline


# ============================================
# EXAMPLE: Pollution Level Classification
# ============================================

class PollutionLevelClassifier(EnvironmentalMLPipeline):
    """
    Classify pollution levels based on environmental parameters.
    
    Classes:
    - Tốt (Good): AQI 0-50
    - Trung bình (Moderate): AQI 51-100
    - Kém (Unhealthy for sensitive): AQI 101-150
    - Xấu (Unhealthy): AQI 151-200
    - Rất xấu (Very unhealthy): AQI > 200
    """
    
    POLLUTION_LEVELS = ['Tốt', 'Trung bình', 'Kém', 'Xấu', 'Rất xấu']
    
    def __init__(self):
        super().__init__(task_type="classification")
    
    @staticmethod
    def assign_pollution_level(aqi: float) -> str:
        """Assign pollution level based on AQI value."""
        if aqi <= 50:
            return 'Tốt'
        elif aqi <= 100:
            return 'Trung bình'
        elif aqi <= 150:
            return 'Kém'
        elif aqi <= 200:
            return 'Xấu'
        else:
            return 'Rất xấu'
    
    def create_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create features for pollution prediction.
        
        Expected columns: PM2.5, PM10, NO2, SO2, CO, O3, temperature, humidity, wind_speed
        """
        features = pd.DataFrame()
        
        # Raw pollutant values
        pollutants = ['PM2.5', 'PM10', 'NO2', 'SO2', 'CO', 'O3']
        for p in pollutants:
            if p in df.columns:
                features[p] = df[p]
        
        # Meteorological features
        meteo = ['temperature', 'humidity', 'wind_speed']
        for m in meteo:
            if m in df.columns:
                features[m] = df[m]
        
        # Derived features
        if 'PM2.5' in df.columns and 'PM10' in df.columns:
            features['PM_ratio'] = df['PM2.5'] / (df['PM10'] + 0.001)
        
        if 'NO2' in df.columns and 'SO2' in df.columns:
            features['NOx_SOx_ratio'] = df['NO2'] / (df['SO2'] + 0.001)
        
        # Time features (if datetime available)
        if 'datetime' in df.columns:
            dt = pd.to_datetime(df['datetime'])
            features['hour'] = dt.dt.hour
            features['day_of_week'] = dt.dt.dayofweek
            features['month'] = dt.dt.month
            features['is_weekend'] = dt.dt.dayofweek.isin([5, 6]).astype(int)
        
        return features
    
    def train(
        self,
        df: pd.DataFrame,
        target_column: str = 'AQI',
        model_name: str = 'random_forest'
    ) -> Dict:
        """
        Train pollution level classifier.
        
        Args:
            df: DataFrame with environmental data
            target_column: Column containing AQI values
            model_name: Model to train
        
        Returns:
            Training results dictionary
        """
        # Create features
        X = self.create_features(df)
        
        # Create target labels
        y = df[target_column].apply(self.assign_pollution_level)
        
        # Prepare data
        X_train, X_test, y_train, y_test = self.prepare_data(X, y)
        
        # Train model
        result = self.train_single_model(model_name, X_train, y_train)
        self.model = result['model']
        self.best_params = result['best_params']
        
        # Evaluate
        y_pred = self.model.predict(X_test)
        y_pred_labels = self.label_encoder.inverse_transform(y_pred)
        y_test_labels = self.label_encoder.inverse_transform(y_test)
        
        evaluation = self.evaluate_classification(
            y_test, y_pred, class_names=self.POLLUTION_LEVELS
        )
        
        return {
            'model_name': model_name,
            'best_params': self.best_params,
            'evaluation': evaluation,
            'feature_importance': self.get_feature_importance()
        }
    
    def predict(self, df: pd.DataFrame) -> pd.Series:
        """Predict pollution levels for new data."""
        X = self.create_features(df)
        X_scaled = self.scaler.transform(X)
        
        y_pred = self.model.predict(X_scaled)
        return pd.Series(self.label_encoder.inverse_transform(y_pred))


# Usage Example
if __name__ == "__main__":
    # Generate sample data
    np.random.seed(42)
    n_samples = 1000
    
    data = pd.DataFrame({
        'PM2.5': np.random.lognormal(3, 0.5, n_samples),
        'PM10': np.random.lognormal(3.5, 0.5, n_samples),
        'NO2': np.random.lognormal(2, 0.5, n_samples),
        'SO2': np.random.lognormal(1.5, 0.5, n_samples),
        'CO': np.random.lognormal(0, 0.5, n_samples),
        'O3': np.random.lognormal(2.5, 0.5, n_samples),
        'temperature': np.random.normal(28, 5, n_samples),
        'humidity': np.random.normal(70, 15, n_samples),
        'wind_speed': np.random.lognormal(1, 0.5, n_samples)
    })
    
    # Simple AQI approximation (based on PM2.5)
    data['AQI'] = data['PM2.5'] * 2
    
    # Train classifier
    classifier = PollutionLevelClassifier()
    results = classifier.train(data, target_column='AQI')
    
    print("Training Results:")
    print(f"Accuracy: {results['evaluation']['accuracy']:.4f}")
    print(f"F1 Score: {results['evaluation']['f1']:.4f}")
    print("\nFeature Importance:")
    print(results['feature_importance'].head(10))
```

### Ngày 3-4: NLP Fundamentals cho Vietnamese Text

#### 2.1 Vietnamese NLP Pipeline

```python
# ============================================
# VIETNAMESE NLP PIPELINE
# ============================================

import re
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import unicodedata

# Vietnamese NLP libraries
# pip install underthesea pyvi

class VietnameseNLPPipeline:
    """
    NLP Pipeline for Vietnamese environmental regulatory text.
    """
    
    # Vietnamese stopwords (common words to remove)
    STOPWORDS = {
        'và', 'của', 'có', 'là', 'được', 'cho', 'trong', 'này', 'với',
        'các', 'để', 'theo', 'từ', 'đến', 'về', 'như', 'hoặc', 'hay',
        'không', 'phải', 'những', 'một', 'sẽ', 'đã', 'đang', 'làm',
        'tại', 'bởi', 'qua', 'trên', 'dưới', 'sau', 'trước', 'nếu',
        'khi', 'mà', 'vì', 'do', 'bị', 'ra', 'vào', 'lên', 'xuống',
        'thì', 'cũng', 'còn', 'rất', 'nhiều', 'ít', 'nhất', 'hơn'
    }
    
    # Environmental domain keywords
    ENV_KEYWORDS = {
        'ô nhiễm', 'môi trường', 'khí thải', 'nước thải', 'chất thải',
        'quan trắc', 'đánh giá', 'tác động', 'bảo vệ', 'xử lý',
        'tiêu chuẩn', 'quy chuẩn', 'giới hạn', 'nồng độ', 'hàm lượng',
        'xả thải', 'phát thải', 'nguồn thải', 'điểm xả', 'ống khói',
        'giấy phép', 'cấp phép', 'đăng ký', 'báo cáo', 'giám sát',
        'PM2.5', 'PM10', 'BOD', 'COD', 'TSS', 'pH', 'DO', 'coliform'
    }
    
    # Legal document patterns
    LEGAL_PATTERNS = {
        'luat': r'Luật\s+(?:số\s+)?\d+/\d{4}/QH\d+',
        'nghi_dinh': r'Nghị\s+định\s+(?:số\s+)?\d+/\d{4}/NĐ-CP',
        'thong_tu': r'Thông\s+tư\s+(?:số\s+)?\d+/\d{4}/TT-[A-Z]+',
        'qcvn': r'QCVN\s+\d+(?::\d{4})?(?:/BTNMT)?',
        'tcvn': r'TCVN\s+\d+(?::\d{4})?',
        'dieu': r'Điều\s+\d+',
        'khoan': r'[Kk]hoản\s+\d+',
        'diem': r'[Đđ]iểm\s+[a-z]'
    }
    
    def __init__(self, use_underthesea: bool = True):
        """
        Initialize Vietnamese NLP pipeline.
        
        Args:
            use_underthesea: Use underthesea for word segmentation
        """
        self.use_underthesea = use_underthesea
        
        if use_underthesea:
            try:
                from underthesea import word_tokenize, pos_tag, ner
                self._word_tokenize = word_tokenize
                self._pos_tag = pos_tag
                self._ner = ner
            except ImportError:
                print("underthesea not installed. Falling back to basic tokenization.")
                self.use_underthesea = False
    
    # ==================== TEXT CLEANING ====================
    
    def normalize_unicode(self, text: str) -> str:
        """Normalize Vietnamese Unicode text."""
        # Normalize to NFC form
        text = unicodedata.normalize('NFC', text)
        return text
    
    def clean_text(self, text: str, keep_punctuation: bool = False) -> str:
        """
        Clean and normalize Vietnamese text.
        
        Args:
            text: Input text
            keep_punctuation: Whether to keep punctuation marks
        
        Returns:
            Cleaned text
        """
        # Normalize unicode
        text = self.normalize_unicode(text)
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters but keep Vietnamese diacritics
        if not keep_punctuation:
            # Keep letters, numbers, Vietnamese characters, and spaces
            text = re.sub(r'[^\w\sàáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ]', '', text)
        
        # Remove extra whitespace again
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def remove_stopwords(self, tokens: List[str]) -> List[str]:
        """Remove Vietnamese stopwords from token list."""
        return [t for t in tokens if t.lower() not in self.STOPWORDS]
    
    # ==================== TOKENIZATION ====================
    
    def tokenize(self, text: str) -> List[str]:
        """
        Tokenize Vietnamese text.
        
        Uses underthesea for word segmentation if available,
        otherwise falls back to simple whitespace tokenization.
        """
        if self.use_underthesea:
            # underthesea handles compound words like "môi trường" as single token
            return self._word_tokenize(text).split()
        else:
            return text.split()
    
    def sentence_tokenize(self, text: str) -> List[str]:
        """Split text into sentences."""
        if self.use_underthesea:
            from underthesea import sent_tokenize
            return sent_tokenize(text)
        else:
            # Simple regex-based sentence splitting
            sentences = re.split(r'[.!?]\s+', text)
            return [s.strip() for s in sentences if s.strip()]
    
    # ==================== POS TAGGING ====================
    
    def pos_tag(self, text: str) -> List[Tuple[str, str]]:
        """
        Part-of-speech tagging for Vietnamese text.
        
        Returns list of (word, POS) tuples.
        
        Common POS tags:
        - N: Noun
        - V: Verb
        - A: Adjective
        - P: Pronoun
        - M: Number
        - R: Adverb
        - E: Preposition
        - C: Conjunction
        - CH: Punctuation
        """
        if self.use_underthesea:
            return self._pos_tag(text)
        else:
            # Fallback: return tokens with 'UNK' tag
            tokens = self.tokenize(text)
            return [(t, 'UNK') for t in tokens]
    
    def extract_nouns(self, text: str) -> List[str]:
        """Extract nouns from text."""
        pos_tags = self.pos_tag(text)
        return [word for word, tag in pos_tags if tag.startswith('N')]
    
    def extract_verbs(self, text: str) -> List[str]:
        """Extract verbs from text."""
        pos_tags = self.pos_tag(text)
        return [word for word, tag in pos_tags if tag.startswith('V')]
    
    # ==================== NAMED ENTITY RECOGNITION ====================
    
    def extract_entities(self, text: str) -> Dict[str, List[str]]:
        """
        Extract named entities from Vietnamese text.
        
        Returns dict with entity types as keys.
        """
        entities = {
            'regulations': [],
            'organizations': [],
            'locations': [],
            'parameters': [],
            'dates': [],
            'numbers': []
        }
        
        # Extract legal document references
        for pattern_name, pattern in self.LEGAL_PATTERNS.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            entities['regulations'].extend(matches)
        
        # Extract environmental parameters
        param_pattern = r'\b(PM2\.5|PM10|BOD5?|COD|TSS|DO|pH|SO2|NO2|CO|O3|NH3|H2S)\b'
        entities['parameters'] = list(set(re.findall(param_pattern, text, re.IGNORECASE)))
        
        # Extract numbers with units
        number_pattern = r'(\d+(?:,\d+)?(?:\.\d+)?)\s*(mg/[Ll]|μg/m³|%|°C|m³|tấn|kg)'
        matches = re.findall(number_pattern, text)
        entities['numbers'] = [f"{m[0]} {m[1]}" for m in matches]
        
        # Extract dates
        date_pattern = r'\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2}'
        entities['dates'] = re.findall(date_pattern, text)
        
        # Use underthesea NER if available
        if self.use_underthesea:
            try:
                ner_results = self._ner(text)
                for entity, tag in ner_results:
                    if tag == 'B-ORG' or tag == 'I-ORG':
                        entities['organizations'].append(entity)
                    elif tag == 'B-LOC' or tag == 'I-LOC':
                        entities['locations'].append(entity)
            except:
                pass
        
        # Remove duplicates
        for key in entities:
            entities[key] = list(set(entities[key]))
        
        return entities
    
    # ==================== DOMAIN-SPECIFIC PROCESSING ====================
    
    def extract_qcvn_references(self, text: str) -> List[Dict]:
        """
        Extract QCVN (Vietnamese Technical Regulation) references.
        
        Returns list of dicts with QCVN details.
        """
        qcvn_pattern = r'QCVN\s+(\d+)(?::(\d{4}))?(?:/([A-Z]+))?'
        matches = re.findall(qcvn_pattern, text, re.IGNORECASE)
        
        qcvn_refs = []
        for match in matches:
            qcvn_refs.append({
                'code': f"QCVN {match[0]}",
                'year': match[1] if match[1] else None,
                'ministry': match[2] if match[2] else 'BTNMT',
                'full_code': f"QCVN {match[0]}:{match[1]}/{match[2]}" if match[1] and match[2] else f"QCVN {match[0]}"
            })
        
        return qcvn_refs
    
    def extract_article_references(self, text: str) -> List[Dict]:
        """
        Extract article/clause references from legal text.
        
        Vietnamese legal structure: Điều (Article) > Khoản (Clause) > Điểm (Point)
        """
        references = []
        
        # Pattern for full reference: Điều X khoản Y điểm z
        full_pattern = r'Điều\s+(\d+)(?:\s+khoản\s+(\d+))?(?:\s+điểm\s+([a-z]))?'
        matches = re.findall(full_pattern, text, re.IGNORECASE)
        
        for match in matches:
            ref = {
                'dieu': int(match[0]),
                'khoan': int(match[1]) if match[1] else None,
                'diem': match[2] if match[2] else None
            }
            references.append(ref)
        
        return references
    
    def categorize_environmental_text(self, text: str) -> Dict[str, float]:
        """
        Categorize text into environmental domain categories.
        
        Returns category scores based on keyword matching.
        """
        categories = {
            'air_quality': ['không khí', 'khí thải', 'PM2.5', 'PM10', 'ô nhiễm không khí', 'ống khói', 'bụi'],
            'water_quality': ['nước thải', 'nước mặt', 'nước ngầm', 'BOD', 'COD', 'xả thải', 'sông', 'hồ'],
            'waste_management': ['chất thải', 'rác thải', 'chất thải nguy hại', 'chất thải rắn', 'xử lý chất thải'],
            'eia': ['đánh giá tác động', 'ĐTM', 'báo cáo đánh giá', 'tác động môi trường'],
            'monitoring': ['quan trắc', 'giám sát', 'đo đạc', 'lấy mẫu', 'phân tích'],
            'permit': ['giấy phép', 'cấp phép', 'đăng ký', 'thủ tục', 'hồ sơ']
        }
        
        text_lower = text.lower()
        scores = {}
        
        for category, keywords in categories.items():
            score = sum(1 for kw in keywords if kw.lower() in text_lower)
            scores[category] = score / len(keywords) if keywords else 0
        
        # Normalize scores
        total = sum(scores.values())
        if total > 0:
            scores = {k: v / total for k, v in scores.items()}
        
        return scores
    
    # ==================== PREPROCESSING PIPELINE ====================
    
    def preprocess(
        self,
        text: str,
        remove_stopwords: bool = True,
        lowercase: bool = True,
        tokenize: bool = True
    ) -> str:
        """
        Full preprocessing pipeline.
        
        Args:
            text: Input text
            remove_stopwords: Remove Vietnamese stopwords
            lowercase: Convert to lowercase
            tokenize: Return as space-joined tokens
        
        Returns:
            Preprocessed text
        """
        # Clean text
        text = self.clean_text(text, keep_punctuation=False)
        
        if lowercase:
            text = text.lower()
        
        if tokenize:
            tokens = self.tokenize(text)
            
            if remove_stopwords:
                tokens = self.remove_stopwords(tokens)
            
            text = ' '.join(tokens)
        
        return text


# ============================================
# TEXT VECTORIZATION
# ============================================

from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from typing import Union
import numpy as np

class VietnameseTextVectorizer:
    """
    Text vectorization for Vietnamese environmental documents.
    """
    
    def __init__(
        self,
        method: str = 'tfidf',
        max_features: int = 10000,
        ngram_range: Tuple[int, int] = (1, 2),
        min_df: int = 2,
        max_df: float = 0.95
    ):
        """
        Initialize vectorizer.
        
        Args:
            method: 'tfidf' or 'count'
            max_features: Maximum number of features
            ngram_range: Range of n-grams
            min_df: Minimum document frequency
            max_df: Maximum document frequency
        """
        self.method = method
        self.nlp = VietnameseNLPPipeline()
        
        vectorizer_class = TfidfVectorizer if method == 'tfidf' else CountVectorizer
        
        self.vectorizer = vectorizer_class(
            max_features=max_features,
            ngram_range=ngram_range,
            min_df=min_df,
            max_df=max_df,
            preprocessor=self._preprocess,
            tokenizer=self._tokenize
        )
    
    def _preprocess(self, text: str) -> str:
        """Preprocess text before tokenization."""
        return self.nlp.clean_text(text, keep_punctuation=False)
    
    def _tokenize(self, text: str) -> List[str]:
        """Tokenize text."""
        tokens = self.nlp.tokenize(text)
        tokens = self.nlp.remove_stopwords(tokens)
        return tokens
    
    def fit(self, texts: List[str]) -> 'VietnameseTextVectorizer':
        """Fit vectorizer on texts."""
        self.vectorizer.fit(texts)
        return self
    
    def transform(self, texts: List[str]) -> np.ndarray:
        """Transform texts to vectors."""
        return self.vectorizer.transform(texts)
    
    def fit_transform(self, texts: List[str]) -> np.ndarray:
        """Fit and transform texts."""
        return self.vectorizer.fit_transform(texts)
    
    def get_feature_names(self) -> List[str]:
        """Get feature names (vocabulary)."""
        return self.vectorizer.get_feature_names_out().tolist()
    
    def get_top_features(self, n: int = 20) -> List[Tuple[str, float]]:
        """Get top features by IDF score (for TF-IDF only)."""
        if self.method != 'tfidf':
            raise ValueError("Top features only available for TF-IDF")
        
        feature_names = self.get_feature_names()
        idf_scores = self.vectorizer.idf_
        
        top_indices = np.argsort(idf_scores)[-n:][::-1]
        
        return [(feature_names[i], idf_scores[i]) for i in top_indices]


# Usage Example
if __name__ == "__main__":
    # Sample Vietnamese environmental text
    sample_text = """
    Theo Nghị định số 08/2022/NĐ-CP ngày 10/01/2022 của Chính phủ quy định chi tiết 
    một số điều của Luật Bảo vệ môi trường, các cơ sở sản xuất công nghiệp phải 
    thực hiện quan trắc môi trường định kỳ. Điều 15 khoản 2 điểm a quy định nồng độ 
    BOD5 không vượt quá 30 mg/L và COD không vượt quá 75 mg/L theo QCVN 40:2011/BTNMT.
    """
    
    # Initialize pipeline
    nlp = VietnameseNLPPipeline(use_underthesea=True)
    
    # Process text
    print("=== Vietnamese NLP Pipeline Demo ===\n")
    
    # Clean text
    cleaned = nlp.clean_text(sample_text)
    print(f"Cleaned text:\n{cleaned[:200]}...\n")
    
    # Tokenize
    tokens = nlp.tokenize(cleaned)
    print(f"Tokens: {tokens[:15]}...\n")
    
    # Extract entities
    entities = nlp.extract_entities(sample_text)
    print(f"Extracted entities:")
    for entity_type, values in entities.items():
        if values:
            print(f"  {entity_type}: {values}")
    
    # Extract QCVN references
    qcvn_refs = nlp.extract_qcvn_references(sample_text)
    print(f"\nQCVN References: {qcvn_refs}")
    
    # Categorize
    categories = nlp.categorize_environmental_text(sample_text)
    print(f"\nCategory scores:")
    for cat, score in sorted(categories.items(), key=lambda x: x[1], reverse=True):
        print(f"  {cat}: {score:.3f}")
```

### Ngày 5-6: Text Classification cho Environmental Documents

#### 3.1 Document Classifier

```python
# ============================================
# ENVIRONMENTAL DOCUMENT CLASSIFIER
# ============================================

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.pipeline import Pipeline
from typing import List, Dict, Tuple, Optional
import joblib
import json

class EnvironmentalDocumentClassifier:
    """
    Classifier for Vietnamese environmental regulatory documents.
    
    Classification Taxonomy:
    
    Level 1 - Document Type:
    - Luật (Law)
    - Nghị định (Decree)
    - Thông tư (Circular)
    - QCVN (Technical Regulation)
    - TCVN (Standard)
    - Quyết định (Decision)
    - Công văn (Official Letter)
    
    Level 2 - Environmental Domain:
    - air_quality: Chất lượng không khí
    - water_quality: Chất lượng nước
    - waste_management: Quản lý chất thải
    - eia: Đánh giá tác động môi trường
    - permit: Giấy phép môi trường
    - monitoring: Quan trắc môi trường
    - penalty: Xử phạt vi phạm
    """
    
    # Document type classification
    DOCUMENT_TYPES = {
        'luat': 'Luật',
        'nghi_dinh': 'Nghị định',
        'thong_tu': 'Thông tư',
        'qcvn': 'QCVN',
        'tcvn': 'TCVN',
        'quyet_dinh': 'Quyết định',
        'cong_van': 'Công văn'
    }
    
    # Environmental domains
    DOMAINS = {
        'air_quality': {
            'name': 'Chất lượng không khí',
            'keywords': ['không khí', 'khí thải', 'PM2.5', 'PM10', 'NO2', 'SO2', 
                        'ô nhiễm không khí', 'bụi', 'ống khói', 'khí độc']
        },
        'water_quality': {
            'name': 'Chất lượng nước',
            'keywords': ['nước thải', 'nước mặt', 'nước ngầm', 'BOD', 'COD', 
                        'TSS', 'xả thải', 'nguồn nước', 'sông', 'hồ', 'biển']
        },
        'waste_management': {
            'name': 'Quản lý chất thải',
            'keywords': ['chất thải rắn', 'chất thải nguy hại', 'rác thải', 
                        'xử lý chất thải', 'thu gom', 'vận chuyển chất thải', 'bãi chôn lấp']
        },
        'eia': {
            'name': 'Đánh giá tác động môi trường',
            'keywords': ['đánh giá tác động', 'ĐTM', 'báo cáo ĐTM', 'tác động môi trường',
                        'dự án', 'đầu tư', 'thẩm định']
        },
        'permit': {
            'name': 'Giấy phép môi trường',
            'keywords': ['giấy phép', 'cấp phép', 'đăng ký môi trường', 
                        'giấy phép môi trường', 'GPMT', 'hồ sơ cấp phép']
        },
        'monitoring': {
            'name': 'Quan trắc môi trường',
            'keywords': ['quan trắc', 'giám sát', 'đo đạc', 'lấy mẫu', 
                        'phân tích', 'trạm quan trắc', 'mạng lưới quan trắc']
        },
        'penalty': {
            'name': 'Xử phạt vi phạm',
            'keywords': ['xử phạt', 'vi phạm', 'phạt tiền', 'xử lý vi phạm',
                        'biện pháp khắc phục', 'đình chỉ', 'thu hồi']
        }
    }
    
    def __init__(
        self,
        classification_level: str = 'domain',  # 'type' or 'domain'
        model_type: str = 'logistic_regression'
    ):
        """
        Initialize classifier.
        
        Args:
            classification_level: 'type' for document type, 'domain' for environmental domain
            model_type: ML model to use
        """
        self.classification_level = classification_level
        self.model_type = model_type
        
        # Initialize NLP pipeline
        self.nlp = VietnameseNLPPipeline(use_underthesea=True)
        
        # Initialize vectorizer
        self.vectorizer = VietnameseTextVectorizer(
            method='tfidf',
            max_features=10000,
            ngram_range=(1, 3)
        )
        
        # Initialize model
        self.model = self._get_model(model_type)
        
        # For storing label mapping
        self.label_encoder = None
        self.classes_ = None
    
    def _get_model(self, model_type: str):
        """Get ML model by type."""
        models = {
            'naive_bayes': MultinomialNB(alpha=0.1),
            'logistic_regression': LogisticRegression(
                max_iter=1000, 
                C=1.0, 
                class_weight='balanced',
                random_state=42
            ),
            'svm': LinearSVC(
                C=1.0, 
                class_weight='balanced',
                random_state=42,
                max_iter=2000
            ),
            'random_forest': RandomForestClassifier(
                n_estimators=100,
                class_weight='balanced',
                random_state=42
            )
        }
        return models.get(model_type, models['logistic_regression'])
    
    def _extract_features(self, text: str) -> Dict:
        """Extract additional features from text."""
        features = {}
        
        # Document type features
        features['has_dieu'] = 1 if re.search(r'Điều\s+\d+', text) else 0
        features['has_khoan'] = 1 if re.search(r'[Kk]hoản\s+\d+', text) else 0
        features['has_qcvn'] = 1 if re.search(r'QCVN', text, re.IGNORECASE) else 0
        features['has_number_value'] = 1 if re.search(r'\d+\s*mg/[Ll]', text) else 0
        
        # Length features
        features['text_length'] = len(text)
        features['word_count'] = len(text.split())
        
        # Domain keyword counts
        for domain, info in self.DOMAINS.items():
            count = sum(1 for kw in info['keywords'] if kw.lower() in text.lower())
            features[f'domain_{domain}_count'] = count
        
        return features
    
    def prepare_training_data(
        self,
        texts: List[str],
        labels: List[str]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Prepare training data.
        
        Args:
            texts: List of document texts
            labels: List of labels
        
        Returns:
            X (feature matrix), y (encoded labels)
        """
        # Vectorize texts
        X_tfidf = self.vectorizer.fit_transform(texts)
        
        # Extract additional features
        additional_features = []
        for text in texts:
            features = self._extract_features(text)
            additional_features.append(list(features.values()))
        
        X_additional = np.array(additional_features)
        
        # Combine features
        from scipy.sparse import hstack
        X = hstack([X_tfidf, X_additional])
        
        # Encode labels
        from sklearn.preprocessing import LabelEncoder
        self.label_encoder = LabelEncoder()
        y = self.label_encoder.fit_transform(labels)
        self.classes_ = self.label_encoder.classes_
        
        return X, y
    
    def train(
        self,
        texts: List[str],
        labels: List[str],
        test_size: float = 0.2,
        cv_folds: int = 5
    ) -> Dict:
        """
        Train the classifier.
        
        Args:
            texts: List of document texts
            labels: List of labels
            test_size: Test set proportion
            cv_folds: Number of cross-validation folds
        
        Returns:
            Training results dictionary
        """
        print(f"Training {self.model_type} classifier for {self.classification_level}...")
        
        # Prepare data
        X, y = self.prepare_training_data(texts, labels)
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        
        # Cross-validation
        cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
        cv_scores = cross_val_score(self.model, X_train, y_train, cv=cv, scoring='f1_weighted')
        
        print(f"Cross-validation F1 scores: {cv_scores}")
        print(f"Mean CV F1: {cv_scores.mean():.4f} (+/- {cv_scores.std()*2:.4f})")
        
        # Train on full training set
        self.model.fit(X_train, y_train)
        
        # Evaluate on test set
        y_pred = self.model.predict(X_test)
        
        # Generate report
        report = classification_report(
            y_test, y_pred,
            target_names=self.classes_,
            output_dict=True
        )
        
        conf_matrix = confusion_matrix(y_test, y_pred)
        
        results = {
            'cv_scores': cv_scores.tolist(),
            'cv_mean': cv_scores.mean(),
            'cv_std': cv_scores.std(),
            'classification_report': report,
            'confusion_matrix': conf_matrix.tolist(),
            'classes': self.classes_.tolist(),
            'test_accuracy': report['accuracy'],
            'test_f1_weighted': report['weighted avg']['f1-score']
        }
        
        # Print results
        print("\n=== Test Set Results ===")
        print(classification_report(y_test, y_pred, target_names=self.classes_))
        
        return results
    
    def predict(self, text: str) -> Dict:
        """
        Predict document class.
        
        Args:
            text: Document text
        
        Returns:
            Prediction result with class and confidence
        """
        # Vectorize
        X_tfidf = self.vectorizer.transform([text])
        
        # Additional features
        features = self._extract_features(text)
        X_additional = np.array([list(features.values())])
        
        # Combine
        from scipy.sparse import hstack
        X = hstack([X_tfidf, X_additional])
        
        # Predict
        prediction = self.model.predict(X)[0]
        predicted_class = self.label_encoder.inverse_transform([prediction])[0]
        
        # Get probabilities if available
        if hasattr(self.model, 'predict_proba'):
            proba = self.model.predict_proba(X)[0]
            confidence = float(max(proba))
            class_probabilities = {
                cls: float(p) for cls, p in zip(self.classes_, proba)
            }
        elif hasattr(self.model, 'decision_function'):
            decision = self.model.decision_function(X)[0]
            # Convert to pseudo-probabilities using softmax
            exp_decision = np.exp(decision - np.max(decision))
            proba = exp_decision / exp_decision.sum()
            confidence = float(max(proba))
            class_probabilities = {
                cls: float(p) for cls, p in zip(self.classes_, proba)
            }
        else:
            confidence = None
            class_probabilities = None
        
        return {
            'predicted_class': predicted_class,
            'confidence': confidence,
            'class_probabilities': class_probabilities,
            'extracted_entities': self.nlp.extract_entities(text),
            'domain_scores': self.nlp.categorize_environmental_text(text)
        }
    
    def predict_batch(self, texts: List[str]) -> List[Dict]:
        """Predict classes for multiple documents."""
        return [self.predict(text) for text in texts]
    
    def save(self, path: str):
        """Save model to disk."""
        model_data = {
            'model': self.model,
            'vectorizer': self.vectorizer,
            'label_encoder': self.label_encoder,
            'classes': self.classes_,
            'classification_level': self.classification_level,
            'model_type': self.model_type
        }
        joblib.dump(model_data, path)
        print(f"Model saved to {path}")
    
    @classmethod
    def load(cls, path: str) -> 'EnvironmentalDocumentClassifier':
        """Load model from disk."""
        model_data = joblib.load(path)
        
        classifier = cls(
            classification_level=model_data['classification_level'],
            model_type=model_data['model_type']
        )
        classifier.model = model_data['model']
        classifier.vectorizer = model_data['vectorizer']
        classifier.label_encoder = model_data['label_encoder']
        classifier.classes_ = model_data['classes']
        
        return classifier


# ============================================
# TRAINING DATA GENERATOR (for demo purposes)
# ============================================

def generate_sample_training_data(n_samples_per_class: int = 50) -> Tuple[List[str], List[str]]:
    """
    Generate sample training data for demonstration.
    In real scenarios, this would come from a labeled dataset.
    """
    
    templates = {
        'air_quality': [
            "Quy định về nồng độ bụi PM2.5 và PM10 trong không khí xung quanh theo QCVN 05:2023/BTNMT.",
            "Hướng dẫn quan trắc chất lượng không khí tại các khu công nghiệp với các thông số NO2, SO2, CO.",
            "Tiêu chuẩn phát thải khí thải công nghiệp qua ống khói nhà máy xi măng.",
            "Biện pháp giảm thiểu ô nhiễm không khí từ hoạt động giao thông vận tải.",
            "Quy chuẩn kỹ thuật quốc gia về khí thải phương tiện cơ giới đường bộ."
        ],
        'water_quality': [
            "Quy chuẩn nước thải công nghiệp QCVN 40:2011/BTNMT quy định giới hạn BOD, COD, TSS.",
            "Hướng dẫn xử lý nước thải sinh hoạt đô thị đạt cột B QCVN 14:2008/BTNMT.",
            "Tiêu chuẩn chất lượng nước mặt dùng cho mục đích cấp nước sinh hoạt.",
            "Quy định về xả nước thải vào nguồn tiếp nhận là sông, hồ, biển.",
            "Biện pháp xử lý nước thải chứa kim loại nặng trong ngành mạ điện."
        ],
        'waste_management': [
            "Quy định về quản lý chất thải rắn sinh hoạt đô thị và nông thôn.",
            "Hướng dẫn phân loại, thu gom và xử lý chất thải nguy hại tại nguồn.",
            "Tiêu chuẩn kỹ thuật bãi chôn lấp chất thải rắn hợp vệ sinh.",
            "Quy trình vận chuyển chất thải nguy hại từ nguồn thải đến cơ sở xử lý.",
            "Công nghệ đốt chất thải y tế và xử lý tro xỉ sau đốt."
        ],
        'eia': [
            "Quy trình lập báo cáo đánh giá tác động môi trường cho dự án đầu tư nhóm I.",
            "Nội dung chương trình quan trắc, giám sát môi trường trong báo cáo ĐTM.",
            "Hướng dẫn đánh giá tác động môi trường chiến lược cho quy hoạch phát triển.",
            "Thủ tục thẩm định và phê duyệt báo cáo ĐTM thuộc thẩm quyền Bộ TNMT.",
            "Yêu cầu tham vấn cộng đồng trong quá trình lập báo cáo ĐTM."
        ],
        'permit': [
            "Thủ tục cấp giấy phép môi trường theo Nghị định 08/2022/NĐ-CP.",
            "Hồ sơ đề nghị cấp giấy phép xả nước thải vào nguồn nước.",
            "Quy định về gia hạn, điều chỉnh giấy phép môi trường.",
            "Điều kiện để được cấp giấy phép nhập khẩu phế liệu làm nguyên liệu sản xuất.",
            "Trình tự đăng ký môi trường cho các cơ sở sản xuất kinh doanh quy mô nhỏ."
        ],
        'monitoring': [
            "Quy định về mạng lưới quan trắc môi trường quốc gia và địa phương.",
            "Tần suất và phương pháp quan trắc chất lượng môi trường không khí.",
            "Yêu cầu về thiết bị quan trắc tự động, liên tục khí thải công nghiệp.",
            "Hướng dẫn lấy mẫu và phân tích môi trường nước theo TCVN.",
            "Báo cáo kết quả quan trắc môi trường định kỳ hàng quý, năm."
        ],
        'penalty': [
            "Xử phạt vi phạm hành chính trong lĩnh vực bảo vệ môi trường.",
            "Mức phạt tiền đối với hành vi xả thải vượt quy chuẩn cho phép.",
            "Biện pháp khắc phục hậu quả vi phạm môi trường bắt buộc áp dụng.",
            "Thẩm quyền xử phạt vi phạm môi trường của các cấp chính quyền.",
            "Đình chỉ hoạt động cơ sở gây ô nhiễm môi trường nghiêm trọng."
        ]
    }
    
    texts = []
    labels = []
    
    for domain, domain_templates in templates.items():
        for _ in range(n_samples_per_class):
            # Select random template and add variation
            template = np.random.choice(domain_templates)
            # Add some random variation
            text = template + f" Áp dụng từ ngày {np.random.randint(1,28)}/{np.random.randint(1,12)}/2024."
            texts.append(text)
            labels.append(domain)
    
    # Shuffle
    combined = list(zip(texts, labels))
    np.random.shuffle(combined)
    texts, labels = zip(*combined)
    
    return list(texts), list(labels)


# Usage Example
if __name__ == "__main__":
    # Generate sample data
    print("Generating sample training data...")
    texts, labels = generate_sample_training_data(n_samples_per_class=100)
    
    print(f"Total samples: {len(texts)}")
    print(f"Classes: {set(labels)}")
    
    # Train classifier
    classifier = EnvironmentalDocumentClassifier(
        classification_level='domain',
        model_type='logistic_regression'
    )
    
    results = classifier.train(texts, labels)
    
    # Test prediction
    test_text = """
    Theo quy định tại Điều 15 Nghị định 08/2022/NĐ-CP, các cơ sở sản xuất phải 
    thực hiện quan trắc nước thải định kỳ với các thông số BOD5, COD, TSS theo 
    QCVN 40:2011/BTNMT. Nồng độ BOD5 không vượt quá 30 mg/L đối với cột A.
    """
    
    print("\n=== Test Prediction ===")
    prediction = classifier.predict(test_text)
    print(f"Predicted class: {prediction['predicted_class']}")
    print(f"Confidence: {prediction['confidence']:.4f}")
    print(f"Domain scores: {prediction['domain_scores']}")
    
    # Save model
    classifier.save("models/env_document_classifier.joblib")
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Pollution Level Classifier (Ngày 1-3)

```
🎯 Mục tiêu: Xây dựng classifier dự đoán mức độ ô nhiễm

📋 Yêu cầu:
1. Thu thập/tạo dữ liệu quan trắc không khí
2. Xây dựng features từ các thông số (PM2.5, PM10, etc.)
3. Train và compare nhiều models
4. Đánh giá với cross-validation
5. Feature importance analysis

📁 Deliverables:
- src/models/pollution_classifier.py
- notebooks/pollution_classification.ipynb
- Model report với metrics
```

### Bài tập 2: Vietnamese NLP Pipeline (Ngày 4-5)

```
🎯 Mục tiêu: Xây dựng NLP pipeline hoàn chỉnh cho Vietnamese text

📋 Yêu cầu:
1. Implement text cleaning và normalization
2. Vietnamese word segmentation
3. Entity extraction (QCVN, parameters, etc.)
4. Text categorization

📁 Deliverables:
- src/nlp/vietnamese_pipeline.py
- tests/test_vietnamese_nlp.py
- Demo notebook với examples
```

### Bài tập 3: Document Classifier (Ngày 6-7)

```
🎯 Mục tiêu: Classifier cho văn bản quy định môi trường

📋 Yêu cầu:
1. Collect/create training dataset (có thể synthetic)
2. Implement TF-IDF vectorization cho Vietnamese
3. Train multi-class classifier
4. Evaluate và optimize
5. Save/load model functionality

📁 Deliverables:
- src/classifiers/document_classifier.py
- Training notebook
- Evaluation report
- Saved model file
```

---

## ✅ CHECKLIST TUẦN 2

### Kiến thức đã học
- [ ] ML workflow end-to-end
- [ ] Supervised learning algorithms (classification, regression)
- [ ] Model evaluation metrics
- [ ] Cross-validation và hyperparameter tuning
- [ ] Vietnamese NLP: tokenization, POS tagging
- [ ] Text preprocessing và vectorization (TF-IDF)
- [ ] Text classification techniques

### Skills thực hành
- [ ] Sử dụng scikit-learn cho ML tasks
- [ ] Xử lý Vietnamese text với underthesea
- [ ] Build và evaluate classification models
- [ ] Feature engineering cho environmental data
- [ ] Model persistence (save/load)

### Deliverables
- [ ] Pollution level classifier
- [ ] Vietnamese NLP pipeline
- [ ] Environmental document classifier
- [ ] Test suite với adequate coverage
- [ ] Model evaluation reports

---

*Hoàn thành Tuần 2 để tiếp tục sang Tuần 3: Vector Databases & Semantic Search*
