# 📅 TUẦN 3: VECTOR DATABASES & SEMANTIC SEARCH

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Thành thạo Vector DB và xây dựng semantic search system |
| **Output** | Environmental Regulation Search Engine |
| **Độ khó** | ⭐⭐⭐ Trung bình - Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu embeddings và vector representations
- [ ] Nắm vững các loại vector databases và use cases
- [ ] Hiểu similarity metrics (cosine, euclidean, dot product)
- [ ] Biết chunking strategies cho documents

### Kỹ năng (Skills)
- [ ] Sử dụng OpenAI/Hugging Face embedding models
- [ ] Setup và query ChromaDB, Pinecone
- [ ] Implement semantic search với filtering
- [ ] Optimize search quality và performance

### Ứng dụng (Application)
- [ ] Xây dựng search engine cho văn bản quy định môi trường
- [ ] Hybrid search (semantic + keyword)
- [ ] Search API với FastAPI

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: Embeddings và Vector Representations

#### 1.1 Embedding Fundamentals

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         EMBEDDING FUNDAMENTALS                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Text Input                    Embedding Model              Vector Output    │
│  ┌─────────────┐              ┌─────────────┐              ┌─────────────┐  │
│  │ "Ô nhiễm    │  ─────────▶  │  Neural     │  ─────────▶  │ [0.23,     │  │
│  │  môi trường"│              │  Network    │              │  -0.45,    │  │
│  └─────────────┘              └─────────────┘              │  0.12,     │  │
│                                                            │  ...,      │  │
│                                                            │  0.67]     │  │
│                                                            │ 1536 dims  │  │
│                                                            └─────────────┘  │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                    SEMANTIC SIMILARITY                                  │ │
│  │                                                                         │ │
│  │  "Ô nhiễm không khí"  ──▶  [v1] ─┐                                     │ │
│  │                                   ├──▶ Cosine Similarity = 0.92        │ │
│  │  "Air pollution"      ──▶  [v2] ─┘                                     │ │
│  │                                                                         │ │
│  │  Same meaning → Similar vectors → High similarity score                │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 Embedding Models Comparison

```python
# ============================================
# EMBEDDING MODELS FOR VIETNAMESE TEXT
# ============================================

import numpy as np
from typing import List, Dict, Optional, Union
from dataclasses import dataclass
from abc import ABC, abstractmethod
import time

@dataclass
class EmbeddingResult:
    """Result from embedding operation."""
    text: str
    vector: np.ndarray
    model: str
    dimensions: int
    latency_ms: float

class BaseEmbeddingModel(ABC):
    """Abstract base class for embedding models."""
    
    @abstractmethod
    def embed(self, text: str) -> np.ndarray:
        """Embed single text."""
        pass
    
    @abstractmethod
    def embed_batch(self, texts: List[str]) -> List[np.ndarray]:
        """Embed batch of texts."""
        pass
    
    @property
    @abstractmethod
    def dimensions(self) -> int:
        """Get embedding dimensions."""
        pass
    
    @property
    @abstractmethod
    def model_name(self) -> str:
        """Get model name."""
        pass


class OpenAIEmbedding(BaseEmbeddingModel):
    """
    OpenAI Embedding Models.
    
    Models:
    - text-embedding-3-small: 1536 dims, fast, cost-effective
    - text-embedding-3-large: 3072 dims, highest quality
    - text-embedding-ada-002: 1536 dims, legacy
    """
    
    MODEL_DIMENSIONS = {
        "text-embedding-3-small": 1536,
        "text-embedding-3-large": 3072,
        "text-embedding-ada-002": 1536
    }
    
    def __init__(
        self, 
        model: str = "text-embedding-3-small",
        api_key: Optional[str] = None
    ):
        from openai import OpenAI
        
        self.model = model
        self.client = OpenAI(api_key=api_key)
        self._dimensions = self.MODEL_DIMENSIONS.get(model, 1536)
    
    @property
    def dimensions(self) -> int:
        return self._dimensions
    
    @property
    def model_name(self) -> str:
        return f"openai/{self.model}"
    
    def embed(self, text: str) -> np.ndarray:
        """Embed single text."""
        response = self.client.embeddings.create(
            model=self.model,
            input=text
        )
        return np.array(response.data[0].embedding)
    
    def embed_batch(
        self, 
        texts: List[str], 
        batch_size: int = 100
    ) -> List[np.ndarray]:
        """Embed batch of texts with automatic batching."""
        all_embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            
            response = self.client.embeddings.create(
                model=self.model,
                input=batch
            )
            
            batch_embeddings = [
                np.array(item.embedding) 
                for item in response.data
            ]
            all_embeddings.extend(batch_embeddings)
            
            # Rate limiting
            if i + batch_size < len(texts):
                time.sleep(0.1)
        
        return all_embeddings
    
    def embed_with_metadata(self, text: str) -> EmbeddingResult:
        """Embed with timing and metadata."""
        start = time.perf_counter()
        vector = self.embed(text)
        latency = (time.perf_counter() - start) * 1000
        
        return EmbeddingResult(
            text=text,
            vector=vector,
            model=self.model_name,
            dimensions=self.dimensions,
            latency_ms=latency
        )


class HuggingFaceEmbedding(BaseEmbeddingModel):
    """
    Hugging Face Sentence Transformers.
    
    Recommended models for Vietnamese:
    - sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2: 384 dims
    - sentence-transformers/paraphrase-multilingual-mpnet-base-v2: 768 dims
    - BAAI/bge-m3: 1024 dims (multilingual, best quality)
    - intfloat/multilingual-e5-large: 1024 dims
    """
    
    def __init__(self, model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"):
        from sentence_transformers import SentenceTransformer
        
        self._model_name = model_name
        self.model = SentenceTransformer(model_name)
        self._dimensions = self.model.get_sentence_embedding_dimension()
    
    @property
    def dimensions(self) -> int:
        return self._dimensions
    
    @property
    def model_name(self) -> str:
        return f"huggingface/{self._model_name}"
    
    def embed(self, text: str) -> np.ndarray:
        """Embed single text."""
        return self.model.encode(text, convert_to_numpy=True)
    
    def embed_batch(self, texts: List[str], batch_size: int = 32) -> List[np.ndarray]:
        """Embed batch of texts."""
        embeddings = self.model.encode(
            texts, 
            batch_size=batch_size,
            convert_to_numpy=True,
            show_progress_bar=True
        )
        return list(embeddings)


class VinAIEmbedding(BaseEmbeddingModel):
    """
    VinAI PhoBERT-based embeddings for Vietnamese.
    
    Best for Vietnamese-specific tasks but requires more setup.
    """
    
    def __init__(self, model_name: str = "vinai/phobert-base"):
        from transformers import AutoModel, AutoTokenizer
        import torch
        
        self._model_name = model_name
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self._dimensions = 768
    
    @property
    def dimensions(self) -> int:
        return self._dimensions
    
    @property
    def model_name(self) -> str:
        return f"vinai/{self._model_name}"
    
    def embed(self, text: str) -> np.ndarray:
        """Embed using mean pooling."""
        import torch
        
        inputs = self.tokenizer(
            text, 
            return_tensors="pt", 
            padding=True, 
            truncation=True,
            max_length=256
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            # Mean pooling
            embeddings = outputs.last_hidden_state.mean(dim=1)
        
        return embeddings.cpu().numpy()[0]
    
    def embed_batch(self, texts: List[str], batch_size: int = 16) -> List[np.ndarray]:
        """Embed batch of texts."""
        import torch
        
        all_embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            
            inputs = self.tokenizer(
                batch,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=256
            ).to(self.device)
            
            with torch.no_grad():
                outputs = self.model(**inputs)
                embeddings = outputs.last_hidden_state.mean(dim=1)
            
            all_embeddings.extend(embeddings.cpu().numpy())
        
        return all_embeddings


# ============================================
# EMBEDDING UTILITIES
# ============================================

class EmbeddingUtils:
    """Utility functions for working with embeddings."""
    
    @staticmethod
    def cosine_similarity(v1: np.ndarray, v2: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors."""
        dot_product = np.dot(v1, v2)
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)
        
        if norm_v1 == 0 or norm_v2 == 0:
            return 0.0
        
        return dot_product / (norm_v1 * norm_v2)
    
    @staticmethod
    def euclidean_distance(v1: np.ndarray, v2: np.ndarray) -> float:
        """Calculate Euclidean distance between two vectors."""
        return np.linalg.norm(v1 - v2)
    
    @staticmethod
    def dot_product(v1: np.ndarray, v2: np.ndarray) -> float:
        """Calculate dot product between two vectors."""
        return np.dot(v1, v2)
    
    @staticmethod
    def normalize(vector: np.ndarray) -> np.ndarray:
        """Normalize vector to unit length."""
        norm = np.linalg.norm(vector)
        if norm == 0:
            return vector
        return vector / norm
    
    @staticmethod
    def find_most_similar(
        query_vector: np.ndarray,
        candidate_vectors: List[np.ndarray],
        top_k: int = 5,
        metric: str = "cosine"
    ) -> List[Dict]:
        """
        Find most similar vectors to query.
        
        Args:
            query_vector: Query embedding
            candidate_vectors: List of candidate embeddings
            top_k: Number of results to return
            metric: Similarity metric ('cosine', 'euclidean', 'dot')
        
        Returns:
            List of {index, score} dicts sorted by similarity
        """
        scores = []
        
        for i, candidate in enumerate(candidate_vectors):
            if metric == "cosine":
                score = EmbeddingUtils.cosine_similarity(query_vector, candidate)
            elif metric == "euclidean":
                # Convert distance to similarity (lower distance = higher similarity)
                score = -EmbeddingUtils.euclidean_distance(query_vector, candidate)
            elif metric == "dot":
                score = EmbeddingUtils.dot_product(query_vector, candidate)
            else:
                raise ValueError(f"Unknown metric: {metric}")
            
            scores.append({"index": i, "score": float(score)})
        
        # Sort by score (descending for similarity, ascending for distance)
        scores.sort(key=lambda x: x["score"], reverse=True)
        
        return scores[:top_k]
    
    @staticmethod
    def compare_embeddings(
        text1: str,
        text2: str,
        model: BaseEmbeddingModel
    ) -> Dict:
        """Compare semantic similarity of two texts."""
        v1 = model.embed(text1)
        v2 = model.embed(text2)
        
        return {
            "text1": text1,
            "text2": text2,
            "cosine_similarity": EmbeddingUtils.cosine_similarity(v1, v2),
            "euclidean_distance": EmbeddingUtils.euclidean_distance(v1, v2),
            "dot_product": EmbeddingUtils.dot_product(v1, v2)
        }


# ============================================
# MODEL COMPARISON BENCHMARK
# ============================================

class EmbeddingBenchmark:
    """Benchmark embedding models for Vietnamese environmental text."""
    
    # Test cases: pairs of semantically similar texts
    TEST_CASES = [
        # Vietnamese - Vietnamese (same meaning, different words)
        ("Ô nhiễm môi trường không khí", "Chất lượng không khí bị suy giảm"),
        ("Xử lý nước thải công nghiệp", "Làm sạch nước thải từ nhà máy"),
        ("Đánh giá tác động môi trường", "Báo cáo ĐTM của dự án"),
        
        # Vietnamese - English (cross-lingual)
        ("Ô nhiễm không khí", "Air pollution"),
        ("Quản lý chất thải rắn", "Solid waste management"),
        ("Quan trắc môi trường", "Environmental monitoring"),
        
        # Domain-specific (environmental regulations)
        ("QCVN 40:2011 về nước thải", "Quy chuẩn nước thải công nghiệp"),
        ("Giấy phép môi trường", "Cấp phép xả thải"),
        
        # Dissimilar pairs (should have low similarity)
        ("Ô nhiễm không khí", "Công nghệ thông tin"),
        ("Xử lý nước thải", "Tài chính ngân hàng"),
    ]
    
    def __init__(self, models: List[BaseEmbeddingModel]):
        self.models = models
    
    def run_benchmark(self) -> pd.DataFrame:
        """Run benchmark on all models."""
        import pandas as pd
        
        results = []
        
        for model in self.models:
            print(f"Benchmarking {model.model_name}...")
            
            model_results = {
                "model": model.model_name,
                "dimensions": model.dimensions,
                "avg_latency_ms": 0,
                "similar_pairs_avg": 0,
                "dissimilar_pairs_avg": 0
            }
            
            latencies = []
            similar_scores = []
            dissimilar_scores = []
            
            for text1, text2 in self.TEST_CASES:
                start = time.perf_counter()
                v1 = model.embed(text1)
                v2 = model.embed(text2)
                latency = (time.perf_counter() - start) * 1000
                
                latencies.append(latency)
                
                similarity = EmbeddingUtils.cosine_similarity(v1, v2)
                
                # Classify as similar or dissimilar based on test case
                if "thông tin" in text2 or "ngân hàng" in text2:
                    dissimilar_scores.append(similarity)
                else:
                    similar_scores.append(similarity)
            
            model_results["avg_latency_ms"] = np.mean(latencies)
            model_results["similar_pairs_avg"] = np.mean(similar_scores)
            model_results["dissimilar_pairs_avg"] = np.mean(dissimilar_scores)
            model_results["discrimination"] = model_results["similar_pairs_avg"] - model_results["dissimilar_pairs_avg"]
            
            results.append(model_results)
        
        return pd.DataFrame(results)


# Usage Example
if __name__ == "__main__":
    # Initialize models
    openai_model = OpenAIEmbedding(model="text-embedding-3-small")
    
    # Test embedding
    text = "Quy định về xả thải nước công nghiệp theo QCVN 40:2011"
    result = openai_model.embed_with_metadata(text)
    
    print(f"Model: {result.model}")
    print(f"Dimensions: {result.dimensions}")
    print(f"Latency: {result.latency_ms:.2f}ms")
    print(f"Vector (first 10): {result.vector[:10]}")
    
    # Compare texts
    comparison = EmbeddingUtils.compare_embeddings(
        "Ô nhiễm nước thải",
        "Water pollution",
        openai_model
    )
    print(f"\nSimilarity: {comparison['cosine_similarity']:.4f}")
```

### Ngày 3-4: Vector Databases Deep Dive

#### 2.1 ChromaDB Implementation

```python
# ============================================
# CHROMADB FOR ENVIRONMENTAL REGULATIONS
# ============================================

import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import hashlib
import json
import os

@dataclass
class Document:
    """Document structure for environmental regulations."""
    id: str
    content: str
    metadata: Dict[str, Any]

@dataclass
class SearchResult:
    """Search result structure."""
    id: str
    content: str
    metadata: Dict[str, Any]
    score: float
    distance: float

class EnvironmentalRegulationDB:
    """
    Vector database for Vietnamese environmental regulations using ChromaDB.
    
    Features:
    - Semantic search
    - Metadata filtering
    - Hybrid search (semantic + keyword)
    - Persistence
    """
    
    # Metadata schema
    METADATA_FIELDS = {
        "doc_type": str,        # luật, nghị_định, thông_tư, qcvn, tcvn
        "doc_number": str,      # Số hiệu văn bản
        "effective_date": str,  # Ngày có hiệu lực
        "issuing_body": str,    # Cơ quan ban hành
        "domain": str,          # Lĩnh vực: air, water, waste, eia, etc.
        "status": str,          # active, expired, amended
        "year": int,            # Năm ban hành
        "chapter": str,         # Chương (nếu có)
        "article": str,         # Điều (nếu có)
    }
    
    def __init__(
        self,
        collection_name: str = "environmental_regulations",
        persist_directory: str = "./chroma_db",
        embedding_model: str = "text-embedding-3-small"
    ):
        """
        Initialize the vector database.
        
        Args:
            collection_name: Name of the collection
            persist_directory: Directory for persistence
            embedding_model: OpenAI embedding model to use
        """
        self.collection_name = collection_name
        self.persist_directory = persist_directory
        
        # Initialize ChromaDB client with persistence
        self.client = chromadb.PersistentClient(
            path=persist_directory,
            settings=Settings(
                anonymized_telemetry=False,
                allow_reset=True
            )
        )
        
        # Initialize embedding function
        self.embedding_fn = embedding_functions.OpenAIEmbeddingFunction(
            api_key=os.getenv("OPENAI_API_KEY"),
            model_name=embedding_model
        )
        
        # Get or create collection
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            embedding_function=self.embedding_fn,
            metadata={
                "hnsw:space": "cosine",  # Use cosine similarity
                "description": "Vietnamese environmental regulations"
            }
        )
        
        print(f"Collection '{collection_name}' initialized with {self.collection.count()} documents")
    
    # ==================== DOCUMENT MANAGEMENT ====================
    
    def _generate_id(self, content: str, metadata: Dict) -> str:
        """Generate unique document ID based on content hash."""
        hash_input = f"{content}:{json.dumps(metadata, sort_keys=True)}"
        return hashlib.md5(hash_input.encode()).hexdigest()[:16]
    
    def add_document(
        self,
        content: str,
        metadata: Dict[str, Any],
        doc_id: Optional[str] = None
    ) -> str:
        """
        Add a single document to the database.
        
        Args:
            content: Document text content
            metadata: Document metadata
            doc_id: Optional custom ID
        
        Returns:
            Document ID
        """
        if doc_id is None:
            doc_id = self._generate_id(content, metadata)
        
        # Validate metadata
        validated_metadata = self._validate_metadata(metadata)
        
        # Add to collection
        self.collection.add(
            documents=[content],
            metadatas=[validated_metadata],
            ids=[doc_id]
        )
        
        return doc_id
    
    def add_documents(
        self,
        documents: List[Document],
        batch_size: int = 100
    ) -> List[str]:
        """
        Add multiple documents in batches.
        
        Args:
            documents: List of Document objects
            batch_size: Batch size for adding
        
        Returns:
            List of document IDs
        """
        all_ids = []
        
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i + batch_size]
            
            ids = [doc.id or self._generate_id(doc.content, doc.metadata) for doc in batch]
            contents = [doc.content for doc in batch]
            metadatas = [self._validate_metadata(doc.metadata) for doc in batch]
            
            self.collection.add(
                documents=contents,
                metadatas=metadatas,
                ids=ids
            )
            
            all_ids.extend(ids)
            print(f"Added {len(all_ids)}/{len(documents)} documents")
        
        return all_ids
    
    def _validate_metadata(self, metadata: Dict) -> Dict:
        """Validate and clean metadata."""
        validated = {}
        
        for key, value in metadata.items():
            if value is not None:
                # ChromaDB requires primitive types
                if isinstance(value, (str, int, float, bool)):
                    validated[key] = value
                elif isinstance(value, datetime):
                    validated[key] = value.isoformat()
                else:
                    validated[key] = str(value)
        
        return validated
    
    def update_document(
        self,
        doc_id: str,
        content: Optional[str] = None,
        metadata: Optional[Dict] = None
    ):
        """Update an existing document."""
        update_kwargs = {"ids": [doc_id]}
        
        if content is not None:
            update_kwargs["documents"] = [content]
        
        if metadata is not None:
            update_kwargs["metadatas"] = [self._validate_metadata(metadata)]
        
        self.collection.update(**update_kwargs)
    
    def delete_document(self, doc_id: str):
        """Delete a document by ID."""
        self.collection.delete(ids=[doc_id])
    
    def delete_by_filter(self, where: Dict):
        """Delete documents matching filter."""
        self.collection.delete(where=where)
    
    def get_document(self, doc_id: str) -> Optional[Document]:
        """Get a document by ID."""
        result = self.collection.get(ids=[doc_id], include=["documents", "metadatas"])
        
        if result["ids"]:
            return Document(
                id=result["ids"][0],
                content=result["documents"][0],
                metadata=result["metadatas"][0]
            )
        return None
    
    # ==================== SEARCH ====================
    
    def search(
        self,
        query: str,
        n_results: int = 5,
        where: Optional[Dict] = None,
        where_document: Optional[Dict] = None,
        include_distances: bool = True
    ) -> List[SearchResult]:
        """
        Semantic search for documents.
        
        Args:
            query: Search query text
            n_results: Number of results to return
            where: Metadata filter (e.g., {"domain": "water_quality"})
            where_document: Document content filter
            include_distances: Include distance scores
        
        Returns:
            List of SearchResult objects
        
        Example filters:
            where={"domain": "water_quality"}
            where={"year": {"$gte": 2020}}
            where={"$and": [{"domain": "air"}, {"status": "active"}]}
        """
        query_kwargs = {
            "query_texts": [query],
            "n_results": n_results,
            "include": ["documents", "metadatas", "distances"]
        }
        
        if where:
            query_kwargs["where"] = where
        
        if where_document:
            query_kwargs["where_document"] = where_document
        
        results = self.collection.query(**query_kwargs)
        
        search_results = []
        
        for i in range(len(results["ids"][0])):
            # Convert distance to similarity score (cosine distance -> similarity)
            distance = results["distances"][0][i] if results["distances"] else 0
            score = 1 - distance  # For cosine, similarity = 1 - distance
            
            search_results.append(SearchResult(
                id=results["ids"][0][i],
                content=results["documents"][0][i],
                metadata=results["metadatas"][0][i],
                score=score,
                distance=distance
            ))
        
        return search_results
    
    def search_by_domain(
        self,
        query: str,
        domain: str,
        n_results: int = 5
    ) -> List[SearchResult]:
        """Search within a specific environmental domain."""
        return self.search(
            query=query,
            n_results=n_results,
            where={"domain": domain}
        )
    
    def search_by_date_range(
        self,
        query: str,
        start_year: int,
        end_year: Optional[int] = None,
        n_results: int = 5
    ) -> List[SearchResult]:
        """Search documents within date range."""
        if end_year is None:
            end_year = datetime.now().year
        
        return self.search(
            query=query,
            n_results=n_results,
            where={
                "$and": [
                    {"year": {"$gte": start_year}},
                    {"year": {"$lte": end_year}}
                ]
            }
        )
    
    def search_active_regulations(
        self,
        query: str,
        n_results: int = 5
    ) -> List[SearchResult]:
        """Search only active (non-expired) regulations."""
        return self.search(
            query=query,
            n_results=n_results,
            where={"status": "active"}
        )
    
    # ==================== HYBRID SEARCH ====================
    
    def hybrid_search(
        self,
        query: str,
        n_results: int = 5,
        semantic_weight: float = 0.7,
        keyword_weight: float = 0.3,
        where: Optional[Dict] = None
    ) -> List[SearchResult]:
        """
        Hybrid search combining semantic and keyword matching.
        
        Args:
            query: Search query
            n_results: Number of results
            semantic_weight: Weight for semantic search (0-1)
            keyword_weight: Weight for keyword matching (0-1)
            where: Metadata filter
        
        Returns:
            Combined and reranked results
        """
        # Get more results to allow for reranking
        expanded_n = n_results * 3
        
        # Semantic search
        semantic_results = self.search(
            query=query,
            n_results=expanded_n,
            where=where
        )
        
        # Keyword search using $contains
        keyword_results = self.search(
            query=query,
            n_results=expanded_n,
            where=where,
            where_document={"$contains": query.split()[0]}  # Simple keyword filter
        )
        
        # Combine results with weighted scores
        combined = {}
        
        for result in semantic_results:
            combined[result.id] = {
                "result": result,
                "semantic_score": result.score,
                "keyword_score": 0
            }
        
        for result in keyword_results:
            if result.id in combined:
                combined[result.id]["keyword_score"] = result.score
            else:
                combined[result.id] = {
                    "result": result,
                    "semantic_score": 0,
                    "keyword_score": result.score
                }
        
        # Calculate final scores
        final_results = []
        for doc_id, data in combined.items():
            final_score = (
                semantic_weight * data["semantic_score"] +
                keyword_weight * data["keyword_score"]
            )
            
            result = data["result"]
            result.score = final_score
            final_results.append(result)
        
        # Sort by final score
        final_results.sort(key=lambda x: x.score, reverse=True)
        
        return final_results[:n_results]
    
    # ==================== UTILITIES ====================
    
    def count(self) -> int:
        """Get total document count."""
        return self.collection.count()
    
    def get_stats(self) -> Dict:
        """Get collection statistics."""
        all_docs = self.collection.get(include=["metadatas"])
        
        stats = {
            "total_documents": len(all_docs["ids"]),
            "domains": {},
            "doc_types": {},
            "years": {}
        }
        
        for metadata in all_docs["metadatas"]:
            domain = metadata.get("domain", "unknown")
            doc_type = metadata.get("doc_type", "unknown")
            year = metadata.get("year", "unknown")
            
            stats["domains"][domain] = stats["domains"].get(domain, 0) + 1
            stats["doc_types"][doc_type] = stats["doc_types"].get(doc_type, 0) + 1
            stats["years"][year] = stats["years"].get(year, 0) + 1
        
        return stats
    
    def reset(self):
        """Reset the collection (delete all documents)."""
        self.client.delete_collection(self.collection_name)
        self.collection = self.client.create_collection(
            name=self.collection_name,
            embedding_function=self.embedding_fn,
            metadata={"hnsw:space": "cosine"}
        )
    
    def export_to_json(self, file_path: str):
        """Export all documents to JSON file."""
        all_docs = self.collection.get(include=["documents", "metadatas"])
        
        export_data = [
            {
                "id": all_docs["ids"][i],
                "content": all_docs["documents"][i],
                "metadata": all_docs["metadatas"][i]
            }
            for i in range(len(all_docs["ids"]))
        ]
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, ensure_ascii=False, indent=2)
    
    def import_from_json(self, file_path: str):
        """Import documents from JSON file."""
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        documents = [
            Document(
                id=item.get("id"),
                content=item["content"],
                metadata=item["metadata"]
            )
            for item in data
        ]
        
        self.add_documents(documents)


# ============================================
# DOCUMENT CHUNKING STRATEGIES
# ============================================

class DocumentChunker:
    """
    Chunking strategies for Vietnamese legal documents.
    
    Vietnamese legal document structure:
    - Phần (Part)
    - Chương (Chapter)
    - Mục (Section)
    - Điều (Article)
    - Khoản (Clause)
    - Điểm (Point)
    """
    
    def __init__(
        self,
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        strategy: str = "article"  # "fixed", "article", "semantic"
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.strategy = strategy
    
    def chunk(
        self,
        text: str,
        metadata: Dict = None
    ) -> List[Document]:
        """
        Chunk document based on strategy.
        
        Args:
            text: Full document text
            metadata: Base metadata for all chunks
        
        Returns:
            List of Document chunks
        """
        if self.strategy == "fixed":
            return self._fixed_chunk(text, metadata)
        elif self.strategy == "article":
            return self._article_chunk(text, metadata)
        elif self.strategy == "semantic":
            return self._semantic_chunk(text, metadata)
        else:
            raise ValueError(f"Unknown strategy: {self.strategy}")
    
    def _fixed_chunk(
        self,
        text: str,
        metadata: Dict = None
    ) -> List[Document]:
        """Fixed-size chunking with overlap."""
        chunks = []
        start = 0
        chunk_index = 0
        
        while start < len(text):
            end = start + self.chunk_size
            chunk_text = text[start:end]
            
            # Try to end at sentence boundary
            if end < len(text):
                last_period = chunk_text.rfind('.')
                if last_period > self.chunk_size * 0.5:
                    chunk_text = chunk_text[:last_period + 1]
                    end = start + last_period + 1
            
            chunk_metadata = {
                **(metadata or {}),
                "chunk_index": chunk_index,
                "chunk_start": start,
                "chunk_end": end
            }
            
            chunks.append(Document(
                id=None,
                content=chunk_text.strip(),
                metadata=chunk_metadata
            ))
            
            start = end - self.chunk_overlap
            chunk_index += 1
        
        return chunks
    
    def _article_chunk(
        self,
        text: str,
        metadata: Dict = None
    ) -> List[Document]:
        """
        Chunk by Vietnamese legal articles (Điều).
        
        Preserves legal structure:
        - Each Điều becomes a chunk
        - Long Điều are split by Khoản
        """
        import re
        
        chunks = []
        
        # Pattern for Điều
        article_pattern = r'(Điều\s+\d+[a-z]?\..*?)(?=Điều\s+\d+[a-z]?\.|$)'
        articles = re.findall(article_pattern, text, re.DOTALL | re.IGNORECASE)
        
        for i, article in enumerate(articles):
            article = article.strip()
            
            # Extract article number
            article_match = re.match(r'Điều\s+(\d+[a-z]?)\.', article)
            article_num = article_match.group(1) if article_match else str(i + 1)
            
            if len(article) <= self.chunk_size:
                # Article fits in one chunk
                chunk_metadata = {
                    **(metadata or {}),
                    "article": f"Điều {article_num}",
                    "chunk_type": "article"
                }
                
                chunks.append(Document(
                    id=None,
                    content=article,
                    metadata=chunk_metadata
                ))
            else:
                # Split long article by Khoản
                clause_chunks = self._split_by_clause(article, article_num, metadata)
                chunks.extend(clause_chunks)
        
        # Handle text before first Điều (preamble)
        first_article = re.search(r'Điều\s+\d+', text)
        if first_article and first_article.start() > 100:
            preamble = text[:first_article.start()].strip()
            if preamble:
                chunks.insert(0, Document(
                    id=None,
                    content=preamble,
                    metadata={
                        **(metadata or {}),
                        "chunk_type": "preamble"
                    }
                ))
        
        return chunks
    
    def _split_by_clause(
        self,
        article_text: str,
        article_num: str,
        metadata: Dict = None
    ) -> List[Document]:
        """Split article by Khoản (clauses)."""
        import re
        
        chunks = []
        
        # Pattern for Khoản
        clause_pattern = r'(\d+\.\s+.*?)(?=\d+\.\s+|$)'
        clauses = re.findall(clause_pattern, article_text, re.DOTALL)
        
        if not clauses:
            # No clear clause structure, use fixed chunking
            return self._fixed_chunk(article_text, metadata)
        
        current_chunk = ""
        current_clauses = []
        
        for clause in clauses:
            clause = clause.strip()
            clause_num = re.match(r'(\d+)\.', clause)
            
            if len(current_chunk) + len(clause) <= self.chunk_size:
                current_chunk += "\n" + clause if current_chunk else clause
                if clause_num:
                    current_clauses.append(clause_num.group(1))
            else:
                # Save current chunk
                if current_chunk:
                    chunk_metadata = {
                        **(metadata or {}),
                        "article": f"Điều {article_num}",
                        "clauses": ",".join(current_clauses),
                        "chunk_type": "article_clause"
                    }
                    
                    chunks.append(Document(
                        id=None,
                        content=current_chunk,
                        metadata=chunk_metadata
                    ))
                
                current_chunk = clause
                current_clauses = [clause_num.group(1)] if clause_num else []
        
        # Don't forget last chunk
        if current_chunk:
            chunk_metadata = {
                **(metadata or {}),
                "article": f"Điều {article_num}",
                "clauses": ",".join(current_clauses),
                "chunk_type": "article_clause"
            }
            
            chunks.append(Document(
                id=None,
                content=current_chunk,
                metadata=chunk_metadata
            ))
        
        return chunks
    
    def _semantic_chunk(
        self,
        text: str,
        metadata: Dict = None
    ) -> List[Document]:
        """
        Semantic chunking using sentence embeddings.
        Groups semantically similar sentences together.
        """
        # This requires embedding model - implement with sentence boundaries
        import re
        
        # Split into sentences
        sentences = re.split(r'(?<=[.!?])\s+', text)
        
        chunks = []
        current_chunk = []
        current_length = 0
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            if current_length + len(sentence) <= self.chunk_size:
                current_chunk.append(sentence)
                current_length += len(sentence)
            else:
                if current_chunk:
                    chunk_text = " ".join(current_chunk)
                    chunks.append(Document(
                        id=None,
                        content=chunk_text,
                        metadata={
                            **(metadata or {}),
                            "chunk_type": "semantic",
                            "sentence_count": len(current_chunk)
                        }
                    ))
                
                current_chunk = [sentence]
                current_length = len(sentence)
        
        # Last chunk
        if current_chunk:
            chunk_text = " ".join(current_chunk)
            chunks.append(Document(
                id=None,
                content=chunk_text,
                metadata={
                    **(metadata or {}),
                    "chunk_type": "semantic",
                    "sentence_count": len(current_chunk)
                }
            ))
        
        return chunks


# Usage Example
if __name__ == "__main__":
    # Initialize database
    db = EnvironmentalRegulationDB(
        collection_name="env_regulations_demo",
        persist_directory="./demo_chroma_db"
    )
    
    # Sample documents
    sample_docs = [
        Document(
            id="qcvn40_dieu5",
            content="""
            Điều 5. Giá trị giới hạn các thông số ô nhiễm trong nước thải công nghiệp
            1. Giá trị giới hạn các thông số ô nhiễm trong nước thải công nghiệp khi 
            xả vào nguồn tiếp nhận được quy định tại Bảng 1.
            2. Nước thải công nghiệp có giá trị các thông số ô nhiễm bằng hoặc nhỏ hơn 
            giá trị quy định tại cột A, Bảng 1 được xả vào các nguồn tiếp nhận là nguồn 
            nước được dùng cho mục đích cấp nước sinh hoạt.
            """,
            metadata={
                "doc_type": "qcvn",
                "doc_number": "QCVN 40:2011/BTNMT",
                "domain": "water_quality",
                "year": 2011,
                "status": "active",
                "article": "Điều 5"
            }
        ),
        Document(
            id="nd08_dieu28",
            content="""
            Điều 28. Đối tượng phải có giấy phép môi trường
            1. Dự án đầu tư nhóm I quy định tại khoản 3 Điều 28 Luật Bảo vệ môi trường.
            2. Dự án đầu tư nhóm II quy định tại khoản 4 Điều 28 Luật Bảo vệ môi trường.
            3. Cơ sở sản xuất, kinh doanh, dịch vụ hoạt động trước ngày Luật này có hiệu lực
            thuộc đối tượng phải có giấy phép môi trường theo quy định của Luật này.
            """,
            metadata={
                "doc_type": "nghi_dinh",
                "doc_number": "Nghị định 08/2022/NĐ-CP",
                "domain": "permit",
                "year": 2022,
                "status": "active",
                "article": "Điều 28"
            }
        ),
    ]
    
    # Add documents
    db.add_documents(sample_docs)
    
    # Search
    print("\n=== Semantic Search ===")
    results = db.search("quy định về xả nước thải công nghiệp", n_results=3)
    for r in results:
        print(f"Score: {r.score:.4f} | {r.metadata['doc_number']} - {r.metadata.get('article', 'N/A')}")
    
    # Search with filter
    print("\n=== Filtered Search (water_quality only) ===")
    results = db.search_by_domain("giới hạn thông số ô nhiễm", domain="water_quality")
    for r in results:
        print(f"Score: {r.score:.4f} | {r.content[:100]}...")
    
    # Get stats
    print("\n=== Database Stats ===")
    stats = db.get_stats()
    print(json.dumps(stats, indent=2, ensure_ascii=False))
```

### Ngày 5-6: Building Search API

#### 3.1 FastAPI Search Service

```python
# ============================================
# FASTAPI SEARCH SERVICE
# ============================================

from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import datetime
import uvicorn

# Initialize FastAPI app
app = FastAPI(
    title="Environmental Regulation Search API",
    description="Semantic search API for Vietnamese environmental regulations",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==================== MODELS ====================

class SearchQuery(BaseModel):
    """Search query model."""
    query: str = Field(..., min_length=1, max_length=500, description="Search query text")
    n_results: int = Field(default=5, ge=1, le=20, description="Number of results")
    domain: Optional[str] = Field(default=None, description="Filter by domain")
    doc_type: Optional[str] = Field(default=None, description="Filter by document type")
    year_from: Optional[int] = Field(default=None, description="Filter by year (from)")
    year_to: Optional[int] = Field(default=None, description="Filter by year (to)")
    status: Optional[str] = Field(default="active", description="Document status filter")
    use_hybrid: bool = Field(default=False, description="Use hybrid search")

class SearchResultItem(BaseModel):
    """Single search result."""
    id: str
    content: str
    score: float
    metadata: Dict[str, Any]
    highlights: Optional[List[str]] = None

class SearchResponse(BaseModel):
    """Search response model."""
    query: str
    total_results: int
    results: List[SearchResultItem]
    search_time_ms: float
    filters_applied: Dict[str, Any]

class DocumentInput(BaseModel):
    """Input for adding documents."""
    content: str = Field(..., min_length=10)
    metadata: Dict[str, Any]
    doc_id: Optional[str] = None

class StatsResponse(BaseModel):
    """Database statistics response."""
    total_documents: int
    domains: Dict[str, int]
    doc_types: Dict[str, int]
    years: Dict[str, int]

# ==================== DEPENDENCIES ====================

# Global database instance
_db: Optional[EnvironmentalRegulationDB] = None

def get_db() -> EnvironmentalRegulationDB:
    """Dependency for database access."""
    global _db
    if _db is None:
        _db = EnvironmentalRegulationDB(
            collection_name="environmental_regulations",
            persist_directory="./chroma_db"
        )
    return _db

# ==================== ENDPOINTS ====================

@app.get("/", tags=["Health"])
async def root():
    """Root endpoint."""
    return {
        "service": "Environmental Regulation Search API",
        "version": "1.0.0",
        "status": "healthy"
    }

@app.get("/health", tags=["Health"])
async def health_check(db: EnvironmentalRegulationDB = Depends(get_db)):
    """Health check endpoint."""
    return {
        "status": "healthy",
        "database_connected": True,
        "document_count": db.count(),
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/search", response_model=SearchResponse, tags=["Search"])
async def search(
    query: SearchQuery,
    db: EnvironmentalRegulationDB = Depends(get_db)
):
    """
    Semantic search for environmental regulations.
    
    Supports:
    - Semantic search (default)
    - Hybrid search (semantic + keyword)
    - Metadata filtering
    """
    import time
    start_time = time.perf_counter()
    
    # Build filter
    where_filter = {}
    filters_applied = {}
    
    if query.domain:
        where_filter["domain"] = query.domain
        filters_applied["domain"] = query.domain
    
    if query.doc_type:
        where_filter["doc_type"] = query.doc_type
        filters_applied["doc_type"] = query.doc_type
    
    if query.status:
        where_filter["status"] = query.status
        filters_applied["status"] = query.status
    
    if query.year_from or query.year_to:
        year_conditions = []
        if query.year_from:
            year_conditions.append({"year": {"$gte": query.year_from}})
            filters_applied["year_from"] = query.year_from
        if query.year_to:
            year_conditions.append({"year": {"$lte": query.year_to}})
            filters_applied["year_to"] = query.year_to
        
        if len(year_conditions) == 1:
            where_filter.update(year_conditions[0])
        else:
            where_filter["$and"] = year_conditions
    
    # Execute search
    try:
        if query.use_hybrid:
            results = db.hybrid_search(
                query=query.query,
                n_results=query.n_results,
                where=where_filter if where_filter else None
            )
        else:
            results = db.search(
                query=query.query,
                n_results=query.n_results,
                where=where_filter if where_filter else None
            )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")
    
    search_time = (time.perf_counter() - start_time) * 1000
    
    # Format results
    result_items = [
        SearchResultItem(
            id=r.id,
            content=r.content,
            score=r.score,
            metadata=r.metadata,
            highlights=_extract_highlights(r.content, query.query)
        )
        for r in results
    ]
    
    return SearchResponse(
        query=query.query,
        total_results=len(result_items),
        results=result_items,
        search_time_ms=search_time,
        filters_applied=filters_applied
    )

@app.get("/search/simple", response_model=SearchResponse, tags=["Search"])
async def simple_search(
    q: str = Query(..., min_length=1, description="Search query"),
    n: int = Query(default=5, ge=1, le=20, description="Number of results"),
    domain: Optional[str] = Query(default=None, description="Filter by domain"),
    db: EnvironmentalRegulationDB = Depends(get_db)
):
    """Simple GET endpoint for search."""
    query = SearchQuery(query=q, n_results=n, domain=domain)
    return await search(query, db)

@app.post("/documents", tags=["Documents"])
async def add_document(
    doc: DocumentInput,
    db: EnvironmentalRegulationDB = Depends(get_db)
):
    """Add a new document to the database."""
    try:
        doc_id = db.add_document(
            content=doc.content,
            metadata=doc.metadata,
            doc_id=doc.doc_id
        )
        return {"status": "success", "document_id": doc_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to add document: {str(e)}")

@app.post("/documents/batch", tags=["Documents"])
async def add_documents_batch(
    docs: List[DocumentInput],
    db: EnvironmentalRegulationDB = Depends(get_db)
):
    """Add multiple documents."""
    try:
        documents = [
            Document(id=d.doc_id, content=d.content, metadata=d.metadata)
            for d in docs
        ]
        doc_ids = db.add_documents(documents)
        return {"status": "success", "documents_added": len(doc_ids), "ids": doc_ids}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to add documents: {str(e)}")

@app.get("/documents/{doc_id}", tags=["Documents"])
async def get_document(
    doc_id: str,
    db: EnvironmentalRegulationDB = Depends(get_db)
):
    """Get a document by ID."""
    doc = db.get_document(doc_id)
    if doc is None:
        raise HTTPException(status_code=404, detail="Document not found")
    
    return {
        "id": doc.id,
        "content": doc.content,
        "metadata": doc.metadata
    }

@app.delete("/documents/{doc_id}", tags=["Documents"])
async def delete_document(
    doc_id: str,
    db: EnvironmentalRegulationDB = Depends(get_db)
):
    """Delete a document by ID."""
    try:
        db.delete_document(doc_id)
        return {"status": "success", "deleted_id": doc_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete: {str(e)}")

@app.get("/stats", response_model=StatsResponse, tags=["Stats"])
async def get_stats(db: EnvironmentalRegulationDB = Depends(get_db)):
    """Get database statistics."""
    stats = db.get_stats()
    return StatsResponse(**stats)

@app.get("/domains", tags=["Metadata"])
async def get_domains():
    """Get available domains."""
    return {
        "domains": [
            {"id": "air_quality", "name": "Chất lượng không khí"},
            {"id": "water_quality", "name": "Chất lượng nước"},
            {"id": "waste_management", "name": "Quản lý chất thải"},
            {"id": "eia", "name": "Đánh giá tác động môi trường"},
            {"id": "permit", "name": "Giấy phép môi trường"},
            {"id": "monitoring", "name": "Quan trắc môi trường"},
            {"id": "penalty", "name": "Xử phạt vi phạm"}
        ]
    }

@app.get("/doc-types", tags=["Metadata"])
async def get_doc_types():
    """Get available document types."""
    return {
        "doc_types": [
            {"id": "luat", "name": "Luật"},
            {"id": "nghi_dinh", "name": "Nghị định"},
            {"id": "thong_tu", "name": "Thông tư"},
            {"id": "qcvn", "name": "QCVN"},
            {"id": "tcvn", "name": "TCVN"},
            {"id": "quyet_dinh", "name": "Quyết định"}
        ]
    }

# ==================== HELPER FUNCTIONS ====================

def _extract_highlights(
    content: str,
    query: str,
    context_chars: int = 50
) -> List[str]:
    """Extract highlighted snippets from content."""
    highlights = []
    query_words = query.lower().split()
    content_lower = content.lower()
    
    for word in query_words:
        idx = content_lower.find(word)
        if idx != -1:
            start = max(0, idx - context_chars)
            end = min(len(content), idx + len(word) + context_chars)
            
            snippet = content[start:end]
            if start > 0:
                snippet = "..." + snippet
            if end < len(content):
                snippet = snippet + "..."
            
            highlights.append(snippet)
    
    return highlights[:3]  # Return max 3 highlights

# ==================== MAIN ====================

if __name__ == "__main__":
    uvicorn.run(
        "search_api:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
```

#### 3.2 Streamlit Demo UI

```python
# ============================================
# STREAMLIT SEARCH DEMO
# ============================================

import streamlit as st
import requests
from typing import Dict, List
import json

# Configuration
API_URL = "http://localhost:8000"

# Page config
st.set_page_config(
    page_title="Environmental Regulation Search",
    page_icon="🔍",
    layout="wide"
)

# Title
st.title("🔍 Tìm kiếm Quy định Môi trường Việt Nam")
st.markdown("*Semantic search engine for Vietnamese environmental regulations*")

# Sidebar filters
st.sidebar.header("🔧 Bộ lọc")

# Domain filter
domains = {
    "Tất cả": None,
    "Chất lượng không khí": "air_quality",
    "Chất lượng nước": "water_quality",
    "Quản lý chất thải": "waste_management",
    "Đánh giá tác động môi trường": "eia",
    "Giấy phép môi trường": "permit",
    "Quan trắc môi trường": "monitoring"
}
selected_domain = st.sidebar.selectbox(
    "Lĩnh vực",
    options=list(domains.keys())
)

# Document type filter
doc_types = {
    "Tất cả": None,
    "Luật": "luat",
    "Nghị định": "nghi_dinh",
    "Thông tư": "thong_tu",
    "QCVN": "qcvn",
    "TCVN": "tcvn"
}
selected_doc_type = st.sidebar.selectbox(
    "Loại văn bản",
    options=list(doc_types.keys())
)

# Year range
col1, col2 = st.sidebar.columns(2)
year_from = col1.number_input("Từ năm", min_value=1990, max_value=2024, value=2010)
year_to = col2.number_input("Đến năm", min_value=1990, max_value=2024, value=2024)

# Number of results
n_results = st.sidebar.slider("Số kết quả", min_value=1, max_value=20, value=5)

# Hybrid search toggle
use_hybrid = st.sidebar.checkbox("Sử dụng Hybrid Search", value=False)

# Search box
query = st.text_input(
    "Nhập nội dung tìm kiếm",
    placeholder="VD: quy định về xả nước thải công nghiệp",
    key="search_query"
)

# Search button
if st.button("🔍 Tìm kiếm", type="primary") or query:
    if query:
        # Build request
        search_params = {
            "query": query,
            "n_results": n_results,
            "use_hybrid": use_hybrid
        }
        
        if domains[selected_domain]:
            search_params["domain"] = domains[selected_domain]
        
        if doc_types[selected_doc_type]:
            search_params["doc_type"] = doc_types[selected_doc_type]
        
        search_params["year_from"] = year_from
        search_params["year_to"] = year_to
        
        # Execute search
        try:
            with st.spinner("Đang tìm kiếm..."):
                response = requests.post(
                    f"{API_URL}/search",
                    json=search_params
                )
                response.raise_for_status()
                results = response.json()
            
            # Display results
            st.markdown(f"### Kết quả tìm kiếm ({results['total_results']} kết quả)")
            st.caption(f"Thời gian: {results['search_time_ms']:.2f}ms")
            
            if results['filters_applied']:
                st.info(f"Bộ lọc: {json.dumps(results['filters_applied'], ensure_ascii=False)}")
            
            for i, result in enumerate(results['results'], 1):
                with st.expander(
                    f"**{i}. {result['metadata'].get('doc_number', 'N/A')}** - "
                    f"{result['metadata'].get('article', '')} "
                    f"(Score: {result['score']:.4f})",
                    expanded=(i <= 3)
                ):
                    # Metadata
                    cols = st.columns(4)
                    cols[0].metric("Loại văn bản", result['metadata'].get('doc_type', 'N/A'))
                    cols[1].metric("Lĩnh vực", result['metadata'].get('domain', 'N/A'))
                    cols[2].metric("Năm", result['metadata'].get('year', 'N/A'))
                    cols[3].metric("Trạng thái", result['metadata'].get('status', 'N/A'))
                    
                    # Content
                    st.markdown("**Nội dung:**")
                    st.markdown(result['content'])
                    
                    # Highlights
                    if result.get('highlights'):
                        st.markdown("**Đoạn trích:**")
                        for h in result['highlights']:
                            st.markdown(f"> {h}")
            
        except requests.exceptions.ConnectionError:
            st.error("Không thể kết nối đến API. Vui lòng kiểm tra server.")
        except Exception as e:
            st.error(f"Lỗi: {str(e)}")
    else:
        st.warning("Vui lòng nhập nội dung tìm kiếm")

# Stats section
st.sidebar.markdown("---")
st.sidebar.header("📊 Thống kê")

try:
    stats_response = requests.get(f"{API_URL}/stats")
    if stats_response.status_code == 200:
        stats = stats_response.json()
        st.sidebar.metric("Tổng số văn bản", stats['total_documents'])
        
        with st.sidebar.expander("Chi tiết"):
            st.json(stats)
except:
    st.sidebar.warning("Không thể tải thống kê")

# Footer
st.markdown("---")
st.markdown(
    """
    <div style='text-align: center'>
        <p>Built with ChromaDB, OpenAI Embeddings, FastAPI & Streamlit</p>
        <p>Environmental AI Engineering Portfolio - Project 1</p>
    </div>
    """,
    unsafe_allow_html=True
)
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Embedding Comparison (Ngày 1-2)

```
🎯 Mục tiêu: So sánh các embedding models cho Vietnamese text

📋 Yêu cầu:
1. Implement 3 embedding models (OpenAI, HuggingFace, VinAI)
2. Benchmark với Vietnamese environmental text
3. Đánh giá semantic similarity accuracy
4. So sánh latency và cost

📁 Deliverables:
- src/embeddings/model_comparison.py
- notebooks/embedding_benchmark.ipynb
- Report: Model comparison results
```

### Bài tập 2: ChromaDB Implementation (Ngày 3-4)

```
🎯 Mục tiêu: Xây dựng vector database cho environmental regulations

📋 Yêu cầu:
1. Setup ChromaDB với persistence
2. Implement document chunking strategies
3. Add filtering và hybrid search
4. Load 50+ sample documents

📁 Deliverables:
- src/database/chroma_db.py
- src/processing/chunker.py
- Sample data loaded
```

### Bài tập 3: Search API (Ngày 5-7)

```
🎯 Mục tiêu: Xây dựng Search API hoàn chỉnh

📋 Yêu cầu:
1. FastAPI với full CRUD operations
2. Search endpoints với filtering
3. Streamlit demo UI
4. API documentation (OpenAPI/Swagger)

📁 Deliverables:
- src/api/search_api.py
- src/ui/streamlit_demo.py
- API documentation
- **PROJECT 1 Complete**: Semantic Search System
```

---

## ✅ CHECKLIST TUẦN 3

### Kiến thức đã học
- [ ] Embeddings và vector representations
- [ ] Similarity metrics (cosine, euclidean, dot product)
- [ ] Vector database concepts và operations
- [ ] Document chunking strategies
- [ ] Hybrid search techniques

### Skills thực hành
- [ ] Sử dụng OpenAI/HuggingFace embeddings
- [ ] Setup và query ChromaDB
- [ ] Implement semantic search
- [ ] Build REST API với FastAPI
- [ ] Create demo UI với Streamlit

### Deliverables
- [ ] Embedding comparison benchmark
- [ ] ChromaDB implementation
- [ ] Search API với full features
- [ ] Streamlit demo UI
- [ ] **PROJECT 1**: Environmental Regulation Search Engine

---

*Hoàn thành Tuần 3 để tiếp tục sang Tuần 4: LLM Fundamentals & Prompt Engineering*
