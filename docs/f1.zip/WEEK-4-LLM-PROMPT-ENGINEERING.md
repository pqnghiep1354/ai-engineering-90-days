# 📅 TUẦN 4: LLM FUNDAMENTALS & PROMPT ENGINEERING

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Thành thạo LLM integration và prompt engineering |
| **Output** | Environmental Q&A System với RAG foundation |
| **Độ khó** | ⭐⭐⭐ Trung bình - Khó |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu LLM architectures và capabilities
- [ ] Nắm vững các kỹ thuật prompt engineering
- [ ] Hiểu token limits, pricing, và rate limiting
- [ ] Biết cách đánh giá LLM outputs

### Kỹ năng (Skills)
- [ ] Sử dụng OpenAI và Anthropic APIs
- [ ] Viết effective prompts cho various tasks
- [ ] Implement streaming responses
- [ ] Handle errors và retries

### Ứng dụng (Application)
- [ ] Xây dựng Q&A system cho environmental regulations
- [ ] Create domain-specific prompts cho Vietnamese legal text
- [ ] Integrate LLM với semantic search (RAG foundation)

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: LLM Fundamentals

#### 1.1 LLM Landscape

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         LARGE LANGUAGE MODELS (2024)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────────┐│
│  │                           COMMERCIAL MODELS                              ││
│  ├─────────────────────────────────────────────────────────────────────────┤│
│  │                                                                          ││
│  │  OpenAI                    Anthropic                 Google              ││
│  │  ┌──────────────┐          ┌──────────────┐          ┌──────────────┐   ││
│  │  │ GPT-4 Turbo  │          │ Claude 3 Opus│          │ Gemini Pro   │   ││
│  │  │ GPT-4o       │          │ Claude 3.5   │          │ Gemini Ultra │   ││
│  │  │ GPT-3.5 Turbo│          │   Sonnet     │          │              │   ││
│  │  └──────────────┘          └──────────────┘          └──────────────┘   ││
│  │                                                                          ││
│  └─────────────────────────────────────────────────────────────────────────┘│
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────────┐│
│  │                           OPEN SOURCE MODELS                             ││
│  ├─────────────────────────────────────────────────────────────────────────┤│
│  │                                                                          ││
│  │  Meta               Mistral              Others                          ││
│  │  ┌──────────────┐   ┌──────────────┐    ┌──────────────┐                ││
│  │  │ Llama 3 70B  │   │ Mixtral 8x7B │    │ Qwen 72B     │                ││
│  │  │ Llama 3 8B   │   │ Mistral 7B   │    │ Yi 34B       │                ││
│  │  └──────────────┘   └──────────────┘    └──────────────┘                ││
│  │                                                                          ││
│  └─────────────────────────────────────────────────────────────────────────┘│
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 1.2 Model Comparison

```python
# ============================================
# LLM MODEL COMPARISON AND SELECTION
# ============================================

from dataclasses import dataclass
from typing import Dict, List, Optional
from enum import Enum

class ModelCapability(Enum):
    """Model capabilities."""
    REASONING = "reasoning"
    CODING = "coding"
    ANALYSIS = "analysis"
    CREATIVE = "creative"
    MULTILINGUAL = "multilingual"
    LONG_CONTEXT = "long_context"
    FAST = "fast"
    CHEAP = "cheap"

@dataclass
class LLMModel:
    """LLM Model specification."""
    name: str
    provider: str
    context_window: int
    max_output: int
    input_cost_per_1m: float  # USD per 1M tokens
    output_cost_per_1m: float
    capabilities: List[ModelCapability]
    vietnamese_quality: str  # "excellent", "good", "fair", "poor"
    best_for: List[str]

# Model Registry
LLM_MODELS = {
    # OpenAI Models
    "gpt-4-turbo-preview": LLMModel(
        name="gpt-4-turbo-preview",
        provider="openai",
        context_window=128000,
        max_output=4096,
        input_cost_per_1m=10.0,
        output_cost_per_1m=30.0,
        capabilities=[
            ModelCapability.REASONING,
            ModelCapability.CODING,
            ModelCapability.ANALYSIS,
            ModelCapability.LONG_CONTEXT
        ],
        vietnamese_quality="good",
        best_for=["complex reasoning", "code generation", "analysis"]
    ),
    "gpt-4o": LLMModel(
        name="gpt-4o",
        provider="openai",
        context_window=128000,
        max_output=4096,
        input_cost_per_1m=5.0,
        output_cost_per_1m=15.0,
        capabilities=[
            ModelCapability.REASONING,
            ModelCapability.CODING,
            ModelCapability.FAST,
            ModelCapability.MULTILINGUAL
        ],
        vietnamese_quality="good",
        best_for=["general tasks", "balanced performance"]
    ),
    "gpt-3.5-turbo": LLMModel(
        name="gpt-3.5-turbo",
        provider="openai",
        context_window=16385,
        max_output=4096,
        input_cost_per_1m=0.5,
        output_cost_per_1m=1.5,
        capabilities=[
            ModelCapability.FAST,
            ModelCapability.CHEAP
        ],
        vietnamese_quality="fair",
        best_for=["simple tasks", "high volume", "cost-sensitive"]
    ),
    
    # Anthropic Models
    "claude-3-opus-20240229": LLMModel(
        name="claude-3-opus-20240229",
        provider="anthropic",
        context_window=200000,
        max_output=4096,
        input_cost_per_1m=15.0,
        output_cost_per_1m=75.0,
        capabilities=[
            ModelCapability.REASONING,
            ModelCapability.ANALYSIS,
            ModelCapability.LONG_CONTEXT
        ],
        vietnamese_quality="good",
        best_for=["complex analysis", "long documents", "research"]
    ),
    "claude-3-5-sonnet-20241022": LLMModel(
        name="claude-3-5-sonnet-20241022",
        provider="anthropic",
        context_window=200000,
        max_output=8192,
        input_cost_per_1m=3.0,
        output_cost_per_1m=15.0,
        capabilities=[
            ModelCapability.REASONING,
            ModelCapability.CODING,
            ModelCapability.ANALYSIS,
            ModelCapability.FAST
        ],
        vietnamese_quality="excellent",
        best_for=["coding", "analysis", "general tasks"]
    ),
    "claude-3-haiku-20240307": LLMModel(
        name="claude-3-haiku-20240307",
        provider="anthropic",
        context_window=200000,
        max_output=4096,
        input_cost_per_1m=0.25,
        output_cost_per_1m=1.25,
        capabilities=[
            ModelCapability.FAST,
            ModelCapability.CHEAP,
            ModelCapability.LONG_CONTEXT
        ],
        vietnamese_quality="fair",
        best_for=["simple tasks", "classification", "extraction"]
    )
}

class ModelSelector:
    """
    Intelligent model selector based on task requirements.
    """
    
    @staticmethod
    def select_model(
        task_type: str,
        budget_sensitive: bool = False,
        requires_vietnamese: bool = True,
        max_context_needed: int = 4000,
        speed_priority: bool = False
    ) -> LLMModel:
        """
        Select appropriate model based on requirements.
        
        Args:
            task_type: Type of task (reasoning, coding, analysis, simple)
            budget_sensitive: Prioritize cost
            requires_vietnamese: Need good Vietnamese support
            max_context_needed: Maximum context window needed
            speed_priority: Prioritize speed
        
        Returns:
            Selected LLMModel
        """
        candidates = list(LLM_MODELS.values())
        
        # Filter by context window
        candidates = [m for m in candidates if m.context_window >= max_context_needed]
        
        # Filter by Vietnamese quality if required
        if requires_vietnamese:
            candidates = [m for m in candidates if m.vietnamese_quality in ["excellent", "good"]]
        
        # Filter by budget
        if budget_sensitive:
            # Sort by total cost (weighted average)
            candidates.sort(key=lambda m: (m.input_cost_per_1m + m.output_cost_per_1m) / 2)
            candidates = candidates[:3]  # Keep top 3 cheapest
        
        # Filter by speed
        if speed_priority:
            candidates = [m for m in candidates if ModelCapability.FAST in m.capabilities]
        
        # Select based on task type
        task_capability_map = {
            "reasoning": ModelCapability.REASONING,
            "coding": ModelCapability.CODING,
            "analysis": ModelCapability.ANALYSIS,
            "simple": ModelCapability.CHEAP
        }
        
        required_capability = task_capability_map.get(task_type)
        
        if required_capability:
            matching = [m for m in candidates if required_capability in m.capabilities]
            if matching:
                candidates = matching
        
        # Return best candidate (first after filtering)
        return candidates[0] if candidates else LLM_MODELS["gpt-4o"]
    
    @staticmethod
    def estimate_cost(
        model: LLMModel,
        input_tokens: int,
        output_tokens: int
    ) -> float:
        """Estimate API cost for given token counts."""
        input_cost = (input_tokens / 1_000_000) * model.input_cost_per_1m
        output_cost = (output_tokens / 1_000_000) * model.output_cost_per_1m
        return input_cost + output_cost


# Usage example
selector = ModelSelector()
model = selector.select_model(
    task_type="analysis",
    requires_vietnamese=True,
    budget_sensitive=False
)
print(f"Selected model: {model.name}")
print(f"Vietnamese quality: {model.vietnamese_quality}")
print(f"Estimated cost for 10K in/5K out: ${selector.estimate_cost(model, 10000, 5000):.4f}")
```

#### 1.3 LLM Client Implementation

```python
# ============================================
# UNIFIED LLM CLIENT
# ============================================

from abc import ABC, abstractmethod
from typing import List, Dict, Optional, Generator, AsyncGenerator
from dataclasses import dataclass
import asyncio
import time
import json

@dataclass
class Message:
    """Chat message structure."""
    role: str  # "system", "user", "assistant"
    content: str

@dataclass
class LLMResponse:
    """LLM response structure."""
    content: str
    model: str
    input_tokens: int
    output_tokens: int
    total_tokens: int
    latency_ms: float
    finish_reason: str

class BaseLLMClient(ABC):
    """Abstract base class for LLM clients."""
    
    @abstractmethod
    def complete(self, messages: List[Message], **kwargs) -> LLMResponse:
        """Synchronous completion."""
        pass
    
    @abstractmethod
    async def acomplete(self, messages: List[Message], **kwargs) -> LLMResponse:
        """Asynchronous completion."""
        pass
    
    @abstractmethod
    def stream(self, messages: List[Message], **kwargs) -> Generator[str, None, None]:
        """Streaming completion."""
        pass


class OpenAIClient(BaseLLMClient):
    """OpenAI API client with advanced features."""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        default_model: str = "gpt-4-turbo-preview",
        default_temperature: float = 0.7,
        default_max_tokens: int = 2000,
        timeout: int = 60,
        max_retries: int = 3
    ):
        from openai import OpenAI, AsyncOpenAI
        
        self.client = OpenAI(api_key=api_key, timeout=timeout)
        self.async_client = AsyncOpenAI(api_key=api_key, timeout=timeout)
        
        self.default_model = default_model
        self.default_temperature = default_temperature
        self.default_max_tokens = default_max_tokens
        self.max_retries = max_retries
    
    def _format_messages(self, messages: List[Message]) -> List[Dict]:
        """Format messages for API."""
        return [{"role": m.role, "content": m.content} for m in messages]
    
    def complete(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Synchronous completion with retry logic."""
        
        start_time = time.perf_counter()
        
        for attempt in range(self.max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=model or self.default_model,
                    messages=self._format_messages(messages),
                    temperature=temperature or self.default_temperature,
                    max_tokens=max_tokens or self.default_max_tokens,
                    **kwargs
                )
                
                latency = (time.perf_counter() - start_time) * 1000
                
                return LLMResponse(
                    content=response.choices[0].message.content,
                    model=response.model,
                    input_tokens=response.usage.prompt_tokens,
                    output_tokens=response.usage.completion_tokens,
                    total_tokens=response.usage.total_tokens,
                    latency_ms=latency,
                    finish_reason=response.choices[0].finish_reason
                )
                
            except Exception as e:
                if attempt == self.max_retries - 1:
                    raise
                time.sleep(2 ** attempt)  # Exponential backoff
    
    async def acomplete(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Asynchronous completion."""
        
        start_time = time.perf_counter()
        
        response = await self.async_client.chat.completions.create(
            model=model or self.default_model,
            messages=self._format_messages(messages),
            temperature=temperature or self.default_temperature,
            max_tokens=max_tokens or self.default_max_tokens,
            **kwargs
        )
        
        latency = (time.perf_counter() - start_time) * 1000
        
        return LLMResponse(
            content=response.choices[0].message.content,
            model=response.model,
            input_tokens=response.usage.prompt_tokens,
            output_tokens=response.usage.completion_tokens,
            total_tokens=response.usage.total_tokens,
            latency_ms=latency,
            finish_reason=response.choices[0].finish_reason
        )
    
    def stream(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> Generator[str, None, None]:
        """Streaming completion."""
        
        stream = self.client.chat.completions.create(
            model=model or self.default_model,
            messages=self._format_messages(messages),
            temperature=temperature or self.default_temperature,
            max_tokens=max_tokens or self.default_max_tokens,
            stream=True,
            **kwargs
        )
        
        for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
    
    async def astream(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        **kwargs
    ) -> AsyncGenerator[str, None]:
        """Async streaming completion."""
        
        stream = await self.async_client.chat.completions.create(
            model=model or self.default_model,
            messages=self._format_messages(messages),
            stream=True,
            **kwargs
        )
        
        async for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content


class AnthropicClient(BaseLLMClient):
    """Anthropic Claude API client."""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        default_model: str = "claude-3-5-sonnet-20241022",
        default_temperature: float = 0.7,
        default_max_tokens: int = 2000,
        timeout: int = 60
    ):
        from anthropic import Anthropic, AsyncAnthropic
        
        self.client = Anthropic(api_key=api_key, timeout=timeout)
        self.async_client = AsyncAnthropic(api_key=api_key, timeout=timeout)
        
        self.default_model = default_model
        self.default_temperature = default_temperature
        self.default_max_tokens = default_max_tokens
    
    def _extract_system_message(self, messages: List[Message]) -> tuple:
        """Extract system message from messages list."""
        system_msg = None
        other_msgs = []
        
        for msg in messages:
            if msg.role == "system":
                system_msg = msg.content
            else:
                other_msgs.append({"role": msg.role, "content": msg.content})
        
        return system_msg, other_msgs
    
    def complete(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Synchronous completion."""
        
        start_time = time.perf_counter()
        
        system_msg, chat_msgs = self._extract_system_message(messages)
        
        response = self.client.messages.create(
            model=model or self.default_model,
            messages=chat_msgs,
            system=system_msg,
            temperature=temperature or self.default_temperature,
            max_tokens=max_tokens or self.default_max_tokens,
            **kwargs
        )
        
        latency = (time.perf_counter() - start_time) * 1000
        
        return LLMResponse(
            content=response.content[0].text,
            model=response.model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            total_tokens=response.usage.input_tokens + response.usage.output_tokens,
            latency_ms=latency,
            finish_reason=response.stop_reason
        )
    
    async def acomplete(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Asynchronous completion."""
        
        start_time = time.perf_counter()
        
        system_msg, chat_msgs = self._extract_system_message(messages)
        
        response = await self.async_client.messages.create(
            model=model or self.default_model,
            messages=chat_msgs,
            system=system_msg,
            temperature=temperature or self.default_temperature,
            max_tokens=max_tokens or self.default_max_tokens,
            **kwargs
        )
        
        latency = (time.perf_counter() - start_time) * 1000
        
        return LLMResponse(
            content=response.content[0].text,
            model=response.model,
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens,
            total_tokens=response.usage.input_tokens + response.usage.output_tokens,
            latency_ms=latency,
            finish_reason=response.stop_reason
        )
    
    def stream(
        self,
        messages: List[Message],
        model: Optional[str] = None,
        **kwargs
    ) -> Generator[str, None, None]:
        """Streaming completion."""
        
        system_msg, chat_msgs = self._extract_system_message(messages)
        
        with self.client.messages.stream(
            model=model or self.default_model,
            messages=chat_msgs,
            system=system_msg,
            max_tokens=self.default_max_tokens,
            **kwargs
        ) as stream:
            for text in stream.text_stream:
                yield text


class UnifiedLLMClient:
    """
    Unified client supporting multiple LLM providers.
    Includes automatic fallback and load balancing.
    """
    
    def __init__(
        self,
        openai_api_key: Optional[str] = None,
        anthropic_api_key: Optional[str] = None,
        default_provider: str = "openai"
    ):
        self.clients = {}
        
        if openai_api_key:
            self.clients["openai"] = OpenAIClient(api_key=openai_api_key)
        
        if anthropic_api_key:
            self.clients["anthropic"] = AnthropicClient(api_key=anthropic_api_key)
        
        self.default_provider = default_provider
    
    def complete(
        self,
        messages: List[Message],
        provider: Optional[str] = None,
        fallback: bool = True,
        **kwargs
    ) -> LLMResponse:
        """
        Complete with automatic fallback.
        
        Args:
            messages: List of messages
            provider: Provider to use ("openai" or "anthropic")
            fallback: Enable fallback to other provider on failure
            **kwargs: Additional arguments for the API
        
        Returns:
            LLMResponse
        """
        provider = provider or self.default_provider
        
        try:
            client = self.clients.get(provider)
            if client:
                return client.complete(messages, **kwargs)
        except Exception as e:
            if fallback:
                # Try other provider
                for other_provider, other_client in self.clients.items():
                    if other_provider != provider:
                        try:
                            return other_client.complete(messages, **kwargs)
                        except:
                            continue
            raise
        
        raise ValueError(f"No client available for provider: {provider}")


# Usage example
if __name__ == "__main__":
    import os
    
    # Initialize unified client
    client = UnifiedLLMClient(
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        anthropic_api_key=os.getenv("ANTHROPIC_API_KEY")
    )
    
    # Test completion
    messages = [
        Message(role="system", content="Bạn là chuyên gia tư vấn môi trường Việt Nam."),
        Message(role="user", content="QCVN 40:2011 quy định gì về nước thải công nghiệp?")
    ]
    
    response = client.complete(messages, provider="openai")
    
    print(f"Model: {response.model}")
    print(f"Tokens: {response.total_tokens}")
    print(f"Latency: {response.latency_ms:.2f}ms")
    print(f"Response:\n{response.content}")
```

### Ngày 3-4: Prompt Engineering

#### 2.1 Prompt Engineering Framework

```python
# ============================================
# PROMPT ENGINEERING FRAMEWORK
# ============================================

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from string import Template
from enum import Enum
import json

class PromptTechnique(Enum):
    """Prompt engineering techniques."""
    ZERO_SHOT = "zero_shot"
    FEW_SHOT = "few_shot"
    CHAIN_OF_THOUGHT = "chain_of_thought"
    SELF_CONSISTENCY = "self_consistency"
    TREE_OF_THOUGHT = "tree_of_thought"
    REACT = "react"
    ROLE_PLAY = "role_play"

@dataclass
class PromptExample:
    """Example for few-shot prompting."""
    input: str
    output: str
    explanation: Optional[str] = None

@dataclass
class PromptTemplate:
    """Reusable prompt template."""
    name: str
    template: str
    technique: PromptTechnique
    variables: List[str]
    examples: List[PromptExample] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def render(self, **kwargs) -> str:
        """Render template with variables."""
        # Validate all required variables are provided
        missing = set(self.variables) - set(kwargs.keys())
        if missing:
            raise ValueError(f"Missing variables: {missing}")
        
        # Build examples section if few-shot
        if self.technique == PromptTechnique.FEW_SHOT and self.examples:
            examples_text = self._format_examples()
            kwargs['examples'] = examples_text
        
        return Template(self.template).safe_substitute(**kwargs)
    
    def _format_examples(self) -> str:
        """Format examples for few-shot prompting."""
        formatted = []
        for i, ex in enumerate(self.examples, 1):
            example_text = f"Ví dụ {i}:\nInput: {ex.input}\nOutput: {ex.output}"
            if ex.explanation:
                example_text += f"\nGiải thích: {ex.explanation}"
            formatted.append(example_text)
        return "\n\n".join(formatted)


class EnvironmentalPromptLibrary:
    """
    Library of prompts for Vietnamese environmental domain.
    """
    
    # ==================== ZERO-SHOT PROMPTS ====================
    
    REGULATION_QA = PromptTemplate(
        name="regulation_qa",
        technique=PromptTechnique.ZERO_SHOT,
        variables=["question", "context"],
        template="""Bạn là chuyên gia tư vấn pháp luật môi trường Việt Nam với kiến thức sâu về:
- Luật Bảo vệ môi trường 2020
- Nghị định 08/2022/NĐ-CP
- Các QCVN, TCVN về môi trường

Dựa vào ngữ cảnh sau đây, hãy trả lời câu hỏi một cách chính xác và chi tiết.

NGỮCẢNH:
$context

CÂU HỎI:
$question

YÊU CẦU:
1. Trả lời trực tiếp câu hỏi
2. Trích dẫn điều khoản cụ thể (số hiệu văn bản, điều, khoản)
3. Giải thích bằng ngôn ngữ dễ hiểu
4. Nếu thông tin không có trong ngữ cảnh, nói rõ "Thông tin này không có trong tài liệu được cung cấp"

TRẢ LỜI:"""
    )
    
    COMPLIANCE_CHECK = PromptTemplate(
        name="compliance_check",
        technique=PromptTechnique.ZERO_SHOT,
        variables=["parameter", "value", "unit", "source_type", "context"],
        template="""Bạn là chuyên gia kiểm tra tuân thủ môi trường.

THÔNG TIN CẦN KIỂM TRA:
- Thông số: $parameter
- Giá trị đo được: $value $unit
- Loại nguồn thải: $source_type

QUY CHUẨN THAM CHIẾU:
$context

HÃY PHÂN TÍCH:
1. So sánh với giới hạn QCVN (cột A và cột B nếu có)
2. Kết luận: ĐẠT / KHÔNG ĐẠT
3. Nếu không đạt, vượt bao nhiêu % so với quy chuẩn
4. Khuyến nghị (nếu cần)

KẾT QUẢ KIỂM TRA:"""
    )
    
    DOCUMENT_SUMMARY = PromptTemplate(
        name="document_summary",
        technique=PromptTechnique.ZERO_SHOT,
        variables=["document_text", "document_type"],
        template="""Tóm tắt văn bản pháp luật môi trường sau đây.

LOẠI VĂN BẢN: $document_type

NỘI DUNG:
$document_text

YÊU CẦU TÓM TẮT:
1. Thông tin chung (số hiệu, ngày ban hành, cơ quan)
2. Phạm vi điều chỉnh
3. Đối tượng áp dụng
4. Các quy định chính (3-5 điểm)
5. Điểm mới/quan trọng cần lưu ý

TÓM TẮT:"""
    )
    
    # ==================== FEW-SHOT PROMPTS ====================
    
    ENTITY_EXTRACTION = PromptTemplate(
        name="entity_extraction",
        technique=PromptTechnique.FEW_SHOT,
        variables=["text"],
        examples=[
            PromptExample(
                input="Theo Điều 15 Nghị định 08/2022/NĐ-CP, nồng độ BOD5 không vượt quá 30 mg/L.",
                output=json.dumps({
                    "regulations": ["Nghị định 08/2022/NĐ-CP"],
                    "articles": ["Điều 15"],
                    "parameters": ["BOD5"],
                    "values": ["30 mg/L"]
                }, ensure_ascii=False),
                explanation="Trích xuất các thực thể: văn bản pháp luật, điều khoản, thông số môi trường, giá trị"
            ),
            PromptExample(
                input="QCVN 40:2011/BTNMT quy định TSS tối đa 50 mg/L (cột A) và 100 mg/L (cột B).",
                output=json.dumps({
                    "regulations": ["QCVN 40:2011/BTNMT"],
                    "parameters": ["TSS"],
                    "values": ["50 mg/L", "100 mg/L"],
                    "categories": ["cột A", "cột B"]
                }, ensure_ascii=False),
                explanation="Trích xuất QCVN, thông số TSS, và các giá trị theo cột"
            )
        ],
        template="""Trích xuất các thực thể từ văn bản quy định môi trường Việt Nam.

Các loại thực thể cần trích xuất:
- regulations: Số hiệu văn bản (Luật, NĐ, TT, QCVN, TCVN)
- articles: Điều, Khoản, Điểm
- parameters: Thông số môi trường (BOD, COD, TSS, pH, etc.)
- values: Giá trị định lượng kèm đơn vị
- organizations: Tổ chức, cơ quan
- dates: Ngày tháng

$examples

Bây giờ, trích xuất thực thể từ văn bản sau:

INPUT:
$text

OUTPUT (JSON):"""
    )
    
    CLASSIFICATION = PromptTemplate(
        name="classification",
        technique=PromptTechnique.FEW_SHOT,
        variables=["text"],
        examples=[
            PromptExample(
                input="Quy định về nồng độ bụi PM2.5 và PM10 trong không khí xung quanh",
                output="air_quality",
                explanation="Văn bản về chất lượng không khí"
            ),
            PromptExample(
                input="Hướng dẫn xử lý nước thải sinh hoạt đô thị đạt cột B QCVN 14:2008",
                output="water_quality",
                explanation="Văn bản về chất lượng nước"
            ),
            PromptExample(
                input="Thủ tục lập báo cáo đánh giá tác động môi trường cho dự án đầu tư",
                output="eia",
                explanation="Văn bản về đánh giá tác động môi trường"
            )
        ],
        template="""Phân loại văn bản quy định môi trường vào một trong các danh mục sau:
- air_quality: Chất lượng không khí, khí thải
- water_quality: Chất lượng nước, nước thải
- waste_management: Quản lý chất thải rắn, chất thải nguy hại
- eia: Đánh giá tác động môi trường (ĐTM)
- permit: Giấy phép môi trường, thủ tục cấp phép
- monitoring: Quan trắc, giám sát môi trường
- penalty: Xử phạt vi phạm môi trường

$examples

Phân loại văn bản sau:

INPUT:
$text

DANH MỤC (chỉ trả về 1 từ khóa):"""
    )
    
    # ==================== CHAIN-OF-THOUGHT PROMPTS ====================
    
    COMPLEX_ANALYSIS = PromptTemplate(
        name="complex_analysis",
        technique=PromptTechnique.CHAIN_OF_THOUGHT,
        variables=["situation", "context"],
        template="""Phân tích tình huống tuân thủ môi trường sau đây.

TÌNH HUỐNG:
$situation

QUY ĐỊNH LIÊN QUAN:
$context

Hãy phân tích theo các bước sau:

BƯỚC 1: XÁC ĐỊNH VẤN ĐỀ
- Liệt kê các vấn đề môi trường trong tình huống
- Xác định các quy định có liên quan

BƯỚC 2: PHÂN TÍCH TỪNG VẤN ĐỀ
- Với mỗi vấn đề, so sánh với quy chuẩn/quy định
- Đánh giá mức độ tuân thủ

BƯỚC 3: ĐÁNH GIÁ RỦI RO
- Rủi ro pháp lý (xử phạt)
- Rủi ro môi trường
- Rủi ro khác

BƯỚC 4: KHUYẾN NGHỊ
- Biện pháp khắc phục ngay
- Biện pháp dài hạn
- Ưu tiên thực hiện

PHÂN TÍCH CHI TIẾT:"""
    )
    
    # ==================== REACT PATTERN ====================
    
    REACT_RESEARCH = PromptTemplate(
        name="react_research",
        technique=PromptTechnique.REACT,
        variables=["question", "available_tools"],
        template="""Bạn là trợ lý nghiên cứu quy định môi trường. Sử dụng các công cụ có sẵn để trả lời câu hỏi.

CÁC CÔNG CỤ CÓ SẴN:
$available_tools

CÂU HỎI:
$question

Sử dụng pattern Thought → Action → Observation để giải quyết:

Thought: [Suy nghĩ về những gì cần làm tiếp theo]
Action: [Tên công cụ và tham số]
Observation: [Kết quả từ công cụ]
... (lặp lại nếu cần)
Final Answer: [Câu trả lời cuối cùng]

BẮT ĐẦU:"""
    )
    
    @classmethod
    def get_prompt(cls, name: str) -> PromptTemplate:
        """Get prompt template by name."""
        prompts = {
            "regulation_qa": cls.REGULATION_QA,
            "compliance_check": cls.COMPLIANCE_CHECK,
            "document_summary": cls.DOCUMENT_SUMMARY,
            "entity_extraction": cls.ENTITY_EXTRACTION,
            "classification": cls.CLASSIFICATION,
            "complex_analysis": cls.COMPLEX_ANALYSIS,
            "react_research": cls.REACT_RESEARCH
        }
        
        if name not in prompts:
            raise ValueError(f"Unknown prompt: {name}. Available: {list(prompts.keys())}")
        
        return prompts[name]
    
    @classmethod
    def list_prompts(cls) -> List[str]:
        """List all available prompts."""
        return [
            "regulation_qa",
            "compliance_check", 
            "document_summary",
            "entity_extraction",
            "classification",
            "complex_analysis",
            "react_research"
        ]


# ============================================
# PROMPT OPTIMIZATION
# ============================================

class PromptOptimizer:
    """
    Tools for optimizing and testing prompts.
    """
    
    def __init__(self, llm_client: UnifiedLLMClient):
        self.llm = llm_client
    
    def test_prompt(
        self,
        prompt_template: PromptTemplate,
        test_cases: List[Dict],
        model: str = None
    ) -> Dict:
        """
        Test prompt with multiple test cases.
        
        Args:
            prompt_template: The prompt template to test
            test_cases: List of {input_vars: Dict, expected_output: str}
            model: Model to use
        
        Returns:
            Test results with metrics
        """
        results = []
        
        for i, test_case in enumerate(test_cases):
            try:
                prompt = prompt_template.render(**test_case['input_vars'])
                
                messages = [Message(role="user", content=prompt)]
                response = self.llm.complete(messages, model=model)
                
                result = {
                    "test_case": i + 1,
                    "input": test_case['input_vars'],
                    "expected": test_case.get('expected_output'),
                    "actual": response.content,
                    "tokens": response.total_tokens,
                    "latency_ms": response.latency_ms,
                    "passed": self._check_output(
                        response.content,
                        test_case.get('expected_output'),
                        test_case.get('criteria')
                    )
                }
                results.append(result)
                
            except Exception as e:
                results.append({
                    "test_case": i + 1,
                    "error": str(e),
                    "passed": False
                })
        
        # Calculate metrics
        passed = sum(1 for r in results if r.get('passed', False))
        total = len(results)
        avg_tokens = sum(r.get('tokens', 0) for r in results) / total
        avg_latency = sum(r.get('latency_ms', 0) for r in results) / total
        
        return {
            "prompt_name": prompt_template.name,
            "technique": prompt_template.technique.value,
            "total_tests": total,
            "passed": passed,
            "failed": total - passed,
            "pass_rate": passed / total if total > 0 else 0,
            "avg_tokens": avg_tokens,
            "avg_latency_ms": avg_latency,
            "results": results
        }
    
    def _check_output(
        self,
        actual: str,
        expected: Optional[str],
        criteria: Optional[Dict] = None
    ) -> bool:
        """Check if output meets criteria."""
        if expected is None and criteria is None:
            return True  # No validation required
        
        if expected:
            # Simple string matching
            return expected.lower() in actual.lower()
        
        if criteria:
            # Check various criteria
            if "contains" in criteria:
                for term in criteria["contains"]:
                    if term.lower() not in actual.lower():
                        return False
            
            if "not_contains" in criteria:
                for term in criteria["not_contains"]:
                    if term.lower() in actual.lower():
                        return False
            
            if "min_length" in criteria:
                if len(actual) < criteria["min_length"]:
                    return False
            
            if "max_length" in criteria:
                if len(actual) > criteria["max_length"]:
                    return False
        
        return True
    
    def compare_techniques(
        self,
        task: str,
        test_input: Dict,
        techniques: List[PromptTechnique]
    ) -> Dict:
        """
        Compare different prompting techniques for the same task.
        """
        results = {}
        
        for technique in techniques:
            prompt = self._create_prompt_for_technique(task, technique, test_input)
            
            messages = [Message(role="user", content=prompt)]
            response = self.llm.complete(messages)
            
            results[technique.value] = {
                "response": response.content,
                "tokens": response.total_tokens,
                "latency_ms": response.latency_ms
            }
        
        return results
    
    def _create_prompt_for_technique(
        self,
        task: str,
        technique: PromptTechnique,
        input_vars: Dict
    ) -> str:
        """Create prompt using specific technique."""
        # Implementation would vary based on technique
        # This is a simplified version
        base_prompt = f"Task: {task}\nInput: {json.dumps(input_vars, ensure_ascii=False)}"
        
        if technique == PromptTechnique.CHAIN_OF_THOUGHT:
            base_prompt += "\n\nLet's think step by step:"
        elif technique == PromptTechnique.ZERO_SHOT:
            base_prompt += "\n\nAnswer:"
        
        return base_prompt


# Usage example
if __name__ == "__main__":
    # Get prompt template
    qa_prompt = EnvironmentalPromptLibrary.get_prompt("regulation_qa")
    
    # Render prompt
    rendered = qa_prompt.render(
        question="QCVN 40:2011 quy định giới hạn BOD5 là bao nhiêu?",
        context="Theo QCVN 40:2011/BTNMT, giới hạn BOD5 trong nước thải công nghiệp là 30 mg/L (cột A) và 50 mg/L (cột B)."
    )
    
    print(rendered)
```

### Ngày 5-6: Building Environmental Q&A System

#### 3.1 Q&A System with RAG Foundation

```python
# ============================================
# ENVIRONMENTAL Q&A SYSTEM
# ============================================

from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class QAResponse:
    """Q&A response structure."""
    question: str
    answer: str
    sources: List[Dict]
    confidence: float
    model_used: str
    tokens_used: int
    latency_ms: float
    timestamp: str

class EnvironmentalQASystem:
    """
    Q&A System for Vietnamese Environmental Regulations.
    
    Features:
    - Semantic search for relevant documents
    - Context-aware answer generation
    - Source citation
    - Confidence scoring
    - Answer caching
    """
    
    def __init__(
        self,
        vector_db: 'EnvironmentalRegulationDB',
        llm_client: UnifiedLLMClient,
        default_model: str = "gpt-4-turbo-preview",
        max_context_docs: int = 5,
        enable_cache: bool = True
    ):
        """
        Initialize Q&A system.
        
        Args:
            vector_db: Vector database instance
            llm_client: LLM client instance
            default_model: Default LLM model
            max_context_docs: Maximum documents for context
            enable_cache: Enable response caching
        """
        self.db = vector_db
        self.llm = llm_client
        self.default_model = default_model
        self.max_context_docs = max_context_docs
        self.enable_cache = enable_cache
        
        # Response cache
        self._cache: Dict[str, QAResponse] = {}
        
        # Prompt templates
        self.prompts = EnvironmentalPromptLibrary()
    
    def ask(
        self,
        question: str,
        domain_filter: Optional[str] = None,
        year_filter: Optional[int] = None,
        model: Optional[str] = None,
        use_hybrid_search: bool = True,
        return_sources: bool = True
    ) -> QAResponse:
        """
        Ask a question about environmental regulations.
        
        Args:
            question: User question
            domain_filter: Filter by domain (air, water, etc.)
            year_filter: Filter by year
            model: LLM model to use
            use_hybrid_search: Use hybrid search (semantic + keyword)
            return_sources: Include source documents in response
        
        Returns:
            QAResponse with answer and metadata
        """
        import time
        start_time = time.perf_counter()
        
        # Check cache
        cache_key = self._generate_cache_key(question, domain_filter, year_filter)
        if self.enable_cache and cache_key in self._cache:
            logger.info(f"Cache hit for question: {question[:50]}...")
            return self._cache[cache_key]
        
        # Step 1: Retrieve relevant documents
        logger.info(f"Retrieving documents for: {question[:50]}...")
        
        search_filter = {}
        if domain_filter:
            search_filter["domain"] = domain_filter
        if year_filter:
            search_filter["year"] = {"$gte": year_filter}
        
        if use_hybrid_search:
            results = self.db.hybrid_search(
                query=question,
                n_results=self.max_context_docs,
                where=search_filter if search_filter else None
            )
        else:
            results = self.db.search(
                query=question,
                n_results=self.max_context_docs,
                where=search_filter if search_filter else None
            )
        
        # Step 2: Build context
        context = self._build_context(results)
        
        # Step 3: Generate answer
        logger.info("Generating answer...")
        
        prompt_template = self.prompts.get_prompt("regulation_qa")
        prompt = prompt_template.render(
            question=question,
            context=context
        )
        
        messages = [Message(role="user", content=prompt)]
        
        response = self.llm.complete(
            messages=messages,
            model=model or self.default_model,
            temperature=0.3  # Lower temperature for factual answers
        )
        
        # Step 4: Calculate confidence
        confidence = self._calculate_confidence(question, results, response.content)
        
        # Step 5: Prepare response
        latency = (time.perf_counter() - start_time) * 1000
        
        qa_response = QAResponse(
            question=question,
            answer=response.content,
            sources=[
                {
                    "id": r.id,
                    "content_snippet": r.content[:200] + "...",
                    "score": r.score,
                    "metadata": r.metadata
                }
                for r in results
            ] if return_sources else [],
            confidence=confidence,
            model_used=response.model,
            tokens_used=response.total_tokens,
            latency_ms=latency,
            timestamp=datetime.now().isoformat()
        )
        
        # Cache response
        if self.enable_cache:
            self._cache[cache_key] = qa_response
        
        return qa_response
    
    def _build_context(self, results: List['SearchResult']) -> str:
        """Build context string from search results."""
        context_parts = []
        
        for i, result in enumerate(results, 1):
            doc_info = f"[Tài liệu {i}]"
            
            if result.metadata.get('doc_number'):
                doc_info += f" {result.metadata['doc_number']}"
            
            if result.metadata.get('article'):
                doc_info += f" - {result.metadata['article']}"
            
            context_parts.append(f"{doc_info}\n{result.content}")
        
        return "\n\n---\n\n".join(context_parts)
    
    def _calculate_confidence(
        self,
        question: str,
        results: List['SearchResult'],
        answer: str
    ) -> float:
        """
        Calculate confidence score for the answer.
        
        Factors:
        - Relevance of retrieved documents (search scores)
        - Answer contains citations
        - Answer length appropriate
        """
        # Base confidence from search scores
        if not results:
            return 0.0
        
        avg_search_score = sum(r.score for r in results) / len(results)
        
        # Bonus for citations in answer
        citation_bonus = 0.0
        citation_patterns = ['Điều', 'Khoản', 'QCVN', 'Nghị định', 'Thông tư']
        for pattern in citation_patterns:
            if pattern in answer:
                citation_bonus += 0.05
        
        citation_bonus = min(citation_bonus, 0.2)  # Cap at 0.2
        
        # Penalty for "không có thông tin" type answers
        uncertainty_penalty = 0.0
        uncertainty_phrases = ['không có trong', 'không tìm thấy', 'không rõ']
        for phrase in uncertainty_phrases:
            if phrase in answer.lower():
                uncertainty_penalty = 0.3
                break
        
        # Calculate final confidence
        confidence = avg_search_score + citation_bonus - uncertainty_penalty
        
        # Clamp to [0, 1]
        return max(0.0, min(1.0, confidence))
    
    def _generate_cache_key(
        self,
        question: str,
        domain: Optional[str],
        year: Optional[int]
    ) -> str:
        """Generate cache key for question."""
        import hashlib
        key_parts = [question.lower().strip()]
        if domain:
            key_parts.append(f"domain:{domain}")
        if year:
            key_parts.append(f"year:{year}")
        
        key_string = "|".join(key_parts)
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def ask_followup(
        self,
        original_qa: QAResponse,
        followup_question: str
    ) -> QAResponse:
        """
        Ask a follow-up question with context from previous Q&A.
        """
        # Include previous context
        context = f"""
Câu hỏi trước: {original_qa.question}
Câu trả lời trước: {original_qa.answer}

Câu hỏi tiếp theo: {followup_question}
"""
        
        # Search for additional relevant documents
        results = self.db.search(followup_question, n_results=3)
        additional_context = self._build_context(results)
        
        prompt = f"""Dựa vào cuộc hội thoại trước và thông tin bổ sung, hãy trả lời câu hỏi tiếp theo.

{context}

THÔNG TIN BỔ SUNG:
{additional_context}

TRẢ LỜI:"""
        
        messages = [Message(role="user", content=prompt)]
        response = self.llm.complete(messages)
        
        return QAResponse(
            question=followup_question,
            answer=response.content,
            sources=[{"id": r.id, "score": r.score} for r in results],
            confidence=0.0,  # Skip confidence calculation for follow-up
            model_used=response.model,
            tokens_used=response.total_tokens,
            latency_ms=response.latency_ms,
            timestamp=datetime.now().isoformat()
        )
    
    def batch_ask(
        self,
        questions: List[str],
        **kwargs
    ) -> List[QAResponse]:
        """Ask multiple questions."""
        return [self.ask(q, **kwargs) for q in questions]
    
    def evaluate_answer(
        self,
        qa_response: QAResponse,
        ground_truth: Optional[str] = None
    ) -> Dict:
        """
        Evaluate answer quality.
        
        Uses LLM-as-judge approach.
        """
        eval_prompt = f"""Đánh giá chất lượng câu trả lời sau về quy định môi trường Việt Nam.

CÂU HỎI: {qa_response.question}

CÂU TRẢ LỜI: {qa_response.answer}

Đánh giá theo thang điểm 1-5 cho mỗi tiêu chí:
1. Độ chính xác: Thông tin có đúng không?
2. Đầy đủ: Trả lời đủ các khía cạnh của câu hỏi không?
3. Trích dẫn: Có trích dẫn nguồn/điều khoản cụ thể không?
4. Dễ hiểu: Ngôn ngữ có rõ ràng, dễ hiểu không?
5. Phù hợp: Câu trả lời có đúng chủ đề không?

Trả về JSON với format:
{{
    "scores": {{
        "accuracy": <1-5>,
        "completeness": <1-5>,
        "citations": <1-5>,
        "clarity": <1-5>,
        "relevance": <1-5>
    }},
    "overall_score": <1-5>,
    "feedback": "<nhận xét ngắn>"
}}

ĐÁNH GIÁ (JSON):"""
        
        messages = [Message(role="user", content=eval_prompt)]
        response = self.llm.complete(messages, temperature=0)
        
        try:
            # Parse JSON from response
            json_str = response.content
            if "```json" in json_str:
                json_str = json_str.split("```json")[1].split("```")[0]
            elif "```" in json_str:
                json_str = json_str.split("```")[1].split("```")[0]
            
            return json.loads(json_str.strip())
        except:
            return {
                "scores": {},
                "overall_score": 0,
                "feedback": "Could not parse evaluation"
            }
    
    def get_stats(self) -> Dict:
        """Get system statistics."""
        return {
            "cache_size": len(self._cache),
            "db_document_count": self.db.count(),
            "default_model": self.default_model
        }
    
    def clear_cache(self):
        """Clear response cache."""
        self._cache.clear()


# ============================================
# FASTAPI Q&A ENDPOINTS
# ============================================

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# Models for API
class QuestionRequest(BaseModel):
    question: str = Field(..., min_length=5, max_length=500)
    domain: Optional[str] = None
    year_from: Optional[int] = None
    use_hybrid_search: bool = True

class QuestionResponse(BaseModel):
    question: str
    answer: str
    sources: List[Dict]
    confidence: float
    model: str
    tokens: int
    latency_ms: float

class FollowUpRequest(BaseModel):
    original_question: str
    original_answer: str
    followup_question: str

# Create API router
def create_qa_router(qa_system: EnvironmentalQASystem):
    """Create FastAPI router for Q&A endpoints."""
    from fastapi import APIRouter
    
    router = APIRouter(prefix="/qa", tags=["Q&A"])
    
    @router.post("/ask", response_model=QuestionResponse)
    async def ask_question(request: QuestionRequest):
        """Ask a question about environmental regulations."""
        try:
            response = qa_system.ask(
                question=request.question,
                domain_filter=request.domain,
                year_filter=request.year_from,
                use_hybrid_search=request.use_hybrid_search
            )
            
            return QuestionResponse(
                question=response.question,
                answer=response.answer,
                sources=response.sources,
                confidence=response.confidence,
                model=response.model_used,
                tokens=response.tokens_used,
                latency_ms=response.latency_ms
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.post("/followup", response_model=QuestionResponse)
    async def ask_followup(request: FollowUpRequest):
        """Ask a follow-up question."""
        try:
            # Create mock original response
            original = QAResponse(
                question=request.original_question,
                answer=request.original_answer,
                sources=[],
                confidence=0,
                model_used="",
                tokens_used=0,
                latency_ms=0,
                timestamp=""
            )
            
            response = qa_system.ask_followup(original, request.followup_question)
            
            return QuestionResponse(
                question=response.question,
                answer=response.answer,
                sources=response.sources,
                confidence=response.confidence,
                model=response.model_used,
                tokens=response.tokens_used,
                latency_ms=response.latency_ms
            )
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    @router.get("/stats")
    async def get_stats():
        """Get Q&A system statistics."""
        return qa_system.get_stats()
    
    @router.post("/clear-cache")
    async def clear_cache():
        """Clear the response cache."""
        qa_system.clear_cache()
        return {"status": "cache cleared"}
    
    return router


# Usage example
if __name__ == "__main__":
    import os
    
    # Initialize components
    db = EnvironmentalRegulationDB(
        collection_name="env_regulations",
        persist_directory="./chroma_db"
    )
    
    llm = UnifiedLLMClient(
        openai_api_key=os.getenv("OPENAI_API_KEY")
    )
    
    qa = EnvironmentalQASystem(
        vector_db=db,
        llm_client=llm
    )
    
    # Test Q&A
    response = qa.ask(
        question="Giới hạn BOD5 trong nước thải công nghiệp theo QCVN là bao nhiêu?",
        domain_filter="water_quality"
    )
    
    print(f"Question: {response.question}")
    print(f"Answer: {response.answer}")
    print(f"Confidence: {response.confidence:.2f}")
    print(f"Sources: {len(response.sources)}")
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: LLM Client (Ngày 1-2)

```
🎯 Mục tiêu: Xây dựng unified LLM client

📋 Yêu cầu:
1. Implement OpenAI và Anthropic clients
2. Support sync, async, và streaming
3. Error handling và retry logic
4. Token counting và cost estimation

📁 Deliverables:
- src/llm/openai_client.py
- src/llm/anthropic_client.py
- src/llm/unified_client.py
- tests/test_llm_client.py
```

### Bài tập 2: Prompt Library (Ngày 3-4)

```
🎯 Mục tiêu: Xây dựng prompt library cho environmental domain

📋 Yêu cầu:
1. Implement prompt templates (zero-shot, few-shot, CoT)
2. Domain-specific prompts (Q&A, compliance, summary)
3. Prompt testing framework
4. Documentation cho mỗi prompt

📁 Deliverables:
- src/prompts/templates.py
- src/prompts/optimizer.py
- prompts/README.md với examples
```

### Bài tập 3: Q&A System (Ngày 5-7)

```
🎯 Mục tiêu: Hoàn thiện Q&A System

📋 Yêu cầu:
1. Integrate với Vector DB từ Week 3
2. Context-aware answer generation
3. Source citation
4. API endpoints
5. Demo UI

📁 Deliverables:
- src/qa/system.py
- src/api/qa_routes.py
- Streamlit demo
- **PROJECT 1 Complete**: Environmental Search + Q&A
```

---

## ✅ CHECKLIST TUẦN 4

### Kiến thức đã học
- [ ] LLM architectures và model selection
- [ ] Token limits, pricing, rate limiting
- [ ] Prompt engineering techniques (zero-shot, few-shot, CoT)
- [ ] Streaming và async completions
- [ ] Answer evaluation methods

### Skills thực hành
- [ ] Sử dụng OpenAI và Anthropic APIs
- [ ] Viết effective prompts cho Vietnamese text
- [ ] Build Q&A system với RAG foundation
- [ ] Implement caching và error handling

### Deliverables
- [ ] Unified LLM client
- [ ] Environmental prompt library
- [ ] Q&A system với citation
- [ ] API và demo UI
- [ ] **PROJECT 1 Hoàn thành**: Semantic Search + Q&A System

---

## 🎉 TỔNG KẾT GIAI ĐOẠN FOUNDATION

### Những gì đã học được (Tuần 1-4)

| Tuần | Chủ đề | Output |
|------|--------|--------|
| 1 | Python & Data Processing | Data pipeline cho environmental data |
| 2 | ML & NLP Basics | Document classifier |
| 3 | Vector DB & Semantic Search | Search engine |
| 4 | LLM & Prompt Engineering | Q&A system |

### PROJECT 1: Environmental Regulation Semantic Search + Q&A

**Features hoàn thành:**
- ✅ Vector database với 100+ documents
- ✅ Semantic search với filtering
- ✅ Hybrid search (semantic + keyword)
- ✅ Q&A với context và citations
- ✅ REST API
- ✅ Demo UI

**Tech Stack:**
- Python, FastAPI, Streamlit
- ChromaDB, OpenAI Embeddings
- GPT-4 / Claude

### Chuẩn bị cho Phase 2 (Intermediate)

Tuần 5-8 sẽ cover:
- RAG Architecture deep dive
- LangChain & LlamaIndex
- Production optimization
- Function calling & Tool use

---

*Hoàn thành Phase 1 Foundation! Tiếp tục sang Phase 2: Intermediate*
