# 📅 TUẦN 1: PYTHON CHO AI ENGINEERING & XỬ LÝ DỮ LIỆU

## Tổng quan

| Thông tin | Chi tiết |
|-----------|----------|
| **Thời lượng** | 7 ngày (15-20 giờ học) |
| **Mục tiêu chính** | Thành thạo Python nâng cao và xử lý dữ liệu môi trường |
| **Output** | Data processing pipeline cho environmental data |
| **Độ khó** | ⭐⭐ Trung bình |

---

## 🎯 MỤC TIÊU HỌC TẬP

### Kiến thức (Knowledge)
- [ ] Hiểu sâu Python type hints và static typing
- [ ] Nắm vững dataclasses, Pydantic models
- [ ] Hiểu async/await và concurrent programming
- [ ] Biết cách structure Python projects cho AI applications

### Kỹ năng (Skills)
- [ ] Sử dụng thành thạo NumPy, Pandas cho data manipulation
- [ ] Viết code Python production-ready với proper error handling
- [ ] Xây dựng data processing pipelines
- [ ] Unit testing với pytest

### Ứng dụng (Application)
- [ ] Xử lý dữ liệu quan trắc môi trường Việt Nam
- [ ] Parse và clean regulatory documents
- [ ] Tính toán chỉ số AQI theo QCVN

---

## 📚 NỘI DUNG CHI TIẾT

### Ngày 1-2: Python Advanced Concepts

#### 1.1 Type Hints và Static Typing

Type hints giúp code dễ đọc, dễ maintain và catch bugs sớm.

```python
# ============================================
# TYPE HINTS FUNDAMENTALS
# ============================================

from typing import (
    List, Dict, Set, Tuple,           # Collections
    Optional, Union,                   # Optional types
    Callable, TypeVar, Generic,        # Functions & Generics
    Literal, Final, TypedDict,         # Special types
    Annotated, Any                     # Annotations
)
from collections.abc import Sequence, Mapping, Iterable

# Basic type hints
def process_sample(
    sample_id: str,
    values: List[float],
    metadata: Dict[str, Any]
) -> Dict[str, float]:
    """Process environmental sample data."""
    return {
        "mean": sum(values) / len(values),
        "max": max(values),
        "min": min(values)
    }

# Optional types - value có thể là None
def get_standard_limit(
    parameter: str,
    column: str = "B"
) -> Optional[float]:
    """
    Get QCVN limit for parameter.
    Returns None if parameter not found.
    """
    limits = {
        "BOD": {"A": 30, "B": 50},
        "COD": {"A": 75, "B": 150},
    }
    param_limits = limits.get(parameter)
    if param_limits:
        return param_limits.get(column)
    return None

# Union types - value có thể là nhiều types
def parse_concentration(value: Union[str, float, int]) -> float:
    """Parse concentration value from various formats."""
    if isinstance(value, str):
        # Handle strings like "< 0.5" or "ND"
        if value.upper() == "ND":
            return 0.0
        if value.startswith("<"):
            return float(value[1:].strip()) / 2
        return float(value)
    return float(value)

# TypedDict for structured dictionaries
class EnvironmentalSampleDict(TypedDict):
    """Type definition for environmental sample."""
    sample_id: str
    location: str
    timestamp: str
    parameters: Dict[str, float]
    qc_status: Literal["passed", "failed", "pending"]

# Generic types
T = TypeVar('T')
NumberType = TypeVar('NumberType', int, float)

def first_above_threshold(
    values: Sequence[NumberType],
    threshold: NumberType
) -> Optional[NumberType]:
    """Find first value above threshold."""
    for value in values:
        if value > threshold:
            return value
    return None

# Callable type hints
ProcessorFunc = Callable[[List[float]], Dict[str, float]]

def apply_processor(
    data: List[float],
    processor: ProcessorFunc
) -> Dict[str, float]:
    """Apply a processor function to data."""
    return processor(data)
```

#### 1.2 Dataclasses và Pydantic

```python
# ============================================
# DATACLASSES - Built-in Python
# ============================================

from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import List, Optional

class SampleType(Enum):
    """Types of environmental samples."""
    WATER = "water"
    AIR = "air"
    SOIL = "soil"
    NOISE = "noise"

class QCStatus(Enum):
    """Quality control status."""
    PASSED = "passed"
    FAILED = "failed"
    PENDING = "pending"

@dataclass
class MonitoringLocation:
    """Environmental monitoring location."""
    location_id: str
    name: str
    latitude: float
    longitude: float
    description: Optional[str] = None
    
    def __post_init__(self):
        """Validate coordinates after initialization."""
        if not (-90 <= self.latitude <= 90):
            raise ValueError(f"Invalid latitude: {self.latitude}")
        if not (-180 <= self.longitude <= 180):
            raise ValueError(f"Invalid longitude: {self.longitude}")

@dataclass
class EnvironmentalParameter:
    """Single environmental parameter measurement."""
    name: str
    value: float
    unit: str
    detection_limit: Optional[float] = None
    qcvn_limit: Optional[float] = None
    
    @property
    def is_compliant(self) -> Optional[bool]:
        """Check if value complies with QCVN limit."""
        if self.qcvn_limit is None:
            return None
        return self.value <= self.qcvn_limit
    
    @property
    def compliance_ratio(self) -> Optional[float]:
        """Calculate ratio of value to limit."""
        if self.qcvn_limit is None or self.qcvn_limit == 0:
            return None
        return self.value / self.qcvn_limit

@dataclass
class EnvironmentalSample:
    """Complete environmental sample with measurements."""
    sample_id: str
    sample_type: SampleType
    location: MonitoringLocation
    collected_at: datetime
    parameters: List[EnvironmentalParameter] = field(default_factory=list)
    qc_status: QCStatus = QCStatus.PENDING
    notes: Optional[str] = None
    
    def __post_init__(self):
        """Generate sample_id if not provided."""
        if not self.sample_id:
            prefix = self.sample_type.value[:3].upper()
            timestamp = self.collected_at.strftime("%Y%m%d%H%M")
            self.sample_id = f"{prefix}-{timestamp}"
    
    def add_parameter(self, parameter: EnvironmentalParameter) -> None:
        """Add a parameter measurement."""
        self.parameters.append(parameter)
    
    def get_parameter(self, name: str) -> Optional[EnvironmentalParameter]:
        """Get parameter by name."""
        for param in self.parameters:
            if param.name.upper() == name.upper():
                return param
        return None
    
    def get_non_compliant_parameters(self) -> List[EnvironmentalParameter]:
        """Get list of parameters that exceed limits."""
        return [p for p in self.parameters if p.is_compliant == False]
    
    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return asdict(self)

# Usage example
location = MonitoringLocation(
    location_id="HCM-001",
    name="Sông Sài Gòn - Cầu Sài Gòn",
    latitude=10.7895,
    longitude=106.7052,
    description="Điểm quan trắc nước mặt"
)

sample = EnvironmentalSample(
    sample_id="",  # Auto-generated
    sample_type=SampleType.WATER,
    location=location,
    collected_at=datetime.now()
)

sample.add_parameter(EnvironmentalParameter(
    name="BOD5",
    value=45.0,
    unit="mg/L",
    qcvn_limit=50.0
))

print(f"Sample ID: {sample.sample_id}")
print(f"BOD5 compliant: {sample.get_parameter('BOD5').is_compliant}")
```

```python
# ============================================
# PYDANTIC - Advanced Data Validation
# ============================================

from pydantic import (
    BaseModel, Field, field_validator, model_validator,
    ConfigDict, computed_field
)
from datetime import datetime
from typing import List, Optional, Annotated
from enum import Enum

class SampleTypeEnum(str, Enum):
    water = "water"
    air = "air"
    soil = "soil"

class CoordinateModel(BaseModel):
    """Geographic coordinates with validation."""
    model_config = ConfigDict(frozen=True)  # Immutable
    
    latitude: Annotated[float, Field(ge=-90, le=90)]
    longitude: Annotated[float, Field(ge=-180, le=180)]

class ParameterReading(BaseModel):
    """Environmental parameter reading with validation."""
    
    parameter_name: str = Field(..., min_length=1, max_length=50)
    value: float = Field(..., ge=0)
    unit: str = Field(..., min_length=1)
    detection_limit: Optional[float] = Field(default=None, ge=0)
    qcvn_code: Optional[str] = Field(
        default=None, 
        pattern=r"^QCVN\s*\d+:\d{4}/BTNMT$"
    )
    qcvn_limit_a: Optional[float] = Field(default=None, ge=0)
    qcvn_limit_b: Optional[float] = Field(default=None, ge=0)
    
    @field_validator('parameter_name')
    @classmethod
    def normalize_parameter_name(cls, v: str) -> str:
        """Normalize parameter name to uppercase."""
        return v.upper().strip()
    
    @field_validator('value', mode='before')
    @classmethod
    def parse_value(cls, v):
        """Parse value from string if needed."""
        if isinstance(v, str):
            v = v.strip()
            if v.upper() in ('ND', 'KPH', '-'):
                return 0.0
            if v.startswith('<'):
                return float(v[1:].strip()) / 2
        return float(v)
    
    @computed_field
    @property
    def compliance_status_a(self) -> Optional[str]:
        """Check compliance against Column A."""
        if self.qcvn_limit_a is None:
            return None
        if self.value <= self.qcvn_limit_a:
            return "compliant"
        return "exceeded"
    
    @computed_field
    @property
    def compliance_status_b(self) -> Optional[str]:
        """Check compliance against Column B."""
        if self.qcvn_limit_b is None:
            return None
        if self.value <= self.qcvn_limit_b:
            return "compliant"
        return "exceeded"

class EnvironmentalSampleModel(BaseModel):
    """Complete environmental sample model."""
    
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra='forbid'
    )
    
    sample_id: str = Field(..., pattern=r"^[A-Z]{2,4}-\d{8,14}$")
    sample_type: SampleTypeEnum
    location_name: str = Field(..., min_length=1)
    coordinates: CoordinateModel
    collected_at: datetime
    analyzed_at: Optional[datetime] = None
    parameters: List[ParameterReading] = Field(default_factory=list)
    collector_name: str = Field(..., min_length=2)
    laboratory: Optional[str] = None
    
    @model_validator(mode='after')
    def validate_dates(self):
        """Ensure analyzed_at is after collected_at."""
        if self.analyzed_at and self.analyzed_at < self.collected_at:
            raise ValueError("analyzed_at must be after collected_at")
        return self
    
    def get_exceeded_parameters(self, column: str = "B") -> List[ParameterReading]:
        """Get parameters that exceed QCVN limits."""
        exceeded = []
        for param in self.parameters:
            status = (
                param.compliance_status_a if column.upper() == "A" 
                else param.compliance_status_b
            )
            if status == "exceeded":
                exceeded.append(param)
        return exceeded

# Usage with validation
try:
    sample = EnvironmentalSampleModel(
        sample_id="WAT-20240115",
        sample_type="water",
        location_name="Sông Đồng Nai - KCN Biên Hòa",
        coordinates={"latitude": 10.95, "longitude": 106.82},
        collected_at="2024-01-15T08:30:00",
        collector_name="Nguyễn Văn A",
        parameters=[
            {
                "parameter_name": "bod5",
                "value": "45.5",
                "unit": "mg/L",
                "qcvn_code": "QCVN 40:2011/BTNMT",
                "qcvn_limit_a": 30,
                "qcvn_limit_b": 50
            },
            {
                "parameter_name": "cod",
                "value": "<10",  # Will be parsed as 5.0
                "unit": "mg/L",
                "qcvn_limit_a": 75,
                "qcvn_limit_b": 150
            }
        ]
    )
    
    print(sample.model_dump_json(indent=2))
    print(f"Exceeded parameters: {sample.get_exceeded_parameters('A')}")
    
except Exception as e:
    print(f"Validation error: {e}")
```

#### 1.3 Async/Await và Concurrent Programming

```python
# ============================================
# ASYNC/AWAIT FOR AI APPLICATIONS
# ============================================

import asyncio
import aiohttp
import aiofiles
from typing import List, Dict, Any
from dataclasses import dataclass
from datetime import datetime
import time

@dataclass
class APIResponse:
    """Response from environmental data API."""
    station_id: str
    data: Dict[str, Any]
    fetched_at: datetime
    latency_ms: float

class EnvironmentalDataFetcher:
    """Async fetcher for environmental monitoring data."""
    
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url
        self.api_key = api_key
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def __aenter__(self):
        """Create session when entering context."""
        self._session = aiohttp.ClientSession(
            headers={"Authorization": f"Bearer {self.api_key}"}
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Close session when exiting context."""
        if self._session:
            await self._session.close()
    
    async def fetch_station_data(self, station_id: str) -> APIResponse:
        """Fetch data from single monitoring station."""
        start_time = time.perf_counter()
        
        url = f"{self.base_url}/stations/{station_id}/latest"
        
        async with self._session.get(url) as response:
            response.raise_for_status()
            data = await response.json()
        
        latency = (time.perf_counter() - start_time) * 1000
        
        return APIResponse(
            station_id=station_id,
            data=data,
            fetched_at=datetime.now(),
            latency_ms=latency
        )
    
    async def fetch_multiple_stations(
        self, 
        station_ids: List[str],
        max_concurrent: int = 10
    ) -> List[APIResponse]:
        """Fetch data from multiple stations concurrently."""
        
        # Semaphore to limit concurrent requests
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def fetch_with_semaphore(station_id: str) -> APIResponse:
            async with semaphore:
                return await self.fetch_station_data(station_id)
        
        # Create tasks for all stations
        tasks = [
            fetch_with_semaphore(station_id) 
            for station_id in station_ids
        ]
        
        # Gather all results
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter out exceptions
        successful = [r for r in results if isinstance(r, APIResponse)]
        failed = [r for r in results if isinstance(r, Exception)]
        
        if failed:
            print(f"Warning: {len(failed)} requests failed")
        
        return successful

class AsyncFileProcessor:
    """Async processor for large environmental data files."""
    
    @staticmethod
    async def read_csv_chunks(
        file_path: str, 
        chunk_size: int = 1000
    ):
        """Read CSV file in chunks asynchronously."""
        async with aiofiles.open(file_path, 'r') as f:
            # Read header
            header = await f.readline()
            columns = header.strip().split(',')
            
            chunk = []
            async for line in f:
                values = line.strip().split(',')
                row = dict(zip(columns, values))
                chunk.append(row)
                
                if len(chunk) >= chunk_size:
                    yield chunk
                    chunk = []
            
            # Yield remaining rows
            if chunk:
                yield chunk
    
    @staticmethod
    async def process_file_parallel(
        file_path: str,
        processor_func,
        num_workers: int = 4
    ) -> List[Any]:
        """Process file with multiple worker coroutines."""
        
        queue = asyncio.Queue()
        results = []
        
        async def worker():
            while True:
                chunk = await queue.get()
                if chunk is None:
                    break
                result = await processor_func(chunk)
                results.append(result)
                queue.task_done()
        
        # Start workers
        workers = [asyncio.create_task(worker()) for _ in range(num_workers)]
        
        # Read and queue chunks
        async for chunk in AsyncFileProcessor.read_csv_chunks(file_path):
            await queue.put(chunk)
        
        # Signal workers to stop
        for _ in range(num_workers):
            await queue.put(None)
        
        # Wait for all workers to complete
        await asyncio.gather(*workers)
        
        return results

# Usage example
async def main():
    """Main async function demonstrating usage."""
    
    # Example 1: Fetch data from multiple stations
    stations = ["HCM-001", "HCM-002", "HCM-003", "DN-001", "HN-001"]
    
    async with EnvironmentalDataFetcher(
        base_url="https://api.envmonitoring.vn",
        api_key="your-api-key"
    ) as fetcher:
        results = await fetcher.fetch_multiple_stations(stations)
        
        for result in results:
            print(f"Station {result.station_id}: {result.latency_ms:.2f}ms")
    
    # Example 2: Process large file
    async def process_chunk(chunk: List[Dict]) -> Dict:
        """Process a chunk of environmental data."""
        # Simulate processing
        await asyncio.sleep(0.1)
        return {
            "count": len(chunk),
            "avg_value": sum(float(r.get('value', 0)) for r in chunk) / len(chunk)
        }
    
    # results = await AsyncFileProcessor.process_file_parallel(
    #     "large_monitoring_data.csv",
    #     process_chunk
    # )

# Run async main
# asyncio.run(main())
```

### Ngày 3-4: Data Processing với Pandas & NumPy

#### 2.1 NumPy cho Environmental Calculations

```python
# ============================================
# NUMPY FOR ENVIRONMENTAL CALCULATIONS
# ============================================

import numpy as np
from typing import Tuple, Optional
from dataclasses import dataclass

class EnvironmentalCalculations:
    """NumPy-based environmental calculations."""
    
    # QCVN 05:2023/BTNMT - Air quality standards (μg/m³)
    QCVN_05_2023 = {
        'PM2.5': {'1h': None, '24h': 50, 'year': 25},
        'PM10': {'1h': None, '24h': 100, 'year': 50},
        'CO': {'1h': 30000, '8h': 10000, '24h': None},
        'NO2': {'1h': 200, '24h': 100, 'year': 40},
        'SO2': {'1h': 350, '24h': 125, 'year': 50},
        'O3': {'1h': 180, '8h': 120, '24h': None}
    }
    
    # AQI breakpoints for Vietnam (simplified)
    AQI_BREAKPOINTS = {
        'PM2.5': [
            (0, 25, 0, 50),      # Good
            (25, 50, 51, 100),   # Moderate
            (50, 80, 101, 150),  # Unhealthy for sensitive
            (80, 150, 151, 200), # Unhealthy
            (150, 250, 201, 300), # Very unhealthy
            (250, 500, 301, 500)  # Hazardous
        ],
        'PM10': [
            (0, 50, 0, 50),
            (50, 100, 51, 100),
            (100, 250, 101, 150),
            (250, 350, 151, 200),
            (350, 420, 201, 300),
            (420, 600, 301, 500)
        ]
    }
    
    @staticmethod
    def calculate_aqi_subindex(
        concentration: float,
        pollutant: str
    ) -> Optional[int]:
        """
        Calculate AQI sub-index for a pollutant.
        
        Formula: AQI = ((AQI_hi - AQI_lo) / (C_hi - C_lo)) * (C - C_lo) + AQI_lo
        """
        breakpoints = EnvironmentalCalculations.AQI_BREAKPOINTS.get(pollutant)
        if not breakpoints:
            return None
        
        for c_lo, c_hi, aqi_lo, aqi_hi in breakpoints:
            if c_lo <= concentration <= c_hi:
                aqi = ((aqi_hi - aqi_lo) / (c_hi - c_lo)) * (concentration - c_lo) + aqi_lo
                return int(round(aqi))
        
        return None
    
    @staticmethod
    def calculate_aqi_batch(
        pm25_values: np.ndarray,
        pm10_values: np.ndarray
    ) -> np.ndarray:
        """
        Calculate AQI for arrays of PM2.5 and PM10 values.
        Uses vectorized operations for efficiency.
        """
        # Calculate sub-indices
        aqi_pm25 = np.zeros_like(pm25_values)
        aqi_pm10 = np.zeros_like(pm10_values)
        
        # PM2.5 breakpoints
        pm25_bp = EnvironmentalCalculations.AQI_BREAKPOINTS['PM2.5']
        for c_lo, c_hi, aqi_lo, aqi_hi in pm25_bp:
            mask = (pm25_values >= c_lo) & (pm25_values <= c_hi)
            aqi_pm25[mask] = (
                ((aqi_hi - aqi_lo) / (c_hi - c_lo)) * 
                (pm25_values[mask] - c_lo) + aqi_lo
            )
        
        # PM10 breakpoints
        pm10_bp = EnvironmentalCalculations.AQI_BREAKPOINTS['PM10']
        for c_lo, c_hi, aqi_lo, aqi_hi in pm10_bp:
            mask = (pm10_values >= c_lo) & (pm10_values <= c_hi)
            aqi_pm10[mask] = (
                ((aqi_hi - aqi_lo) / (c_hi - c_lo)) * 
                (pm10_values[mask] - c_lo) + aqi_lo
            )
        
        # Overall AQI is the maximum
        return np.maximum(aqi_pm25, aqi_pm10).astype(int)
    
    @staticmethod
    def calculate_statistics(data: np.ndarray) -> dict:
        """Calculate comprehensive statistics for environmental data."""
        
        # Remove NaN values for calculations
        clean_data = data[~np.isnan(data)]
        
        if len(clean_data) == 0:
            return {"error": "No valid data"}
        
        return {
            "count": len(clean_data),
            "mean": float(np.mean(clean_data)),
            "std": float(np.std(clean_data)),
            "min": float(np.min(clean_data)),
            "max": float(np.max(clean_data)),
            "median": float(np.median(clean_data)),
            "p25": float(np.percentile(clean_data, 25)),
            "p75": float(np.percentile(clean_data, 75)),
            "p90": float(np.percentile(clean_data, 90)),
            "p95": float(np.percentile(clean_data, 95)),
            "p99": float(np.percentile(clean_data, 99)),
            "iqr": float(np.percentile(clean_data, 75) - np.percentile(clean_data, 25)),
            "cv": float(np.std(clean_data) / np.mean(clean_data) * 100) if np.mean(clean_data) != 0 else None,
            "skewness": float(calculate_skewness(clean_data)),
            "kurtosis": float(calculate_kurtosis(clean_data))
        }
    
    @staticmethod
    def detect_outliers_iqr(
        data: np.ndarray,
        multiplier: float = 1.5
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Detect outliers using IQR method.
        
        Returns:
            - clean_data: data with outliers removed
            - outliers: outlier values
            - outlier_indices: indices of outliers
        """
        q1, q3 = np.percentile(data, [25, 75])
        iqr = q3 - q1
        
        lower_bound = q1 - multiplier * iqr
        upper_bound = q3 + multiplier * iqr
        
        outlier_mask = (data < lower_bound) | (data > upper_bound)
        
        return (
            data[~outlier_mask],
            data[outlier_mask],
            np.where(outlier_mask)[0]
        )
    
    @staticmethod
    def interpolate_missing(
        data: np.ndarray,
        timestamps: np.ndarray,
        method: str = 'linear'
    ) -> np.ndarray:
        """Interpolate missing values in time series data."""
        
        valid_mask = ~np.isnan(data)
        
        if method == 'linear':
            return np.interp(
                timestamps,
                timestamps[valid_mask],
                data[valid_mask]
            )
        elif method == 'forward_fill':
            result = data.copy()
            last_valid = None
            for i, val in enumerate(result):
                if np.isnan(val):
                    if last_valid is not None:
                        result[i] = last_valid
                else:
                    last_valid = val
            return result
        else:
            raise ValueError(f"Unknown method: {method}")
    
    @staticmethod
    def calculate_exceedance_statistics(
        data: np.ndarray,
        threshold: float
    ) -> dict:
        """Calculate statistics about threshold exceedances."""
        
        exceedances = data > threshold
        
        return {
            "threshold": threshold,
            "total_measurements": len(data),
            "exceedance_count": int(np.sum(exceedances)),
            "exceedance_rate": float(np.mean(exceedances) * 100),
            "max_exceedance": float(np.max(data) - threshold) if np.any(exceedances) else 0,
            "mean_when_exceeded": float(np.mean(data[exceedances])) if np.any(exceedances) else None,
            "consecutive_exceedances": int(max_consecutive_true(exceedances))
        }

def calculate_skewness(data: np.ndarray) -> float:
    """Calculate skewness of data."""
    n = len(data)
    mean = np.mean(data)
    std = np.std(data)
    if std == 0:
        return 0
    return (n / ((n-1) * (n-2))) * np.sum(((data - mean) / std) ** 3)

def calculate_kurtosis(data: np.ndarray) -> float:
    """Calculate excess kurtosis of data."""
    n = len(data)
    mean = np.mean(data)
    std = np.std(data)
    if std == 0:
        return 0
    return (n * (n+1) / ((n-1) * (n-2) * (n-3))) * np.sum(((data - mean) / std) ** 4) - 3 * (n-1)**2 / ((n-2) * (n-3))

def max_consecutive_true(arr: np.ndarray) -> int:
    """Find maximum consecutive True values in boolean array."""
    if not np.any(arr):
        return 0
    
    # Find indices where value changes
    change_indices = np.where(np.diff(arr.astype(int)))[0] + 1
    
    # Add start and end
    indices = np.concatenate([[0], change_indices, [len(arr)]])
    
    # Find lengths of True sequences
    max_len = 0
    for i in range(len(indices) - 1):
        if arr[indices[i]]:
            length = indices[i + 1] - indices[i]
            max_len = max(max_len, length)
    
    return max_len

# Usage example
if __name__ == "__main__":
    # Generate sample PM2.5 data
    np.random.seed(42)
    pm25_data = np.random.lognormal(mean=3.5, sigma=0.5, size=1000)
    
    # Calculate statistics
    calc = EnvironmentalCalculations()
    stats = calc.calculate_statistics(pm25_data)
    print("Statistics:", stats)
    
    # Check exceedances against QCVN
    exceedance = calc.calculate_exceedance_statistics(pm25_data, threshold=50)
    print("Exceedance analysis:", exceedance)
    
    # Calculate AQI
    pm10_data = pm25_data * 1.5  # Simulated PM10
    aqi = calc.calculate_aqi_batch(pm25_data, pm10_data)
    print(f"AQI range: {aqi.min()} - {aqi.max()}")
```

#### 2.2 Pandas cho Data Processing Pipeline

```python
# ============================================
# PANDAS DATA PROCESSING PIPELINE
# ============================================

import pandas as pd
import numpy as np
from pathlib import Path
from typing import List, Dict, Optional, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class QCVNStandard:
    """Vietnamese environmental standard definition."""
    code: str
    parameter: str
    unit: str
    limit_a: Optional[float]
    limit_b: Optional[float]
    averaging_period: str  # e.g., "24h", "1h", "year"

class EnvironmentalDataPipeline:
    """
    Complete data processing pipeline for environmental monitoring data.
    """
    
    # QCVN 40:2011/BTNMT - Industrial wastewater standards
    QCVN_40_2011 = {
        'pH': {'unit': '-', 'A': (6, 9), 'B': (5.5, 9)},
        'BOD5': {'unit': 'mg/L', 'A': 30, 'B': 50},
        'COD': {'unit': 'mg/L', 'A': 75, 'B': 150},
        'TSS': {'unit': 'mg/L', 'A': 50, 'B': 100},
        'Amoni': {'unit': 'mg/L', 'A': 5, 'B': 10},
        'Tổng N': {'unit': 'mg/L', 'A': 20, 'B': 40},
        'Tổng P': {'unit': 'mg/L', 'A': 4, 'B': 6},
        'Coliform': {'unit': 'MPN/100mL', 'A': 3000, 'B': 5000},
    }
    
    def __init__(self, data_dir: str = "./data"):
        self.data_dir = Path(data_dir)
        self.df: Optional[pd.DataFrame] = None
        self._processing_log: List[str] = []
    
    def log_step(self, message: str):
        """Log processing step."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        self._processing_log.append(log_entry)
        logger.info(message)
    
    # ==================== DATA LOADING ====================
    
    def load_csv(
        self, 
        file_path: str,
        date_columns: List[str] = None,
        encoding: str = 'utf-8'
    ) -> 'EnvironmentalDataPipeline':
        """Load data from CSV file."""
        
        self.log_step(f"Loading data from {file_path}")
        
        parse_dates = date_columns or []
        
        self.df = pd.read_csv(
            file_path,
            parse_dates=parse_dates,
            encoding=encoding,
            na_values=['ND', 'KPH', '-', 'N/A', '']
        )
        
        self.log_step(f"Loaded {len(self.df)} rows, {len(self.df.columns)} columns")
        
        return self
    
    def load_excel(
        self,
        file_path: str,
        sheet_name: str = 0,
        header_row: int = 0
    ) -> 'EnvironmentalDataPipeline':
        """Load data from Excel file."""
        
        self.log_step(f"Loading Excel from {file_path}, sheet: {sheet_name}")
        
        self.df = pd.read_excel(
            file_path,
            sheet_name=sheet_name,
            header=header_row,
            na_values=['ND', 'KPH', '-', 'N/A', '']
        )
        
        self.log_step(f"Loaded {len(self.df)} rows, {len(self.df.columns)} columns")
        
        return self
    
    # ==================== DATA CLEANING ====================
    
    def clean_column_names(self) -> 'EnvironmentalDataPipeline':
        """Standardize column names."""
        
        self.log_step("Cleaning column names")
        
        # Vietnamese to English mapping
        column_mapping = {
            'Ngày lấy mẫu': 'sample_date',
            'Vị trí': 'location',
            'Mã mẫu': 'sample_id',
            'Thông số': 'parameter',
            'Giá trị': 'value',
            'Đơn vị': 'unit',
            'QCVN': 'qcvn_limit',
            'Đánh giá': 'compliance',
        }
        
        # Clean names: lowercase, replace spaces with underscores
        self.df.columns = [
            column_mapping.get(col, col.lower().strip().replace(' ', '_'))
            for col in self.df.columns
        ]
        
        return self
    
    def handle_missing_values(
        self,
        strategy: str = 'drop',
        fill_value: Optional[float] = None,
        columns: List[str] = None
    ) -> 'EnvironmentalDataPipeline':
        """
        Handle missing values.
        
        Strategies:
        - 'drop': Remove rows with missing values
        - 'fill': Fill with specified value
        - 'ffill': Forward fill
        - 'bfill': Backward fill
        - 'interpolate': Linear interpolation
        - 'mean': Fill with column mean
        - 'median': Fill with column median
        """
        
        self.log_step(f"Handling missing values with strategy: {strategy}")
        
        target_cols = columns or self.df.columns.tolist()
        initial_na = self.df[target_cols].isna().sum().sum()
        
        if strategy == 'drop':
            self.df = self.df.dropna(subset=target_cols)
        elif strategy == 'fill':
            self.df[target_cols] = self.df[target_cols].fillna(fill_value)
        elif strategy == 'ffill':
            self.df[target_cols] = self.df[target_cols].fillna(method='ffill')
        elif strategy == 'bfill':
            self.df[target_cols] = self.df[target_cols].fillna(method='bfill')
        elif strategy == 'interpolate':
            self.df[target_cols] = self.df[target_cols].interpolate(method='linear')
        elif strategy == 'mean':
            for col in target_cols:
                if self.df[col].dtype in ['float64', 'int64']:
                    self.df[col] = self.df[col].fillna(self.df[col].mean())
        elif strategy == 'median':
            for col in target_cols:
                if self.df[col].dtype in ['float64', 'int64']:
                    self.df[col] = self.df[col].fillna(self.df[col].median())
        
        final_na = self.df[target_cols].isna().sum().sum()
        self.log_step(f"Missing values: {initial_na} -> {final_na}")
        
        return self
    
    def remove_outliers(
        self,
        columns: List[str],
        method: str = 'iqr',
        threshold: float = 1.5
    ) -> 'EnvironmentalDataPipeline':
        """
        Remove outliers from specified columns.
        
        Methods:
        - 'iqr': Interquartile range method
        - 'zscore': Z-score method
        - 'percentile': Remove outside percentile range
        """
        
        self.log_step(f"Removing outliers using {method} method")
        
        initial_len = len(self.df)
        
        for col in columns:
            if self.df[col].dtype not in ['float64', 'int64']:
                continue
            
            if method == 'iqr':
                Q1 = self.df[col].quantile(0.25)
                Q3 = self.df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower = Q1 - threshold * IQR
                upper = Q3 + threshold * IQR
                self.df = self.df[(self.df[col] >= lower) & (self.df[col] <= upper)]
            
            elif method == 'zscore':
                z_scores = np.abs((self.df[col] - self.df[col].mean()) / self.df[col].std())
                self.df = self.df[z_scores < threshold]
            
            elif method == 'percentile':
                lower = self.df[col].quantile(threshold / 100)
                upper = self.df[col].quantile(1 - threshold / 100)
                self.df = self.df[(self.df[col] >= lower) & (self.df[col] <= upper)]
        
        removed = initial_len - len(self.df)
        self.log_step(f"Removed {removed} outlier rows ({removed/initial_len*100:.2f}%)")
        
        return self
    
    def parse_detection_limits(
        self,
        value_column: str = 'value'
    ) -> 'EnvironmentalDataPipeline':
        """
        Parse values with detection limit indicators (e.g., '<0.5', 'ND').
        Converts to numeric, handling special cases.
        """
        
        self.log_step(f"Parsing detection limits in column: {value_column}")
        
        def parse_value(val):
            if pd.isna(val):
                return np.nan
            
            val_str = str(val).strip().upper()
            
            # Not detected
            if val_str in ['ND', 'KPH', '-', 'N/A', '']:
                return np.nan
            
            # Below detection limit
            if val_str.startswith('<'):
                try:
                    return float(val_str[1:].strip()) / 2  # Use half of DL
                except ValueError:
                    return np.nan
            
            # Above detection limit
            if val_str.startswith('>'):
                try:
                    return float(val_str[1:].strip())
                except ValueError:
                    return np.nan
            
            # Range (e.g., "5-10")
            if '-' in val_str and not val_str.startswith('-'):
                try:
                    parts = val_str.split('-')
                    return (float(parts[0]) + float(parts[1])) / 2
                except (ValueError, IndexError):
                    pass
            
            # Normal numeric value
            try:
                return float(val_str)
            except ValueError:
                return np.nan
        
        self.df[value_column] = self.df[value_column].apply(parse_value)
        
        return self
    
    # ==================== COMPLIANCE CHECKING ====================
    
    def check_qcvn_compliance(
        self,
        parameter_column: str = 'parameter',
        value_column: str = 'value',
        standard: str = 'QCVN_40_2011',
        column: str = 'B'
    ) -> 'EnvironmentalDataPipeline':
        """
        Check compliance against QCVN standards.
        Adds compliance status columns.
        """
        
        self.log_step(f"Checking compliance against {standard}, Column {column}")
        
        standards = getattr(self, standard, {})
        
        def check_compliance(row):
            param = row[parameter_column]
            value = row[value_column]
            
            if pd.isna(value) or param not in standards:
                return None
            
            limit = standards[param].get(column)
            
            if limit is None:
                return None
            
            # Handle range limits (e.g., pH)
            if isinstance(limit, tuple):
                return 'Đạt' if limit[0] <= value <= limit[1] else 'Không đạt'
            
            return 'Đạt' if value <= limit else 'Không đạt'
        
        self.df['compliance_status'] = self.df.apply(check_compliance, axis=1)
        self.df['qcvn_standard'] = standard.replace('_', ' ')
        self.df['qcvn_column'] = column
        
        # Add limit column
        def get_limit(row):
            param = row[parameter_column]
            if param in standards:
                limit = standards[param].get(column)
                if isinstance(limit, tuple):
                    return f"{limit[0]}-{limit[1]}"
                return limit
            return None
        
        self.df['qcvn_limit'] = self.df.apply(get_limit, axis=1)
        
        # Summary
        compliance_summary = self.df['compliance_status'].value_counts()
        self.log_step(f"Compliance summary:\n{compliance_summary}")
        
        return self
    
    # ==================== AGGREGATION ====================
    
    def aggregate_by_time(
        self,
        date_column: str,
        value_columns: List[str],
        freq: str = 'D',
        agg_func: str = 'mean'
    ) -> 'EnvironmentalDataPipeline':
        """
        Aggregate data by time period.
        
        freq options: 'H' (hourly), 'D' (daily), 'W' (weekly), 'M' (monthly)
        """
        
        self.log_step(f"Aggregating by {freq} using {agg_func}")
        
        # Ensure datetime
        self.df[date_column] = pd.to_datetime(self.df[date_column])
        self.df = self.df.set_index(date_column)
        
        # Aggregate
        if agg_func == 'mean':
            self.df = self.df[value_columns].resample(freq).mean()
        elif agg_func == 'max':
            self.df = self.df[value_columns].resample(freq).max()
        elif agg_func == 'min':
            self.df = self.df[value_columns].resample(freq).min()
        elif agg_func == 'sum':
            self.df = self.df[value_columns].resample(freq).sum()
        elif agg_func == 'median':
            self.df = self.df[value_columns].resample(freq).median()
        
        self.df = self.df.reset_index()
        
        return self
    
    def pivot_parameters(
        self,
        index_columns: List[str],
        parameter_column: str = 'parameter',
        value_column: str = 'value'
    ) -> 'EnvironmentalDataPipeline':
        """
        Pivot data so each parameter becomes a column.
        """
        
        self.log_step("Pivoting parameters to columns")
        
        self.df = self.df.pivot_table(
            index=index_columns,
            columns=parameter_column,
            values=value_column,
            aggfunc='mean'
        ).reset_index()
        
        # Flatten column names if multi-index
        self.df.columns = [
            col if not isinstance(col, tuple) else '_'.join(str(c) for c in col)
            for col in self.df.columns
        ]
        
        return self
    
    # ==================== EXPORT ====================
    
    def export_csv(
        self,
        file_path: str,
        include_log: bool = True
    ) -> 'EnvironmentalDataPipeline':
        """Export processed data to CSV."""
        
        self.log_step(f"Exporting to {file_path}")
        
        self.df.to_csv(file_path, index=False, encoding='utf-8-sig')
        
        if include_log:
            log_path = file_path.replace('.csv', '_processing_log.txt')
            with open(log_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(self._processing_log))
        
        return self
    
    def export_excel(
        self,
        file_path: str,
        sheet_name: str = 'Data'
    ) -> 'EnvironmentalDataPipeline':
        """Export processed data to Excel."""
        
        self.log_step(f"Exporting to Excel: {file_path}")
        
        with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
            self.df.to_excel(writer, sheet_name=sheet_name, index=False)
            
            # Add processing log sheet
            log_df = pd.DataFrame({'Processing Log': self._processing_log})
            log_df.to_excel(writer, sheet_name='Log', index=False)
        
        return self
    
    # ==================== REPORTING ====================
    
    def generate_summary_report(self) -> Dict:
        """Generate summary statistics report."""
        
        report = {
            'record_count': len(self.df),
            'columns': list(self.df.columns),
            'date_range': None,
            'numeric_summary': {},
            'missing_values': self.df.isna().sum().to_dict(),
            'compliance_summary': None,
            'processing_log': self._processing_log
        }
        
        # Date range
        date_cols = self.df.select_dtypes(include=['datetime64']).columns
        if len(date_cols) > 0:
            report['date_range'] = {
                'start': str(self.df[date_cols[0]].min()),
                'end': str(self.df[date_cols[0]].max())
            }
        
        # Numeric summary
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            report['numeric_summary'][col] = {
                'mean': float(self.df[col].mean()),
                'std': float(self.df[col].std()),
                'min': float(self.df[col].min()),
                'max': float(self.df[col].max()),
                'median': float(self.df[col].median())
            }
        
        # Compliance summary
        if 'compliance_status' in self.df.columns:
            report['compliance_summary'] = self.df['compliance_status'].value_counts().to_dict()
        
        return report

# Usage example
if __name__ == "__main__":
    pipeline = EnvironmentalDataPipeline()
    
    # Example pipeline execution
    # (pipeline
    #     .load_csv("monitoring_data.csv", date_columns=['sample_date'])
    #     .clean_column_names()
    #     .parse_detection_limits('value')
    #     .handle_missing_values(strategy='interpolate', columns=['value'])
    #     .remove_outliers(['value'], method='iqr')
    #     .check_qcvn_compliance(standard='QCVN_40_2011', column='B')
    #     .export_csv("processed_data.csv")
    # )
    
    # report = pipeline.generate_summary_report()
    # print(report)
```

### Ngày 5-6: Project Structure và Best Practices

#### 3.1 Project Structure cho AI Applications

```python
# ============================================
# RECOMMENDED PROJECT STRUCTURE
# ============================================

"""
environmental-ai-project/
│
├── README.md                    # Project overview
├── pyproject.toml              # Project configuration (modern)
├── setup.py                    # Legacy setup (if needed)
├── requirements.txt            # Production dependencies
├── requirements-dev.txt        # Development dependencies
├── .env.example                # Environment variables template
├── .gitignore                  # Git ignore rules
├── Makefile                    # Common commands
│
├── src/                        # Source code
│   └── environmental_ai/       # Main package
│       ├── __init__.py
│       ├── config.py           # Configuration management
│       ├── constants.py        # Constants and enums
│       │
│       ├── data/               # Data processing
│       │   ├── __init__.py
│       │   ├── loaders.py      # Data loading utilities
│       │   ├── processors.py   # Data processing pipelines
│       │   ├── validators.py   # Data validation
│       │   └── schemas.py      # Pydantic schemas
│       │
│       ├── models/             # ML/AI models
│       │   ├── __init__.py
│       │   ├── embeddings.py   # Embedding models
│       │   ├── classifiers.py  # Classification models
│       │   └── rag.py          # RAG components
│       │
│       ├── services/           # Business logic
│       │   ├── __init__.py
│       │   ├── compliance.py   # Compliance checking
│       │   ├── search.py       # Search functionality
│       │   └── reporting.py    # Report generation
│       │
│       ├── api/                # API layer
│       │   ├── __init__.py
│       │   ├── routes.py       # API routes
│       │   ├── dependencies.py # FastAPI dependencies
│       │   └── schemas.py      # API request/response schemas
│       │
│       └── utils/              # Utilities
│           ├── __init__.py
│           ├── logging.py      # Logging configuration
│           ├── helpers.py      # Helper functions
│           └── exceptions.py   # Custom exceptions
│
├── tests/                      # Tests
│   ├── __init__.py
│   ├── conftest.py            # Pytest fixtures
│   ├── unit/                  # Unit tests
│   │   ├── test_processors.py
│   │   └── test_validators.py
│   ├── integration/           # Integration tests
│   │   └── test_api.py
│   └── fixtures/              # Test data
│       └── sample_data.csv
│
├── notebooks/                  # Jupyter notebooks
│   ├── 01_eda.ipynb           # Exploratory data analysis
│   ├── 02_modeling.ipynb      # Model development
│   └── 03_evaluation.ipynb    # Model evaluation
│
├── data/                       # Data directory (gitignored)
│   ├── raw/                   # Raw data
│   ├── processed/             # Processed data
│   └── external/              # External data sources
│
├── models/                     # Saved models (gitignored)
│   └── .gitkeep
│
├── scripts/                    # Utility scripts
│   ├── setup_db.py
│   ├── download_data.py
│   └── train_model.py
│
├── docker/                     # Docker configuration
│   ├── Dockerfile
│   └── docker-compose.yml
│
└── docs/                       # Documentation
    ├── api.md
    ├── architecture.md
    └── deployment.md
"""
```

#### 3.2 Configuration Management

```python
# ============================================
# src/environmental_ai/config.py
# ============================================

from pydantic_settings import BaseSettings
from pydantic import Field, field_validator
from typing import Optional, List
from pathlib import Path
from functools import lru_cache

class Settings(BaseSettings):
    """Application settings with validation."""
    
    # Application
    APP_NAME: str = "Environmental AI"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = Field(default="development", pattern="^(development|staging|production)$")
    
    # API Keys
    OPENAI_API_KEY: str = Field(..., min_length=20)
    ANTHROPIC_API_KEY: Optional[str] = None
    
    # Database
    DATABASE_URL: str = "sqlite:///./data/app.db"
    VECTOR_DB_PATH: str = "./data/chroma_db"
    
    # Model settings
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    LLM_MODEL: str = "gpt-4-turbo-preview"
    LLM_TEMPERATURE: float = Field(default=0.3, ge=0, le=2)
    LLM_MAX_TOKENS: int = Field(default=2000, ge=100, le=100000)
    
    # RAG settings
    CHUNK_SIZE: int = Field(default=1000, ge=100, le=5000)
    CHUNK_OVERLAP: int = Field(default=200, ge=0, le=1000)
    RETRIEVAL_TOP_K: int = Field(default=5, ge=1, le=20)
    
    # Paths
    DATA_DIR: Path = Path("./data")
    MODELS_DIR: Path = Path("./models")
    LOGS_DIR: Path = Path("./logs")
    
    # Logging
    LOG_LEVEL: str = Field(default="INFO", pattern="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$")
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:8501"]
    
    @field_validator('CHUNK_OVERLAP')
    @classmethod
    def validate_overlap(cls, v, info):
        chunk_size = info.data.get('CHUNK_SIZE', 1000)
        if v >= chunk_size:
            raise ValueError('CHUNK_OVERLAP must be less than CHUNK_SIZE')
        return v
    
    @field_validator('DATA_DIR', 'MODELS_DIR', 'LOGS_DIR', mode='after')
    @classmethod
    def create_directories(cls, v: Path) -> Path:
        v.mkdir(parents=True, exist_ok=True)
        return v
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True
        extra = "ignore"

@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()

# Usage
settings = get_settings()
```

#### 3.3 Custom Exceptions

```python
# ============================================
# src/environmental_ai/utils/exceptions.py
# ============================================

from typing import Optional, Dict, Any

class EnvironmentalAIError(Exception):
    """Base exception for Environmental AI application."""
    
    def __init__(
        self,
        message: str,
        code: str = "UNKNOWN_ERROR",
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "error": self.code,
            "message": self.message,
            "details": self.details
        }

class DataValidationError(EnvironmentalAIError):
    """Raised when data validation fails."""
    
    def __init__(self, message: str, field: str = None, value: Any = None):
        super().__init__(
            message=message,
            code="DATA_VALIDATION_ERROR",
            details={"field": field, "value": str(value)}
        )

class ComplianceCheckError(EnvironmentalAIError):
    """Raised when compliance check fails."""
    
    def __init__(self, message: str, parameter: str = None, standard: str = None):
        super().__init__(
            message=message,
            code="COMPLIANCE_CHECK_ERROR",
            details={"parameter": parameter, "standard": standard}
        )

class ModelError(EnvironmentalAIError):
    """Raised when model operation fails."""
    
    def __init__(self, message: str, model_name: str = None, operation: str = None):
        super().__init__(
            message=message,
            code="MODEL_ERROR",
            details={"model": model_name, "operation": operation}
        )

class RetrievalError(EnvironmentalAIError):
    """Raised when document retrieval fails."""
    
    def __init__(self, message: str, query: str = None):
        super().__init__(
            message=message,
            code="RETRIEVAL_ERROR",
            details={"query": query}
        )

class RateLimitError(EnvironmentalAIError):
    """Raised when API rate limit is exceeded."""
    
    def __init__(self, message: str, retry_after: int = None):
        super().__init__(
            message=message,
            code="RATE_LIMIT_ERROR",
            details={"retry_after": retry_after}
        )
```

#### 3.4 Logging Setup

```python
# ============================================
# src/environmental_ai/utils/logging.py
# ============================================

import logging
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional
import json
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler

class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno
        }
        
        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        # Add extra fields
        if hasattr(record, 'extra'):
            log_data.update(record.extra)
        
        return json.dumps(log_data, ensure_ascii=False)

def setup_logging(
    log_level: str = "INFO",
    log_dir: Optional[Path] = None,
    app_name: str = "environmental_ai",
    json_format: bool = False
) -> logging.Logger:
    """
    Setup application logging.
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_dir: Directory for log files
        app_name: Application name for logger
        json_format: Use JSON format for logs
    
    Returns:
        Configured logger instance
    """
    
    # Create logger
    logger = logging.getLogger(app_name)
    logger.setLevel(getattr(logging, log_level.upper()))
    
    # Clear existing handlers
    logger.handlers = []
    
    # Formatter
    if json_format:
        formatter = JSONFormatter()
    else:
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler (if log_dir provided)
    if log_dir:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        
        # Rotating file handler
        file_handler = RotatingFileHandler(
            log_dir / f"{app_name}.log",
            maxBytes=10 * 1024 * 1024,  # 10 MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        # Error file handler
        error_handler = RotatingFileHandler(
            log_dir / f"{app_name}_error.log",
            maxBytes=10 * 1024 * 1024,
            backupCount=5,
            encoding='utf-8'
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(formatter)
        logger.addHandler(error_handler)
    
    return logger

class LoggerMixin:
    """Mixin class to add logging capability."""
    
    @property
    def logger(self) -> logging.Logger:
        if not hasattr(self, '_logger'):
            self._logger = logging.getLogger(
                f"{self.__class__.__module__}.{self.__class__.__name__}"
            )
        return self._logger

# Context manager for timing operations
class LogTimer:
    """Context manager for logging operation duration."""
    
    def __init__(self, logger: logging.Logger, operation: str):
        self.logger = logger
        self.operation = operation
        self.start_time = None
    
    def __enter__(self):
        self.start_time = datetime.now()
        self.logger.info(f"Starting: {self.operation}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = (datetime.now() - self.start_time).total_seconds()
        
        if exc_type:
            self.logger.error(
                f"Failed: {self.operation} (duration: {duration:.2f}s)",
                exc_info=True
            )
        else:
            self.logger.info(f"Completed: {self.operation} (duration: {duration:.2f}s)")
        
        return False

# Usage example
if __name__ == "__main__":
    logger = setup_logging(
        log_level="DEBUG",
        log_dir=Path("./logs"),
        json_format=False
    )
    
    logger.info("Application started")
    
    with LogTimer(logger, "Data processing"):
        # Simulate processing
        import time
        time.sleep(1)
    
    logger.info("Application finished")
```

### Ngày 7: Unit Testing

#### 4.1 Testing với Pytest

```python
# ============================================
# tests/conftest.py - Shared Fixtures
# ============================================

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
import tempfile
import json

@pytest.fixture
def sample_monitoring_data():
    """Generate sample environmental monitoring data."""
    np.random.seed(42)
    
    n_samples = 100
    
    data = {
        'sample_id': [f"WAT-{i:04d}" for i in range(n_samples)],
        'sample_date': pd.date_range(start='2024-01-01', periods=n_samples, freq='D'),
        'location': np.random.choice(['HCM-001', 'HCM-002', 'DN-001'], n_samples),
        'parameter': np.random.choice(['BOD5', 'COD', 'TSS', 'pH'], n_samples),
        'value': np.random.lognormal(mean=3, sigma=0.5, size=n_samples),
        'unit': 'mg/L'
    }
    
    return pd.DataFrame(data)

@pytest.fixture
def sample_csv_file(sample_monitoring_data, tmp_path):
    """Create temporary CSV file with sample data."""
    file_path = tmp_path / "test_data.csv"
    sample_monitoring_data.to_csv(file_path, index=False)
    return file_path

@pytest.fixture
def qcvn_standards():
    """QCVN 40:2011 standards for testing."""
    return {
        'BOD5': {'unit': 'mg/L', 'A': 30, 'B': 50},
        'COD': {'unit': 'mg/L', 'A': 75, 'B': 150},
        'TSS': {'unit': 'mg/L', 'A': 50, 'B': 100},
        'pH': {'unit': '-', 'A': (6, 9), 'B': (5.5, 9)}
    }

@pytest.fixture
def mock_api_response():
    """Mock API response for testing."""
    return {
        "station_id": "HCM-001",
        "timestamp": "2024-01-15T08:00:00",
        "parameters": {
            "PM2.5": {"value": 35.2, "unit": "μg/m³"},
            "PM10": {"value": 52.1, "unit": "μg/m³"},
            "CO": {"value": 1.2, "unit": "mg/m³"},
        }
    }

# ============================================
# tests/unit/test_data_processing.py
# ============================================

import pytest
import pandas as pd
import numpy as np
from environmental_ai.data.processors import EnvironmentalDataPipeline
from environmental_ai.utils.exceptions import DataValidationError

class TestEnvironmentalDataPipeline:
    """Test suite for EnvironmentalDataPipeline."""
    
    def test_load_csv_success(self, sample_csv_file):
        """Test successful CSV loading."""
        pipeline = EnvironmentalDataPipeline()
        pipeline.load_csv(str(sample_csv_file))
        
        assert pipeline.df is not None
        assert len(pipeline.df) == 100
    
    def test_load_csv_file_not_found(self):
        """Test CSV loading with non-existent file."""
        pipeline = EnvironmentalDataPipeline()
        
        with pytest.raises(FileNotFoundError):
            pipeline.load_csv("non_existent_file.csv")
    
    def test_clean_column_names(self, sample_csv_file):
        """Test column name cleaning."""
        pipeline = EnvironmentalDataPipeline()
        pipeline.load_csv(str(sample_csv_file))
        pipeline.clean_column_names()
        
        # All columns should be lowercase
        assert all(col == col.lower() for col in pipeline.df.columns)
        # No spaces in column names
        assert all(' ' not in col for col in pipeline.df.columns)
    
    @pytest.mark.parametrize("strategy,expected_na", [
        ("drop", 0),
        ("fill", 0),
        ("ffill", None),  # Depends on data
    ])
    def test_handle_missing_values(self, sample_monitoring_data, strategy, expected_na):
        """Test different missing value handling strategies."""
        # Add some missing values
        df = sample_monitoring_data.copy()
        df.loc[5:10, 'value'] = np.nan
        
        pipeline = EnvironmentalDataPipeline()
        pipeline.df = df
        
        if strategy == "fill":
            pipeline.handle_missing_values(strategy=strategy, fill_value=0, columns=['value'])
        else:
            pipeline.handle_missing_values(strategy=strategy, columns=['value'])
        
        if expected_na is not None:
            assert pipeline.df['value'].isna().sum() == expected_na
    
    def test_remove_outliers_iqr(self, sample_monitoring_data):
        """Test outlier removal using IQR method."""
        # Add some outliers
        df = sample_monitoring_data.copy()
        df.loc[0, 'value'] = 10000  # Extreme outlier
        
        pipeline = EnvironmentalDataPipeline()
        pipeline.df = df
        
        initial_len = len(pipeline.df)
        pipeline.remove_outliers(['value'], method='iqr')
        
        assert len(pipeline.df) < initial_len
        assert 10000 not in pipeline.df['value'].values
    
    @pytest.mark.parametrize("input_value,expected", [
        ("45.5", 45.5),
        ("<0.5", 0.25),  # Half of detection limit
        ("ND", np.nan),
        ("KPH", np.nan),
        (">100", 100.0),
    ])
    def test_parse_detection_limits(self, input_value, expected):
        """Test parsing of detection limit values."""
        df = pd.DataFrame({'value': [input_value]})
        
        pipeline = EnvironmentalDataPipeline()
        pipeline.df = df
        pipeline.parse_detection_limits('value')
        
        if np.isnan(expected):
            assert pd.isna(pipeline.df['value'].iloc[0])
        else:
            assert pipeline.df['value'].iloc[0] == pytest.approx(expected)

class TestComplianceChecking:
    """Test compliance checking functionality."""
    
    def test_compliance_within_limit(self, qcvn_standards):
        """Test compliance when value is within limit."""
        df = pd.DataFrame({
            'parameter': ['BOD5'],
            'value': [25.0]  # Below limit of 30 (A) and 50 (B)
        })
        
        pipeline = EnvironmentalDataPipeline()
        pipeline.df = df
        pipeline.QCVN_40_2011 = qcvn_standards
        pipeline.check_qcvn_compliance(column='B')
        
        assert pipeline.df['compliance_status'].iloc[0] == 'Đạt'
    
    def test_compliance_exceeds_limit(self, qcvn_standards):
        """Test compliance when value exceeds limit."""
        df = pd.DataFrame({
            'parameter': ['BOD5'],
            'value': [60.0]  # Above limit of 50 (B)
        })
        
        pipeline = EnvironmentalDataPipeline()
        pipeline.df = df
        pipeline.QCVN_40_2011 = qcvn_standards
        pipeline.check_qcvn_compliance(column='B')
        
        assert pipeline.df['compliance_status'].iloc[0] == 'Không đạt'
    
    def test_ph_range_compliance(self, qcvn_standards):
        """Test pH compliance with range limits."""
        df = pd.DataFrame({
            'parameter': ['pH', 'pH', 'pH'],
            'value': [7.0, 5.0, 10.0]  # Within, below, above range
        })
        
        pipeline = EnvironmentalDataPipeline()
        pipeline.df = df
        pipeline.QCVN_40_2011 = qcvn_standards
        pipeline.check_qcvn_compliance(column='B')
        
        expected = ['Đạt', 'Không đạt', 'Không đạt']
        assert pipeline.df['compliance_status'].tolist() == expected

# ============================================
# tests/unit/test_calculations.py
# ============================================

import pytest
import numpy as np
from environmental_ai.data.processors import EnvironmentalCalculations

class TestEnvironmentalCalculations:
    """Test environmental calculations."""
    
    @pytest.fixture
    def calc(self):
        return EnvironmentalCalculations()
    
    @pytest.mark.parametrize("concentration,expected_aqi_range", [
        (10, (0, 50)),      # Good
        (30, (51, 100)),    # Moderate
        (60, (101, 150)),   # Unhealthy for sensitive
        (100, (151, 200)),  # Unhealthy
    ])
    def test_aqi_calculation(self, calc, concentration, expected_aqi_range):
        """Test AQI calculation for PM2.5."""
        aqi = calc.calculate_aqi_subindex(concentration, 'PM2.5')
        
        assert aqi is not None
        assert expected_aqi_range[0] <= aqi <= expected_aqi_range[1]
    
    def test_aqi_batch_calculation(self, calc):
        """Test batch AQI calculation."""
        pm25 = np.array([10, 30, 60, 100])
        pm10 = np.array([20, 60, 150, 300])
        
        aqi = calc.calculate_aqi_batch(pm25, pm10)
        
        assert len(aqi) == 4
        assert aqi[0] < aqi[-1]  # AQI should increase
    
    def test_statistics_calculation(self, calc):
        """Test comprehensive statistics calculation."""
        data = np.array([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
        
        stats = calc.calculate_statistics(data)
        
        assert stats['count'] == 10
        assert stats['mean'] == pytest.approx(55.0)
        assert stats['min'] == 10
        assert stats['max'] == 100
        assert stats['median'] == pytest.approx(55.0)
    
    def test_outlier_detection(self, calc):
        """Test outlier detection using IQR."""
        data = np.array([10, 20, 30, 40, 50, 200])  # 200 is outlier
        
        clean, outliers, indices = calc.detect_outliers_iqr(data)
        
        assert 200 in outliers
        assert 200 not in clean
        assert 5 in indices
    
    def test_exceedance_statistics(self, calc):
        """Test exceedance statistics calculation."""
        data = np.array([40, 45, 55, 60, 70, 80])  # 4 exceed threshold of 50
        
        result = calc.calculate_exceedance_statistics(data, threshold=50)
        
        assert result['exceedance_count'] == 4
        assert result['exceedance_rate'] == pytest.approx(66.67, rel=0.01)

# ============================================
# tests/integration/test_pipeline_integration.py
# ============================================

import pytest
import pandas as pd
from pathlib import Path

class TestPipelineIntegration:
    """Integration tests for complete pipeline."""
    
    def test_full_pipeline_execution(self, sample_csv_file, tmp_path):
        """Test complete pipeline from load to export."""
        from environmental_ai.data.processors import EnvironmentalDataPipeline
        
        output_path = tmp_path / "output.csv"
        
        pipeline = EnvironmentalDataPipeline()
        
        (pipeline
            .load_csv(str(sample_csv_file))
            .clean_column_names()
            .handle_missing_values(strategy='drop')
            .remove_outliers(['value'], method='iqr')
            .export_csv(str(output_path)))
        
        # Verify output file exists
        assert output_path.exists()
        
        # Verify output data
        output_df = pd.read_csv(output_path)
        assert len(output_df) > 0
        assert 'value' in output_df.columns
    
    def test_pipeline_with_compliance_check(self, sample_csv_file, tmp_path):
        """Test pipeline with compliance checking."""
        from environmental_ai.data.processors import EnvironmentalDataPipeline
        
        pipeline = EnvironmentalDataPipeline()
        
        (pipeline
            .load_csv(str(sample_csv_file))
            .clean_column_names()
            .check_qcvn_compliance(column='B'))
        
        # Verify compliance columns added
        assert 'compliance_status' in pipeline.df.columns
        assert 'qcvn_limit' in pipeline.df.columns
        
        # Verify compliance values
        assert set(pipeline.df['compliance_status'].dropna().unique()).issubset(
            {'Đạt', 'Không đạt'}
        )
```

---

## 📝 BÀI TẬP THỰC HÀNH

### Bài tập 1: Data Processing Pipeline (Ngày 1-3)

```
🎯 Mục tiêu: Xây dựng pipeline xử lý dữ liệu quan trắc chất lượng nước

📋 Yêu cầu:
1. Load dữ liệu từ file CSV (tạo sample data nếu chưa có)
2. Clean và normalize dữ liệu
3. Xử lý missing values và outliers
4. Kiểm tra compliance theo QCVN 40:2011
5. Export kết quả và báo cáo

📁 Deliverables:
- src/data/water_quality_pipeline.py
- tests/test_water_quality.py
- notebooks/01_water_quality_eda.ipynb
```

### Bài tập 2: Air Quality Calculator (Ngày 4-5)

```
🎯 Mục tiêu: Xây dựng module tính toán AQI theo chuẩn Việt Nam

📋 Yêu cầu:
1. Implement AQI calculation theo QCVN 05:2023
2. Support batch processing với NumPy
3. Generate air quality reports
4. Visualize với matplotlib

📁 Deliverables:
- src/calculators/aqi_calculator.py
- tests/test_aqi.py
- notebooks/02_aqi_analysis.ipynb
```

### Bài tập 3: Project Setup (Ngày 6-7)

```
🎯 Mục tiêu: Setup hoàn chỉnh project structure

📋 Yêu cầu:
1. Tạo project structure theo best practices
2. Setup configuration với Pydantic
3. Implement logging system
4. Write comprehensive tests
5. Setup pre-commit hooks

📁 Deliverables:
- Complete project structure
- README.md với setup instructions
- 90%+ test coverage
- CI configuration (GitHub Actions)
```

---

## ✅ CHECKLIST TUẦN 1

### Kiến thức đã học
- [ ] Type hints và static typing trong Python
- [ ] Dataclasses và Pydantic models
- [ ] Async/await programming
- [ ] NumPy cho numerical computing
- [ ] Pandas cho data processing
- [ ] Project structure best practices
- [ ] Configuration management
- [ ] Logging và error handling
- [ ] Unit testing với pytest

### Skills thực hành
- [ ] Viết code production-ready với type hints
- [ ] Xây dựng data processing pipelines
- [ ] Xử lý dữ liệu môi trường Việt Nam
- [ ] Tính toán AQI theo QCVN
- [ ] Kiểm tra compliance theo tiêu chuẩn VN
- [ ] Setup và cấu trúc project
- [ ] Viết unit tests comprehensive

### Deliverables
- [ ] Water quality processing pipeline
- [ ] AQI calculator module
- [ ] Project với complete structure
- [ ] Test suite với >80% coverage
- [ ] Documentation (README, docstrings)

---

## 📖 TÀI NGUYÊN BỔ SUNG

### Readings
1. [Python Type Hints Cheat Sheet](https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html)
2. [Pydantic Documentation](https://docs.pydantic.dev/)
3. [NumPy User Guide](https://numpy.org/doc/stable/user/index.html)
4. [Pandas User Guide](https://pandas.pydata.org/docs/user_guide/index.html)

### Vietnamese Environmental Resources
1. QCVN 40:2011/BTNMT - Nước thải công nghiệp
2. QCVN 05:2023/BTNMT - Chất lượng không khí
3. Thông tư 10/2021/TT-BTNMT - Quan trắc môi trường

### Practice
1. [LeetCode Python Problems](https://leetcode.com/problemset/all/?difficulty=MEDIUM&listId=wpwgkgt&page=1)
2. [Kaggle Environmental Datasets](https://www.kaggle.com/datasets?search=environmental)

---

*Hoàn thành Tuần 1 để tiếp tục sang Tuần 2: Machine Learning & NLP Basics*
