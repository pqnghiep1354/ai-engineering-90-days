# 🎓 GIAI ĐOẠN 1: NỀN TẢNG (FOUNDATION)

## Tuần 1-4 | 60+ giờ học tập

---

## 📋 TỔNG QUAN GIAI ĐOẠN

### Mục tiêu
Xây dựng nền tảng vững chắc về Python, ML/NLP, Vector Databases, và LLM integration để chuẩn bị cho các giai đoạn nâng cao hơn.

### Kết quả đầu ra
**PROJECT 1: Environmental Regulation Semantic Search + Q&A System**

---

## 📚 CẤU TRÚC TÀI LIỆU

```
phase-1-foundation/
├── README.md                           # File này
│
├── week-1/
│   └── WEEK-1-PYTHON-DATA-PROCESSING.md
│       ├── Python Advanced (Type hints, Dataclasses, Pydantic)
│       ├── Async/Await Programming
│       ├── NumPy & Pandas cho Environmental Data
│       ├── Project Structure & Best Practices
│       └── Unit Testing với Pytest
│
├── week-2/
│   └── WEEK-2-ML-NLP-BASICS.md
│       ├── Machine Learning Workflow
│       ├── Supervised Learning Algorithms
│       ├── Vietnamese NLP Pipeline
│       ├── Text Vectorization (TF-IDF)
│       └── Document Classification
│
├── week-3/
│   └── WEEK-3-VECTOR-DB-SEMANTIC-SEARCH.md
│       ├── Embeddings & Vector Representations
│       ├── ChromaDB Implementation
│       ├── Document Chunking Strategies
│       ├── Hybrid Search
│       └── Search API với FastAPI
│
└── week-4/
    └── WEEK-4-LLM-PROMPT-ENGINEERING.md
        ├── LLM Landscape & Model Selection
        ├── Unified LLM Client
        ├── Prompt Engineering Framework
        ├── Environmental Q&A System
        └── Answer Evaluation
```

---

## 📅 LỊCH TRÌNH CHI TIẾT

### Tuần 1: Python cho AI Engineering & Xử lý dữ liệu

| Ngày | Nội dung | Thời gian |
|------|----------|-----------|
| 1-2 | Python Advanced: Type hints, Dataclasses, Pydantic, Async | 4-6h |
| 3-4 | NumPy & Pandas: Environmental data processing | 4-6h |
| 5-6 | Project structure, Configuration, Logging | 4-6h |
| 7 | Unit testing với Pytest | 2-3h |

**Deliverables:**
- Data processing pipeline
- Project structure template
- Test suite

---

### Tuần 2: Machine Learning & NLP Basics

| Ngày | Nội dung | Thời gian |
|------|----------|-----------|
| 1-2 | ML Fundamentals: Workflow, Algorithms | 4-6h |
| 3-4 | Vietnamese NLP: Tokenization, POS, NER | 4-6h |
| 5-6 | Text Classification | 4-6h |
| 7 | Model evaluation & optimization | 2-3h |

**Deliverables:**
- Pollution level classifier
- Vietnamese NLP pipeline
- Document classifier

---

### Tuần 3: Vector Databases & Semantic Search

| Ngày | Nội dung | Thời gian |
|------|----------|-----------|
| 1-2 | Embeddings: Models, Comparison | 4-6h |
| 3-4 | ChromaDB: Setup, Operations, Chunking | 4-6h |
| 5-6 | Search API: FastAPI, Filtering | 4-6h |
| 7 | Demo UI với Streamlit | 2-3h |

**Deliverables:**
- Embedding benchmark
- ChromaDB implementation
- Search API + Demo UI

---

### Tuần 4: LLM Fundamentals & Prompt Engineering

| Ngày | Nội dung | Thời gian |
|------|----------|-----------|
| 1-2 | LLM: Models, APIs, Clients | 4-6h |
| 3-4 | Prompt Engineering: Techniques, Templates | 4-6h |
| 5-6 | Q&A System: RAG foundation | 4-6h |
| 7 | Integration & Testing | 2-3h |

**Deliverables:**
- Unified LLM client
- Prompt library
- Q&A system với citations

---

## 🛠 TECH STACK

### Languages & Frameworks
- Python 3.10+
- FastAPI
- Streamlit

### AI/ML Libraries
- NumPy, Pandas, scikit-learn
- OpenAI API, Anthropic API
- sentence-transformers, underthesea

### Databases
- ChromaDB
- SQLite (optional)

### DevOps
- Docker
- pytest
- GitHub Actions (CI/CD)

---

## 📊 METRICS ĐÁNH GIÁ

### Technical Metrics

| Metric | Target | Actual |
|--------|--------|--------|
| Search Precision@5 | > 0.8 | |
| Search Latency P95 | < 500ms | |
| Q&A Accuracy | > 80% | |
| Test Coverage | > 80% | |

### Project Completion

| Component | Status |
|-----------|--------|
| Data Pipeline | ☐ |
| NLP Pipeline | ☐ |
| Vector DB | ☐ |
| Search API | ☐ |
| Q&A System | ☐ |
| Demo UI | ☐ |
| Documentation | ☐ |
| Tests | ☐ |

---

## 📝 CHECKLIST HOÀN THÀNH

### Kiến thức

- [ ] **Python Advanced**
  - [ ] Type hints và static typing
  - [ ] Dataclasses và Pydantic
  - [ ] Async/await programming
  - [ ] Context managers và decorators

- [ ] **Data Processing**
  - [ ] NumPy operations
  - [ ] Pandas pipelines
  - [ ] Data cleaning và validation
  - [ ] Environmental data formats

- [ ] **Machine Learning**
  - [ ] ML workflow
  - [ ] Classification algorithms
  - [ ] Model evaluation
  - [ ] Feature engineering

- [ ] **NLP**
  - [ ] Vietnamese tokenization
  - [ ] Text preprocessing
  - [ ] Text vectorization (TF-IDF)
  - [ ] Named entity recognition

- [ ] **Vector Databases**
  - [ ] Embedding concepts
  - [ ] Similarity metrics
  - [ ] ChromaDB operations
  - [ ] Chunking strategies

- [ ] **LLM**
  - [ ] Model selection
  - [ ] API integration
  - [ ] Prompt engineering
  - [ ] Streaming responses

### Skills

- [ ] Xử lý dữ liệu môi trường Việt Nam
- [ ] Build text classification models
- [ ] Implement semantic search
- [ ] Viết effective prompts
- [ ] Build REST APIs
- [ ] Create demo UIs
- [ ] Write unit tests
- [ ] Document code properly

### Projects

- [ ] **PROJECT 1**: Environmental Regulation Search + Q&A
  - [ ] 100+ documents indexed
  - [ ] Semantic + Hybrid search
  - [ ] Q&A với citations
  - [ ] API endpoints
  - [ ] Demo UI
  - [ ] Documentation

---

## 🔗 TÀI NGUYÊN

### Tài liệu tuần 1
- [Week 1: Python & Data Processing](./week-1/WEEK-1-PYTHON-DATA-PROCESSING.md)

### Tài liệu tuần 2
- [Week 2: ML & NLP Basics](./week-2/WEEK-2-ML-NLP-BASICS.md)

### Tài liệu tuần 3
- [Week 3: Vector DB & Semantic Search](./week-3/WEEK-3-VECTOR-DB-SEMANTIC-SEARCH.md)

### Tài liệu tuần 4
- [Week 4: LLM & Prompt Engineering](./week-4/WEEK-4-LLM-PROMPT-ENGINEERING.md)

---

## ➡️ BƯỚC TIẾP THEO

Sau khi hoàn thành Phase 1, bạn sẽ tiếp tục với:

### Phase 2: Intermediate (Tuần 5-8)
- RAG Architecture Deep Dive
- LangChain & LlamaIndex
- Production Optimization
- Function Calling & Tool Use

### Phase 3: Advanced (Tuần 9-12)
- Multi-Agent Systems
- Document Generation
- Testing & Deployment
- Capstone Project

---

*Chúc bạn học tập hiệu quả! 🚀*
